//
//  WXApiResponseManager.m
//  SDKSample
//
//  Created by Jeason on 15/7/14.
//
//

#import "WXApi.h"
#import "WXApiResponseHandler.h"

@implementation WXApiResponseHandler

#pragma mark - Public Methods

@end
