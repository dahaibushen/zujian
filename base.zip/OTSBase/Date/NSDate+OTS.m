//
//  NSDate+OTS.m
//  OneStore
//
//  Created by huang jiming on 13-6-18.
//  Copyright (c) 2013年 OneStore. All rights reserved.
//

#import "NSDate+OTS.h"
#import "OTSGlobalValue.h"

@implementation NSDate (OTS)

- (NSUInteger)distanceNowDays {
    NSTimeInterval seconds = [self timeIntervalSinceNow];
    if (seconds < 0) {
        seconds = -seconds;
    }
    NSInteger daySeconds = 60 * 60 * 24;
    NSInteger days = (NSInteger) (seconds / daySeconds);
    return days;
}

- (NSDictionary *)distanceNowDic {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *comps = [calendar components:kCFCalendarUnitDay | kCFCalendarUnitHour | kCFCalendarUnitMinute | kCFCalendarUnitSecond fromDate:[OTSGlobalValue sharedInstance].serverTime toDate:self options:0];

    NSDictionary *dic = nil;
    dic = [NSDictionary dictionaryWithObjectsAndKeys:@(comps.day), @"day", @(comps.hour), @"hour", @(comps.minute), @"minute", @(comps.second), @"second", nil];

    return dic;
}

/**
 *  是否是今天的日期
 *
 *  @return 返回YES OR NO
 */
- (BOOL)isTodayDate {
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy-MM-dd"];
    NSString *today = [dateFormatter stringFromDate:[NSDate date]];
    NSString *day = [dateFormatter stringFromDate:self];

    if ([today isEqualToString:day]) {
        return YES;
    }

    return NO;
}

/**
 *  是否昨天
 */
- (BOOL)isYesterday {
    NSDate *nowDate = [OTSGlobalValue sharedInstance].serverTime;

    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd";
    NSString *selStr = [fmt stringFromDate:self];
    NSDate *selfDate = [fmt dateFromString:selStr];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDateComponents *cmps = [calendar components:NSCalendarUnitDay fromDate:selfDate toDate:nowDate options:0];
    return cmps.day == 1;
}

/**
 *  是否是今年的日期
 *
 *  @return 返回YES OR NO
 */
- (BOOL)isCurrentYearDate {

    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyy"];
    NSString *today = [dateFormatter stringFromDate:[NSDate date]];
    NSString *day = [dateFormatter stringFromDate:self];

    if ([today isEqualToString:day]) {
        return YES;
    }

    return NO;
}

/**
 *  判断与当前时间差值
 */
- (NSDateComponents *)deltaWithNow {
    NSCalendar *calendar = [NSCalendar currentCalendar];
    int unit = NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
    return [calendar components:unit fromDate:self toDate:[NSDate date] options:0];
}

@end
