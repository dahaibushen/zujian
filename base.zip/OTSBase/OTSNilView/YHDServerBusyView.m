//
//  YHDServerBusyView.m
//  OneStoreMain
//
//  Created by 黄吉明 on 11/8/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "YHDServerBusyView.h"
#import <OTSCore/OTSCore.h>
#import "OTSOperationManager.h"
#import "OTSVC.h"
#import <OTSCore/OTSEnlargeButton.h>

@interface YHDGifView ()

@property(nonatomic, strong) UIImageView *gifIv;//gif动画
@property(nonatomic, strong) UILabel *tipLbl;//提示语
@property(nonatomic, strong) UIButton *bottomBtn;//底部按钮

/**
 *  功能:点击底部按钮
 */
- (void)bottomBtnClicked:(id)sender;

@end

@interface YHDServerBusyView ()
@property(nonatomic, strong) OTSEnlargeButton *backButton;
@property(nonatomic, strong) NSMutableArray *cachedOperationMangers;//所有缓存的出错的operation manger

@end

@implementation YHDServerBusyView

DEF_SINGLETON(YHDServerBusyView)

- (id)init {
    if (self = [super init]) {
        //loading图片
        NSMutableArray *gifArray = [NSMutableArray array];
        for (int i = 0; i < 27; i++) {
            UIImage *img = [UIImage imageNamed:[NSString stringWithFormat:@"loadingView_%d", i]];
            [gifArray safeAddObject:img];
        }
        self.gifIv.animationImages = gifArray;
        self.gifIv.animationDuration = 0.8;

        //提示语
        self.tipLbl.text = @"服务器正忙，请稍后再试～";

        //底部按钮
        [self.bottomBtn setTitle:@"重新加载" forState:UIControlStateNormal];
        self.bottomBtn.hidden = NO;

        //返回按钮
        [self addSubview:self.backButton];
        [self.backButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
        [self.backButton autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:25];
    }

    return self;
}

- (BOOL)willDealloc {
    return NO;
}

#pragma mark - Property

- (NSMutableArray *)cachedOperationMangers {
    if (!_cachedOperationMangers) {
        _cachedOperationMangers = [NSMutableArray array];
    }

    return _cachedOperationMangers;
}

- (OTSEnlargeButton *)backButton {
    if (!_backButton) {
        _backButton = [OTSEnlargeButton buttonWithType:UIButtonTypeCustom];
        _backButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_backButton setBackgroundImage:[UIImage imageNamed:@"icon_bg"] forState:UIControlStateNormal];
        [_backButton setBackgroundImage:[UIImage imageNamed:@"icon_bg"] forState:UIControlStateHighlighted];
        [_backButton setImage:[UIImage imageNamed:@"SRVC_arrow_nor"] forState:UIControlStateNormal];
        [_backButton setImage:[UIImage imageNamed:@"SRVC_arrow_high"] forState:UIControlStateHighlighted];
        [_backButton setEnlargeEdge:10];
        [_backButton sizeToFit];
        [_backButton addTarget:self action:@selector(backBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }
    return _backButton;
}

- (void)showInVC:(OTSVC *)aVC delegate:(id <YHDGifViewDelegate>)aDelegate {
    [super showInVC:aVC delegate:aDelegate];
    self.backButton.hidden = !aVC.navigationBarHidden;
}

#pragma mark - Rewrite

/**
 *  功能:点击底部按钮
 */
- (void)bottomBtnClicked:(id)sender {
    for (OTSOperationManager *manger in self.cachedOperationMangers) {
        [manger performCachedOperationForShowErrorView];
    }

    [super bottomBtnClicked:sender];
}

/**
 * 功能:点击左按钮 返回上一页面
 */
- (void)backBtnClicked:(id)sender {
    if ([self.delegate respondsToSelector:@selector(gifView:backBtnClicked:)]) {
        [self.delegate gifView:self backBtnClicked:sender];
    }
}

/**
 *  功能:隐藏gif view
 */
- (void)hide {
    [super hide];
    [self.cachedOperationMangers removeAllObjects];
}

#pragma mark - API

/**
 *  功能:存储所有出错的operation manger，便于重新加载
 */
- (void)cacheErrorOperationManager:(OTSOperationManager *)aManger {
    [self.cachedOperationMangers safeAddObject:aManger];
}

@end
