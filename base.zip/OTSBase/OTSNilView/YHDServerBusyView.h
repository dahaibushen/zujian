//
//  YHDServerBusyView.h
//  OneStoreMain
//
//  Created by 黄吉明 on 11/8/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "YHDGifView.h"

@class OTSOperationManager;

@interface YHDServerBusyView : YHDGifView

+ (YHDServerBusyView *)sharedInstance;

/**
 *  功能:存储所有出错的operation manger，便于重新加载
 */
- (void)cacheErrorOperationManager:(OTSOperationManager *)aManger;

@end
