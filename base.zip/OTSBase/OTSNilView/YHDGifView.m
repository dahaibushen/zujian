//
//  YHDGifView.m
//  OneStoreMain
//
//  Created by 黄吉明 on 11/8/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "YHDGifView.h"
#import "OTSVC.h"
#import <OTSCore/UIView+create.h>
#import <OTSCore/OTSCore.h>

@interface YHDGifView ()
@property(nonatomic, strong) UIImageView *gifIv;//gif动画
@property(nonatomic, strong) UILabel *tipLbl;//提示语
@property(nonatomic, strong) UIButton *bottomBtn;//底部按钮

@end

@implementation YHDGifView

DEF_SINGLETON(YHDGifView)

- (id)init {
    CGRect screenBounds = [UIScreen mainScreen].bounds;
    if (self = [super initWithFrame:CGRectMake(0, 0, screenBounds.size.width, screenBounds.size.height - 64)]) {
        self.backgroundColor = [UIColor colorWithRed:237.0 / 255.0 green:237.0 / 255.0 blue:237.0 / 255.0 alpha:1.0];
        [self addSubview:self.gifIv];
        [self addSubview:self.tipLbl];
        [self addSubview:self.bottomBtn];

        //布局
        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.gifIv attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.f constant:0.0f]];
        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.gifIv attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self.gifIv attribute:NSLayoutAttributeHeight multiplier:1.f constant:0.0f]];

        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.tipLbl attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterY multiplier:1.f constant:10.0f]];
        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.tipLbl attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeWidth multiplier:1.f constant:280.0f]];

        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.bottomBtn attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeWidth multiplier:1.f constant:280.0f]];

        [self addConstraints:[NSLayoutConstraint constraintsWithVisualFormat:@"V:|-(>=0)-[_gifIv(200)]-(-40)-[_tipLbl(120)]-(>=0)-[_bottomBtn(43)]-100-|" options:NSLayoutFormatAlignAllCenterX metrics:nil views:NSDictionaryOfVariableBindings(_gifIv, _tipLbl, _bottomBtn)]];
    }

    return self;
}

#pragma mark - Property

- (UIImageView *)gifIv {
    if (!_gifIv) {
        _gifIv = [UIImageView autolayoutView];
    }

    return _gifIv;
}

- (UILabel *)tipLbl {
    if (!_tipLbl) {
        _tipLbl = [UILabel autolayoutView];
        _tipLbl.textColor = [UIColor colorWithRed:145.0 / 255.0 green:145.0 / 255.0 blue:145.0 / 255.0 alpha:1.0];
        _tipLbl.font = [UIFont systemFontOfSize:14.0];
        _tipLbl.textAlignment = NSTextAlignmentCenter;
        _tipLbl.backgroundColor = [UIColor clearColor];
        _tipLbl.numberOfLines = 0;
    }

    return _tipLbl;
}

- (UIButton *)bottomBtn {
    if (!_bottomBtn) {
        _bottomBtn = [UIButton autolayoutView];
        _bottomBtn.layer.cornerRadius = 5.0;
        _bottomBtn.backgroundColor = [UIColor redColor];
        [_bottomBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        _bottomBtn.titleLabel.font = [UIFont systemFontOfSize:15.0];
        [_bottomBtn addTarget:self action:@selector(bottomBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }

    return _bottomBtn;
}

#pragma mark - Action

/**
 *  功能:点击底部按钮
 */
- (void)bottomBtnClicked:(id)sender {
    if ([self.delegate respondsToSelector:@selector(gifView:bottomBtnClicked:)]) {
        [self.delegate gifView:self bottomBtnClicked:sender];
    }
}

#pragma mark - API

/**
 *  功能:在aVC中显示gif view，若是有navi bar和tool bar，gif view不会遮挡navi bar和tool bar，支持delegate自定义frame
 */
- (void)showInVC:(OTSVC *)aVC delegate:(id <YHDGifViewDelegate>)aDelegate {
    if (!aVC.isViewLoaded) {
        return;
    }

    //默认frame
    CGRect screenBounds = [UIScreen mainScreen].bounds;
    CGFloat rectY = 0.0;
    CGFloat rectHeight = screenBounds.size.height - 64.0;//-113.0
    if (aVC.navigationBarHidden) {
        rectY = 0.0;
        rectHeight += 64.0;
    }

    CGRect frame = CGRectMake(0, rectY, screenBounds.size.width, rectHeight);

    //自定义frame
    if ([aDelegate respondsToSelector:@selector(frameForYHDGifView:)]) {
        if (!CGRectEqualToRect([aDelegate frameForYHDGifView:self], CGRectZero)) {
            frame = [aDelegate frameForYHDGifView:self];
        }
    }

    [self showInView:aVC.view frame:frame delegate:aDelegate];
}

/**
 *  功能:在aView中显示gif view
 *  aFrame:gif view的frame。当传入CGRectZero时，frame等于view.bounds
 */
- (void)showInView:(UIView *)aView frame:(CGRect)aFrame delegate:(id <YHDGifViewDelegate>)aDelegate {
    self.delegate = aDelegate;

    //先移除
    if (self.superview != aView) {
        [self removeFromSuperview];
    }

    //调整frame
    if (CGRectEqualToRect(aFrame, CGRectZero)) {
        self.frame = aView.bounds;
    } else {
        self.frame = aFrame;
    }

    //开始动画
    [self.gifIv startAnimating];

    [aView addSubview:self];
    [aView bringSubviewToFront:self];
}

/**
 *  功能:隐藏gif view
 */
- (void)hide {
    [self removeFromSuperview];
    [self.gifIv stopAnimating];
}

@end
