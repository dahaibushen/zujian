//
//  YHDNotConnectView.m
//  OneStoreMain
//
//  Created by 黄吉明 on 11/8/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "YHDNotConnectView.h"
#import <OTSCore/OTSEnlargeButton.h>
#import "OTSVC.h"
#import <OTSCore/OTSCore.h>

@interface YHDGifView ()

@property(nonatomic, strong) UIImageView *gifIv;//gif动画
@property(nonatomic, strong) UILabel *tipLbl;//提示语
@property(nonatomic, strong) UIButton *bottomBtn;//底部按钮

@end

@interface YHDNotConnectView ()

@property(nonatomic, strong) OTSEnlargeButton *backButton;

@end

@implementation YHDNotConnectView

DEF_SINGLETON(YHDNotConnectView)

- (id)init {
    if (self = [super init]) {
        //loading图片
        NSMutableArray *gifArray = [NSMutableArray array];
        for (int i = 0; i < 18; i++) {
            UIImage *img = [UIImage imageNamed:[NSString stringWithFormat:@"nilView_notConnect_%d", i]];
            [gifArray safeAddObject:img];
        }
        self.gifIv.animationImages = gifArray;
        self.gifIv.animationDuration = 0.8;

        //提示语
        self.tipLbl.text = @"当前网络不可用，请检查您的网络设置";

        //底部按钮
        self.bottomBtn.hidden = YES;

        //返回按钮
        [self addSubview:self.backButton];
        [self.backButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
        [self.backButton autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:25];
    }

    return self;
}

- (BOOL)willDealloc {
    return NO;
}

- (UIButton *)backButton {
    if (!_backButton) {
        _backButton = [OTSEnlargeButton buttonWithType:UIButtonTypeCustom];
        _backButton.translatesAutoresizingMaskIntoConstraints = NO;
        [_backButton setBackgroundImage:[UIImage imageNamed:@"icon_bg"] forState:UIControlStateNormal];
        [_backButton setBackgroundImage:[UIImage imageNamed:@"icon_bg"] forState:UIControlStateHighlighted];
        [_backButton setImage:[UIImage imageNamed:@"SRVC_arrow_nor"] forState:UIControlStateNormal];
        [_backButton setImage:[UIImage imageNamed:@"SRVC_arrow_high"] forState:UIControlStateHighlighted];
        [_backButton setEnlargeEdge:10];
        [_backButton sizeToFit];
        [_backButton addTarget:self action:@selector(backBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
    }

    return _backButton;
}

- (void)showInVC:(OTSVC *)aVC delegate:(id <YHDGifViewDelegate>)aDelegate {
    [super showInVC:aVC delegate:aDelegate];
    self.backButton.hidden = !aVC.navigationBarHidden;
}

/**
 * 功能:点击左按钮 返回上一页面
 */
- (void)backBtnClicked:(id)sender {
    if ([self.delegate respondsToSelector:@selector(gifView:backBtnClicked:)]) {
        [self.delegate gifView:self backBtnClicked:sender];
    }
}

@end
