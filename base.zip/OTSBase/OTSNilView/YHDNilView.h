//
//  YHDNilView.h
//  OneStoreMain
//
//  Created by 黄吉明 on 11/6/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "YHDGifView.h"

@interface YHDNilView : YHDGifView

+ (YHDNilView *)sharedInstance;

/**
 *  功能:刷新
 *  aImgs:图片数组NSArray<UIImage>，支持单图和多张图片，1x图片为200*200，注意图片内容居中100*100，周围留白
 *  aTip:提示信息
 *  aBtnTitle:底部按钮标题，nil则不显示底部按钮
 */
- (void)updateWithImgs:(NSArray *)aImgs tip:(NSString *)aTip bottomBtnTitle:(NSString *)aBtnTitle;

- (void)updateWithImgs:(NSArray *)aImgs atriStr:(NSAttributedString *)atriStr bottomBtnTitle:(NSString *)aBtnTitle;

@end
