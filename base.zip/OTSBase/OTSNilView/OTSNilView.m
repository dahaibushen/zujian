//
//  OTSNilView.m
//  OneStore
//
//  Created by huangjiming on 12/23/15.
//  Copyright © 2015 OneStore. All rights reserved.
//

#import "OTSNilView.h"
#import <OTSBase/OTSBase.h>

@implementation OTSNilView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self != nil) {
        self.backgroundColor = [UIColor whiteColor];
        [self addSubview:self.iconIv];
        [self addSubview:self.tipLbl];

        CGFloat iconSize;
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            iconSize = 150;
        } else {
            iconSize = 100;
        }

        [self.iconIv autoSetDimension:ALDimensionWidth toSize:iconSize];
        [self.iconIv autoSetDimension:ALDimensionHeight toSize:iconSize];
        [self.iconIv autoAlignAxisToSuperviewAxis:ALAxisVertical];
        [self.iconIv autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self withOffset:-iconSize / 2];

        [self.tipLbl autoSetDimension:ALDimensionWidth toSize:300];
        [self.tipLbl autoSetDimension:ALDimensionHeight toSize:40];
        [self.tipLbl autoAlignAxisToSuperviewAxis:ALAxisVertical];
        [self.tipLbl autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self withOffset:20];
    }
    return self;
}

#pragma mark - Property

- (UIImageView *)iconIv {
    if (_iconIv == nil) {
        _iconIv = [UIImageView autolayoutView];
    }
    return _iconIv;
}

- (UILabel *)tipLbl {
    if (_tipLbl == nil) {
        _tipLbl = [UILabel autolayoutView];
        _tipLbl.numberOfLines = 0;
        _tipLbl.textColor = [UIColor colorWithRed:102.0 / 255 green:102.0 / 255 blue:102.0 / 255 alpha:1];
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad) {
            _tipLbl.font = [UIFont systemFontOfSize:15.0];
        } else {
            _tipLbl.font = [UIFont systemFontOfSize:13.0];
        }
        _tipLbl.textAlignment = NSTextAlignmentCenter;
    }
    return _tipLbl;
}

#pragma mark - API

- (void)updateWithImgName:(NSString *)imgName tip:(NSString *)tip {
    UIImage *img = [UIImage imageNamed:imgName];
    self.iconIv.image = img;

    self.tipLbl.text = tip;
}

@end
