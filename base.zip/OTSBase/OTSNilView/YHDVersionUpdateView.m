//
//  YHDVersionUpdateView.m
//  OneStoreMain
//
//  Created by 黄吉明 on 1/20/15.
//  Copyright (c) 2015 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YHDVersionUpdateView.h"

#import <OTSCore/OTSCore.h>

@interface YHDGifView ()

@property(nonatomic, strong) UIImageView *gifIv;//gif动画
@property(nonatomic, strong) UILabel *tipLbl;//提示语
@property(nonatomic, strong) UIButton *bottomBtn;//底部按钮

@end

@implementation YHDVersionUpdateView

DEF_SINGLETON(YHDVersionUpdateView)

- (id)init {
    if (self = [super init]) {
        self.gifIv.image = [UIImage imageNamed:@"icon_update"];
        self.gifIv.contentMode = UIViewContentModeCenter;

        //提示语
        self.tipLbl.text = @"亲，版本太旧，该更新啦！";

        //底部按钮
        [self.bottomBtn setTitle:@"立即更新" forState:UIControlStateNormal];
        self.bottomBtn.hidden = NO;
    }

    return self;
}

/**
 *  功能:刷新
 *  aTip:提示信息
 *  aUrl:更新url
 */
- (void)updateWithTip:(NSString *)aTip url:(NSString *)aUrl {
    if (aTip.length > 0) {
        self.tipLbl.text = aTip;
    }

    self.updateUrl = aUrl;
}

@end
