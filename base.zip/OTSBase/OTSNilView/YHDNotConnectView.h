//
//  YHDNotConnectView.h
//  OneStoreMain
//
//  Created by 黄吉明 on 11/8/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "YHDGifView.h"

@interface YHDNotConnectView : YHDGifView

+ (YHDNotConnectView *)sharedInstance;

@end
