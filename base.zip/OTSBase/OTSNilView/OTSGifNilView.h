//
//  OTSGifNilView.h
//  OTSCommon
//
//  Created by HUI on 16/6/29.
//  Copyright © 2016年 OTSCommon. All rights reserved.
//

#import <OTSBase/OTSBase.h>
#import "FLAnimatedImageView.h"

@protocol OTSGifNilViewDelegate <NSObject>

- (void)gifNilViewRefresh;

@end

@interface OTSGifNilView : UIView
@property(nonatomic, strong) FLAnimatedImageView *nilGifImgView;
@property(nonatomic, strong) UIButton *nilHomeBtn;
@property(nonatomic, strong) UIButton *refreshBtn;//刷新按钮
@property(nonatomic, strong) UILabel *nilInfoLabel;
@property(nonatomic, weak) id <OTSGifNilViewDelegate> nilDelegate;
@property(nonatomic, strong) NSLayoutConstraint *widthLayoutContraint;
@property(nonatomic, strong) NSLayoutConstraint *heightLayoutContraint;

- (void)setNilInfo:(NSString *)nilInfo gifImgName:(NSString *)gifImgName;
@end
