//
//  OTSNilView.h
//  OneStore
//
//  Created by huangjiming on 12/23/15.
//  Copyright © 2015 OneStore. All rights reserved.
//

#import <UIKit/UIkit.h>

@interface OTSNilView : UIView

@property(nonatomic, strong) UIImageView *iconIv;
@property(nonatomic, strong) UILabel *tipLbl;

- (void)updateWithImgName:(NSString *)imgName tip:(NSString *)tip;

@end
