//
//  YHDDetailNilView.h
//  OneStore
//
//  Created by huang jiming on 13-4-10.
//  Copyright (c) 2013年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    PhoneNilViewType_Detail,          //购物车空态

} YHDDetailNilViewType;

@protocol YHDDetailNilViewDelegate <NSObject>

@optional
- (void)reflushBtnClicked;
@end

@interface YHDDetailNilView : UIView

@property(nonatomic, strong) UIImageView *picIv;//图片
@property(nonatomic, strong) UILabel *mainTextLbl;//图片下面文字
@property(nonatomic, assign) YHDDetailNilViewType type;//空态类型
@property(nonatomic, strong) UIButton *nilTypeButton;
@property(nonatomic, strong) UIButton *reflushButton;//刷新按钮

@property(nonatomic, weak) id <YHDDetailNilViewDelegate> delegate;

@end
