//
//  YHDNilView.m
//  OneStoreMain
//
//  Created by 黄吉明 on 11/6/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "YHDNilView.h"

#import <OTSCore/OTSCore.h>

@interface YHDGifView ()

@property(nonatomic, strong) UIImageView *gifIv;//gif动画
@property(nonatomic, strong) UILabel *tipLbl;//提示语
@property(nonatomic, strong) UIButton *bottomBtn;//底部按钮

@end

@implementation YHDNilView

DEF_SINGLETON(YHDNilView)

/**
 *  功能:刷新
 *  aImgs:图片数组NSArray<UIImage>，支持单图和多张图片，1x图片为200*200，注意图片内容居中100*100，周围留白
 *  aTip:提示信息
 *  aBtnTitle:底部按钮标题，nil则不显示底部按钮
 */
- (void)updateWithImgs:(NSArray *)aImgs tip:(NSString *)aTip bottomBtnTitle:(NSString *)aBtnTitle {
    //图片
    if (aImgs.count > 1) {
        self.gifIv.animationImages = aImgs;
        self.gifIv.animationDuration = 0.8;
    } else {
        UIImage *img = [aImgs safeObjectAtIndex:0];
        self.gifIv.image = img;
        self.gifIv.contentMode = UIViewContentModeCenter;
    }

    //提示语
    self.tipLbl.text = aTip;

    //底部按钮
    if (aBtnTitle.length > 0) {
        [self.bottomBtn setTitle:aBtnTitle forState:UIControlStateNormal];
        self.bottomBtn.hidden = NO;
    } else {
        self.bottomBtn.hidden = YES;
    }
}

- (void)updateWithImgs:(NSArray *)aImgs atriStr:(NSAttributedString *)atriStr bottomBtnTitle:(NSString *)aBtnTitle {
    //图片
    if (aImgs.count > 1) {
        self.gifIv.animationImages = aImgs;
        self.gifIv.animationDuration = 0.8;
    } else {
        UIImage *img = [aImgs safeObjectAtIndex:0];
        self.gifIv.image = img;
        self.gifIv.contentMode = UIViewContentModeCenter;
    }

    //提示语
    self.tipLbl.attributedText = atriStr;

    //底部按钮
    if (aBtnTitle.length > 0) {
        [self.bottomBtn setTitle:aBtnTitle forState:UIControlStateNormal];
        self.bottomBtn.hidden = NO;
    } else {
        self.bottomBtn.hidden = YES;
    }
}

@end
