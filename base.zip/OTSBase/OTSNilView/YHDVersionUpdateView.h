//
//  YHDVersionUpdateView.h
//  OneStoreMain
//
//  Created by 黄吉明 on 1/20/15.
//  Copyright (c) 2015 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YHDGifView.h"

@interface YHDVersionUpdateView : YHDGifView

@property(nonatomic, strong) NSString *updateUrl;//版本更新url

+ (YHDVersionUpdateView *)sharedInstance;

/**
 *  功能:刷新
 *  aTip:提示信息
 *  aUrl:更新url
 */
- (void)updateWithTip:(NSString *)aTip url:(NSString *)aUrl;

@end
