//
//  OTSGifNilView.m
//  OTSCommon
//
//  Created by HUI on 16/6/29.
//  Copyright © 2016年 OTSCommon. All rights reserved.
//

#import "OTSGifNilView.h"
#import "FLAnimatedImage.h"

@interface OTSGifNilView ()

@end

@implementation OTSGifNilView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        [self setupMainView];
        WEAK_SELF;
        self.nilGifImgView.loopCompletionBlock = ^(NSUInteger loopCountRemaining) {
            STRONG_SELF;
            [self.nilGifImgView stopAnimating];
        };

    }
    return self;
}

- (void)setupMainView {
    [self addSubview:self.nilGifImgView];
    [self addSubview:self.nilInfoLabel];
    [self addSubview:self.nilHomeBtn];
    [self addSubview:self.refreshBtn];

    [self.nilInfoLabel autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self withOffset:UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? 90 : 50];
    [self.nilInfoLabel autoAlignAxisToSuperviewAxis:ALAxisVertical];
    [self.nilInfoLabel autoSetDimension:ALDimensionHeight toSize:40];

    [self.nilGifImgView autoSetDimensionsToSize:UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? CGSizeMake(200, 200) : CGSizeMake(120, 120)];
    [self.nilGifImgView autoPinEdge:ALEdgeBottom toEdge:ALEdgeTop ofView:self.nilInfoLabel withOffset:-10];
    [self.nilGifImgView autoAlignAxisToSuperviewAxis:ALAxisVertical];

    [self.nilHomeBtn autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.nilInfoLabel withOffset:10];
    [self.nilHomeBtn autoAlignAxisToSuperviewAxis:ALAxisVertical];
    self.widthLayoutContraint = [self.nilHomeBtn autoSetDimension:ALDimensionWidth toSize:80];
    self.heightLayoutContraint = [self.nilHomeBtn autoSetDimension:ALDimensionHeight toSize:25];

    [self.refreshBtn autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.nilInfoLabel withOffset:80];
    [self.refreshBtn autoAlignAxisToSuperviewAxis:ALAxisVertical];
    [self.refreshBtn autoSetDimensionsToSize:CGSizeMake(140, 40)];
    self.refreshBtn.hidden = YES;

}

#pragma mark - properties

- (UILabel *)nilInfoLabel {
    if (_nilInfoLabel == nil) {
        _nilInfoLabel = [UILabel autolayoutView];
        _nilInfoLabel.font = [UIFont systemFontOfSizeForiPhone:14 iPad:16];
        _nilInfoLabel.textColor = rgb(117, 117, 117);
        _nilInfoLabel.textAlignment = NSTextAlignmentCenter;
        _nilInfoLabel.text = @"是空哒~快去买买买";
        _nilInfoLabel.numberOfLines = 2;
    }
    return _nilInfoLabel;
}

- (UIButton *)nilHomeBtn {
    if (_nilHomeBtn == nil) {
        _nilHomeBtn = [UIButton autolayoutView];
        _nilHomeBtn.backgroundColor = [UIColor redColor];
        _nilHomeBtn.layer.cornerRadius = 5;
        _nilHomeBtn.layer.masksToBounds = YES;
        _nilHomeBtn.titleLabel.font = [UIFont systemFontOfSizeForiPhone:14 iPad:16];
        [_nilHomeBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_nilHomeBtn setTitle:@"去逛逛" forState:UIControlStateNormal];
        [_nilHomeBtn addTarget:self action:@selector(goToHomePage) forControlEvents:UIControlEventTouchUpInside];
    }
    return _nilHomeBtn;
}

- (UIButton *)refreshBtn {
    if (_refreshBtn == nil) {
        _refreshBtn = [UIButton autolayoutView];
        _refreshBtn.backgroundColor = [UIColor redColor];
        _refreshBtn.layer.cornerRadius = 3;
        _refreshBtn.layer.masksToBounds = YES;
        _refreshBtn.titleLabel.font = [UIFont systemFontOfSize:16];
        [_refreshBtn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_refreshBtn setTitle:@"刷新" forState:UIControlStateNormal];
        [_refreshBtn addTarget:self action:@selector(gifNilViewRefresh) forControlEvents:UIControlEventTouchUpInside];
    }
    return _refreshBtn;
}

- (FLAnimatedImageView *)nilGifImgView {
    if (_nilGifImgView == nil) {
        _nilGifImgView = [FLAnimatedImageView autolayoutView];
    }
    return _nilGifImgView;
}

- (void)setNilInfo:(NSString *)nilInfo gifImgName:(NSString *)gifImgName {
    if (gifImgName.length) {
        NSString *gifPath = [[NSBundle mainBundle] pathForResource:[NSString stringWithFormat:@"%@", gifImgName] ofType:@"gif"];
        FLAnimatedImage *aniImage = [[FLAnimatedImage alloc] initWithAnimatedGIFData:[NSData dataWithContentsOfFile:gifPath]];
        self.nilGifImgView.animatedImage = aniImage;
    }

    self.nilInfoLabel.text = nilInfo;
}

- (void)setHidden:(BOOL)hidden {
    [super setHidden:hidden];
    if (!hidden) {
        [self.nilGifImgView startAnimating];
    }
}

- (void)goToHomePage {
    [[OTSRouter sharedInstance] routeToHomePage];
}

- (void)gifNilViewRefresh {
    if ([self.nilDelegate respondsToSelector:@selector(gifNilViewRefresh)]) {
        [self.nilDelegate gifNilViewRefresh];
    }
}

@end
