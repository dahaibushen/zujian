//
//  YHDGifView.h
//  OneStoreMain
//
//  Created by 黄吉明 on 11/8/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YHDGifView;
@class OTSVC;

@protocol YHDGifViewDelegate <NSObject>

@optional
/**
 *  功能:gif view的frame
 */
- (CGRect)frameForYHDGifView:(YHDGifView *)aView;

/**
 *  功能:点击底部按钮
 */
- (void)gifView:(YHDGifView *)aView bottomBtnClicked:(id)sender;

/**
 * 功能:点击左按钮返回之前页面
 */
- (void)gifView:(YHDGifView *)aView backBtnClicked:(id)sender;
@end

@interface YHDGifView : UIView

@property(nonatomic, weak) id <YHDGifViewDelegate> delegate;

/**
 *  功能:在aVC中显示gif view，若是有navi bar和tool bar，gif view不会遮挡navi bar和tool bar，支持delegate自定义frame
 */
- (void)showInVC:(OTSVC *)aVC delegate:(id <YHDGifViewDelegate>)aDelegate;

/**
 *  功能:在aView中显示gif view
 *  aFrame:gif view的frame。当传入CGRectZero时，frame等于view.bounds
 */
- (void)showInView:(UIView *)aView frame:(CGRect)aFrame delegate:(id <YHDGifViewDelegate>)aDelegate;

/**
 *  功能:隐藏gif view
 */
- (void)hide;

@end
