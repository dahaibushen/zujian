//
//  YHDDetailNilView.m
//  OneStore
//
//  Created by wudepeng on 14-9-10.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "YHDDetailNilView.h"
#import <OTSCore/UIFont+OTS.h>

@implementation YHDDetailNilView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithRed:250.0 / 255.0 green:250.0 / 255.0 blue:250.0 / 255.0 alpha:1.0];

        CGFloat yValue = (frame.size.height - 280) / 2;

        self.picIv = [[UIImageView alloc] initWithFrame:CGRectMake([[UIScreen mainScreen] bounds].size.width / 2 - 48, yValue, 96, 97)];
        [self addSubview:self.picIv];
        yValue += 100.0;

        self.mainTextLbl = [[UILabel alloc] initWithFrame:CGRectMake(0, yValue, self.frame.size.width, 40)];
        self.mainTextLbl.backgroundColor = [UIColor clearColor];
        self.mainTextLbl.numberOfLines = 2;
        self.mainTextLbl.textColor = [UIColor colorWithRed:170.0 / 255.0 green:170.0 / 255.0 blue:170.0 / 255.0 alpha:1.0];
        self.mainTextLbl.font = [UIFont systemFontOfSizeForiPhone:12 iPad:14];
        self.mainTextLbl.textAlignment = NSTextAlignmentCenter;
        [self addSubview:self.mainTextLbl];
        yValue += 55.0f;

        self.nilTypeButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.nilTypeButton.frame = CGRectMake(89, yValue, 142, 41);
        self.nilTypeButton.titleLabel.font = [UIFont systemFontOfSizeForiPhone:12 iPad:14];
        [self.nilTypeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [self.nilTypeButton setBackgroundImage:[UIImage imageNamed:@"niltype_button"] forState:UIControlStateNormal];
        [self.nilTypeButton setBackgroundImage:[UIImage imageNamed:@"niltype_button_sel"] forState:UIControlStateHighlighted];
        [self addSubview:self.nilTypeButton];
        self.nilTypeButton.hidden = YES;

        self.reflushButton = [[UIButton alloc] initWithFrame:CGRectMake([[UIScreen mainScreen] bounds].size.width / 2 - 50, yValue, 105, 40)];
        [self.reflushButton setBackgroundImage:[UIImage imageNamed:@"niltype_button"] forState:UIControlStateNormal];
        [self.reflushButton setTitle:@"刷新" forState:UIControlStateNormal];
        [self.reflushButton addTarget:self action:@selector(reflushBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:self.reflushButton];

    }
    return self;
}

- (void)setType:(YHDDetailNilViewType)aType {
    switch (aType) {
        case PhoneNilViewType_Detail:
            self.picIv.image = [UIImage imageNamed:@"nil_search"];
            self.mainTextLbl.text = @"无结果";
            break;
        default:
            break;
    }
}

- (void)setFrame:(CGRect)aFrame {
    [super setFrame:aFrame];

    CGFloat yValue = (aFrame.size.height - 140) / 2;

    self.picIv.frame = CGRectMake([[UIScreen mainScreen] bounds].size.width / 2 - 48, yValue, 96, 97);

    yValue += 100.0;
    self.mainTextLbl.frame = CGRectMake(0, yValue, self.frame.size.width, 40);
}

- (void)reflushBtnClicked:(id)sender {
    if ([self.delegate respondsToSelector:@selector(reflushBtnClicked)]) {
        [self.delegate reflushBtnClicked];
    }
}

@end
