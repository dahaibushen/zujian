//
//  HCIModel.h
//  OTSBase
//
//  Created by liuwei7 on 2017/8/18.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HCIModel : NSObject

- (void)setValue:(NSString *)value forKey:(NSString *)key;

- (NSString *)toString;

@end
