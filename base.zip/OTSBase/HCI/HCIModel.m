//
//  HCIModel.m
//  OTSBase
//
//  Created by liuwei7 on 2017/8/18.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "HCIModel.h"
#import <CommonCrypto/CommonCryptor.h>
#import "OTSClientInfo.h"

@interface HCIModel ()

@property(atomic, strong) NSMutableDictionary *hciTokens;

@end

@implementation HCIModel

- (instancetype)init {
    if (self = [super init]) {
        self.hciTokens = [NSMutableDictionary dictionary];
        [self.hciTokens setValue:[OTSClientInfo sharedInstance].traderName forKey:@"aon"];//系统aon
        [self.hciTokens setObject:[OTSClientInfo sharedInstance].clientVersion forKey:@"aov"];//系统版本号aov
        [self.hciTokens setValue:[OTSClientInfo sharedInstance].deviceCode forKey:@"dc"];//获取UUID
        [self.hciTokens setValue:[OTSClientInfo sharedInstance].clientAppVersion forKey:@"av"];//版本号 av
        [self.hciTokens setValue:[OTSClientInfo sharedInstance].nettype forKey:@"nt"];//网络类型nt
        //定位位置g
        [self.hciTokens setValue:[NSString stringWithFormat:@"%@,%@", [OTSClientInfo sharedInstance].latitude, [OTSClientInfo sharedInstance].longitude] forKey:@"g"];
        if ([OTSClientInfo sharedInstance].latitude.integerValue == 0 || [OTSClientInfo sharedInstance].longitude.integerValue == 0) {
            [self.hciTokens setValue:@"" forKey:@"g"];
        }
        //真机/模拟器
        if (TARGET_IPHONE_SIMULATOR) {
            [self.hciTokens setValue:@"1" forKey:@"e"];
        } else {
            [self.hciTokens setValue:@"0" forKey:@"e"];
        }
    }

    return self;
}

- (void)setValue:(NSString *)value forKey:(NSString *)key {
    [self.hciTokens setValue:value forKey:key];
}

- (NSString *)toString {
    //转成json格式
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self.hciTokens options:0 error:nil];
    NSString *hciTokenString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];

    //base64
    NSString *hciString = [NSString stringWithFormat:@"%@", hciTokenString];
    NSData *hciData = [hciString dataUsingEncoding:NSUTF8StringEncoding];
    NSData *hciBase64 = [hciData base64EncodedDataWithOptions:0];

    //reverse
    NSMutableData *hciTokenData = [[NSMutableData alloc] init];
    NSData *mdata;
    for (NSInteger i = hciBase64.length; i > 0; i--) {
        mdata = [hciBase64 subdataWithRange:NSMakeRange(i - 1, 1)];
        [hciTokenData appendData:mdata];
    }

    //tripLeDES加密
    NSString *desKey = @"3Bq4z2p0eUJ7eDndWPDoQ2wI";
    size_t plainTextBufferSize = [hciTokenData length];
    const void *vplainText = (const void *) [hciTokenData bytes];
    CCCryptorStatus ccStatus;
    uint8_t *bufferPtr = NULL;
    size_t bufferPtrSize = 0;
    size_t bufferOutLength = 0;
    bufferPtrSize = (plainTextBufferSize + kCCBlockSize3DES) & ~(kCCBlockSize3DES - 1);
    bufferPtr = malloc(bufferPtrSize * sizeof(uint8_t));
    memset((void *) bufferPtr, 0x0, bufferPtrSize);
    const void *vkey = (const void *) [desKey UTF8String];
    //偏移量
    const void *vinitVec = nil;
    //配置CCCrypt
    ccStatus = CCCrypt(kCCEncrypt,
            kCCAlgorithm3DES, //3DES
            kCCOptionECBMode | kCCOptionPKCS7Padding, //设置模式
            vkey,  //key
            kCCKeySize3DES,
            vinitVec,   //偏移量，这里不用，设置为nil;不用的话，必须为nil,不可以为@“”
            vplainText,
            plainTextBufferSize,
            (void *) bufferPtr,
            bufferPtrSize,
            &bufferOutLength);

    NSString *hciTokenTripleDESString = nil;
    if (ccStatus != kCCSuccess) {
        return nil;
    } else {
        NSData *myData = [NSData dataWithBytes:(const void *) bufferPtr length:(NSUInteger) bufferOutLength];
        hciTokenTripleDESString = [myData base64EncodedStringWithOptions:0];
    }
    if (bufferPtr) {
        free(bufferPtr);
    }

    return hciTokenTripleDESString;
}

@end
