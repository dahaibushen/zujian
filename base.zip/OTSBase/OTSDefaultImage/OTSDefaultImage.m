//
//  OTSDefaultImage.m
//  OneStoreBase
//
//  Created by liuwei7 on 09/06/2017.
//  Copyright © 2017 OneStoreBase. All rights reserved.
//

#import "OTSDefaultImage.h"
#import <CommonCrypto/CommonDigest.h>

static NSString *common_otsd_72px_base64 = @"iVBORw0KGgoAAAANSUhEUgAAAEgAAABICAYAAABV7bNHAAALKUlEQVR4nN2ce5RVVR3HP/dyGXk4Ag7ig8RBcERkRCupAMFQcelYC1uSIKloKUVJ6SKtMHvY8o+wErGQNFERRTJjkWL5QDBYLa10CiFQwJEUDQZ5DaAI3P74nuPZZ5/HPefOvXcYv2vNmnPO3Wc/fmfv33vvTFNTExVEB+B0YDBwMlAH9AdqgMOBaqfcLqAF2AqsA14D1gL/AhqBA5XqcK4CbRwPXAycA4wAuid4p9r5OxYYZP22HXgBeA54DNhUsp6GIFOmGdQJuBS4GjgLyJSjETSTngXmAn8A3i91A6UmUDdgCvAtoFcpK06AzcBdwJ3AjlJVWioCVQHXAdOAHgXKNqMlsgpYg/jLu2hQu5wy1YjYxyA+NQA4FS3RngXqfw+4DZgJ7Es5jgBKQaDPA7OBk2LKvAI8AjwN/BvIF9lWBjgNOA8YD3wypuzrwCTg+SLbUoOtIFAX4Hbg64TzmBbgHmAOsLLYRgqgHpgIXIukoI08cDcwFdhTTAPFEqgOMUVbwoCWykzgDiSmK4Ea4NtomYdJyVXAl9ByToVsEZ0ZDbxEkDgH0VLrD/yQyhEHp61b0DKf7fTFxKnA31HfUyEtgS4HnkQM1MQGYCRabs1pO1FCNDt9GAmst347AvX9yjQVpiHQNcADBJXL+cAZwPI0DZcZyxEDn289zyGeeE3SipISaCwwCz8zzgM3ImmyM2mDFcRO1Lcb8S+5DBrLl5NUkoRAo4CHkB3lYh9wGTA9SSNtjOnABPw6UQekfY8q9HIhAtUBjyNF0MUBZEbY0/dQxnzUZ9PIrUJjq4t7MY5AXZAoNxlyHukdC4vpZRtjIWLQppLaDY2xS9RLcQSaTlCUT0PLrb1iHvAD69kgYlhFlKI4HNlLJlNeiJStYs2EQwUZtLTGGM/yyM4LSOKwGZQDfoOfOE3AVbR/4oDGcDUak4sMGnPAPxZGoCnIxjErnIgcVR8XbENjMj94PRq7DzaBuiE+Y+IhYFkJO3eoYBlBfnozlpVgE+g64Ejjfgfw3ZQNH4+s+ChkEC97AngLmQeNyIdzbMq2XKxHs+GBlO9Nxe9c64E1i0wCdUYWsYmZwP9SNHgC+jIDIn4/HPgjEq0NQG9kiQ8Gvo8caA0p2nOxHS2b3Snf24w8kCamIFoAfil2JXC/UbAFqCW5VV6LnFO1SBqcZf2eRbPmAuf+PWQ8bgU+jSQnSOMdTeWWdQ1i2KY/aSLObDRn0FetF39LcuKciAZUG1NmAh5xFgH9gCuA6xExG5BTq8pp25Yo56NlVMxfnIdhq9Oeia+5Fy6B+uB9QZxKZ8dUaqIfsNSpIw7fdP5vQEakLRUXA99xruuAC63fWxOiKvTubPwSbRjOeNwXx+DXe14kmfetDliCeEkcOgFDnOs5RLs/HwR+BXRFH2xRRLl5iMG7+Aby96wG/hRSvlCU4zU05s869xkUy5vhEshmjI8VqBAUGV0CHJegbE+8D7AhptwHwDvIK3lUTLm78Wu94xGBGoHvJehPGH6PRyDQDJ6RRbNouFX4yQKVnYKWVRLigHiAO4X7xpQ7DDjaeKeSWGzdDwc6ZpHnzbRm30biNgoDkbQ6JkXj7yOfMMhkOSyi3Ffw4vNLU9RfCqxBY3fRBTgji5IJTPwtppJ61PGjY8pEYZbzvx+KkdlhmvOBXzjX61AMrdKwx356jqBLozGmgqvwvuzYlI3PRbxiNGKA65FetB3N4rOdcgeAycCHKesHLYsF1rODSMf7IMH7jcAlxn19Dn1RE/+JqeAG4zqtZX/AaXw+YoC9kFVtYhfSjZ5JWbeLPoSrG5NIRiCbtfTNhVT4ZhEdS4pdwEXAF1FkYQjiOU1IpN+BpFixeBd41Xp2gORZH03WfZ8cwWSA1nQwDEcQjNu/BfwopOxx+CXjbuIFho0lSGMvFvbYj8oRZJa7KC0uw2PQabERGcCVgh2+6pql/AQqV/JUOdBi3VfnkPVcFVK4VFiNtNQwNCB9YyNS9W2YU36jUU8aF0waBOiQQzOmxnhWTWln0TKiXRdvIiHRhCKgTTH1rCQYDe2IDEt3FdQiLT9OEseh2rpvyRIyrYqsvDUYAbyBxPtpCcpnUE7QeqTVu17QoWjG/sOpMy1sdtOSJeh2KNbtWQqci1JrxseUqUIeydnIvRuGTyHCXZ+yfVuib8nitz+gslJjGBLr5yAP3kFkp811noXhPqSJgwzam9Cs64006V8jvpoFfonsu6Swx/7fHME8mlNSVNhauD6dd5AO8zhixFWIECfhTzpowNNzXkYeys3G75uAFcjWc/OY7gKeIpl31B77hixBzdM2XiuJRSg7DcS8x1m/u76e3WgWbSYcK5A9ByLSpITt2/xvZZagcfq5hJWVC2ae80XG8yPx+nY/EvtxeATPOfeFhG0Pte4bsyhF13SB9iY6bFMJmL4jc8r3w8tReiFBPXk89SI2xcXBAOATxv0e4JUscivYQftiYlNRGIXE9zNESx0b7gzqbDwzRbCtmkTBNR26JihrBwmWAx+6UQ3bxXoJpUMeie9zgTMTvnOy89/UpE1pm2RGmOWSGOC2f2sxeGGfhfj9O59J0YlCeBnPF3N5gvKD8Zx4pvmxDrkzQAZwIRuvN16KXZgZY6IOjdlFHkWAPyLQRsT5XWRIzvkLYQdeRtoY/Hk5NjrhxfXz+CO9B/HS/s7Ei7OFoQOKfLi+7zkF+ngtfoKvwBECZmT13pCXaigNpgF7nev5KEnCDub1R1ub3GV4H0EV5DZgi3M9A/gpfj4FmjkL8STgs8BfYvpWQ3Ay/M69MGPznRHVTHX7VpTBHoY4l2tYbH4C0pZdSbQJSaPdSCEcZvz2IloeYQHGkcCf0WwDKYBLUay/L7LBXKt8HRLdW4jGT/CPsRnpYHshmIJ3i/OCix1ofYYpZGkJBHK13kt8UHABcsfG5V4PQXrOiTFlnkM8L45B90JRVTMn6McYNLDzg2agNBIX3dCOnjDEqe5Rg1uEBjUVEbEF8ZaNwMPo618a876Ll5CONBnpOq5asAkx1wuR1CwkvW7HT5xtyC/+EcKSOG/Ai0+BZsrZJFPO2hNGoKVpMuep+MceSqAcEs1mnuIbKHb1cclT7I4siFrj2Uo0xv1mwbAkzv1IhJo8pi+SKu3JvxyFDBpLrfEsj8a83y4clUj+V4KRiIuR76W94yY8f5KLWWjMAcTtOOyCjMaBxrM8kgzzWtXFtsME5IwzV8JqpHuF5izFbUXYg7JRzeSjDNJu47ThQxVjkEZtEmcHGmPkftZCu33WOhWYXr0c8CgSx+0FY1GfOxrP9qGxrY17Mcl+sSVoWdlbiR4mfQ51W2AqMm/sLV1XoLHFIumOwwUoD9CUbFng50ijbYtQUSFUo484Hf8482gsjyapJM2e1XtQno0tCschnaKYOFS5MAL1yQ4f7Uc5TnE7AXxIu+t5LvI22qaAmwr8IMVln5UKvZBBvJRg3tNOZOGn2q5QzL75p5GxuMp6nkG8ag1yQ5TKVZIENcjAXIt4i63QrkJ9jnN7hKIYAuF0ZAhSsGyrvjsK3TQhu6ae8qHeaaMJeSLsUxfyTh+HUEBaRaEUh5uMQt67uMNN/okkyROkS4gKwwC0zMejEHMUXkeHDBSUVHEo9fE4N1P4hKm3UTbpavzH42xDCltHFMHo4fy5x+MMRHGxQln924GfcQgdj2PC3W81mbY5YGkWQZ9Wq1DOI7rGoV0zQynvEV3PI/OnXRzRFYYTkPV8AXLD2k72tNiLLO+nkALbLg95i0JHdBDKIPzHBPZE2bDulog9SG9pxn9M4KtIASwmybwo/B/g0Y5upWToVgAAAABJRU5ErkJggg==";

static NSString *common_otsd_108px_base64 = @"iVBORw0KGgoAAAANSUhEUgAAAGwAAABsCAYAAACPZlfNAAARMElEQVR4nO2de5RdVX3HP7kzmZBAGCIJnaA0YUBoEknELKUkQAcqglYQS4kx2NBY0JqoSxBLoK1WqCBLURQDVBAhViEBlaWCiAoCEkQq0ICJlhAHfKVMEhgY8pwk/eN7jrPPb597z/PeuQn3s9ZdM+fc89hn/+7Zj99rj+jt7WU3og3oBmYAhwCTgT8HJgSfTqAdGBsc/xIwCPQDfcHnWaAXeBr4H2AtsKNB5S9M+3AXIIExwF8BxwGzgZnBvrSEghuHhBvHJuAXwArgvuCzKUdZG8KIJnzDuoC/A05BgtqrwfffAtwP3A4sAzY2+P41aRaBjUJCWgD0oKavGdgK3AncFPzdPrzFGX6BHQh8GDgHeFXKc9ajvueXqP/pBdYBG4LPdmAgOHYfYCSwf/DpQk1jNzANmI76vjRsBK4Dvgj8IeU5pTNcAusG/hU4E+hIOPaPwL3APcHftXUoy/HACcHfiQnHbwNuBi6uQ1kSabTAJgKfBP4B/fKr8TjqP74DrKp/sSJMBU4F3gW8vsZx24EbgU+gH1VDaJTAOoCPAhehZiqOjcBS4HrU3DUD04CzgflUb7IHgMuAz6K3r640QmCzUNs/tcr3a4DPoY69WYfTY4CzgPOAQ6scswr1xSvqWZBKHa89CrgCeIB4Ya1FlTAFuIbmFRaobNcAf4HKHNd3TUXPegV69rpQrzdsCnALGoVZXgD+A7iKBjQhdaID+BAaOO0X8/1KYC6wuuwb1+MNmwP8nHhhLQVei36Fu6uwQGW/Aj3L0pjvp6M6mFP2jcsU2AjU+d6CP7D4LXASak7Wl3jP4WY9eqaT0DO67IPq4jJUN6VQlsD2QoVbjF+45UhZe3dJ92pG7kbPuNzsH4HqZBklqdjKENhY4Pv4r/924INoPvN8Cfdpdp5Hz/pBfBXWGaiOxtqTslJUYJ3o19Vj9j8X7FtS8Pq7I0vQsz9n9vcAPyR+kJKaIgIbC/wA+Euz/3/R3Kuu85EmZwWqg1+b/UcBd1HgTcsrsNFIbXSU2f8osls9nbdAexBPA8egOnE5CtVdFrven8gjsBFIc9Fj9j+EFKh70iiwKOtRndjWpgfVYebRYx6BXYq07C6PAm9FpvgWUfqBtyGrtss8VJeZyCqwM4ALzL41wMm0hFWLfvSDfsrsvwDVaWqyCGwKcAPR17gvKEhflpu+QukDTiRaVyOAr1JdMe6RVmCj8DUY24B3ojesRTqeQXXmquX2RgbRVArjtAK7FF83eD7wYMrzWwzxIKo7l+mk7M/SaOtnIbOBK9zbyNj2tvBYTrQOdwLHkjB/TRLYKDQCdNvY3yK92StB3VRPxiFnooOcfauANyBvrViSmsRz8TvEs2kJqwyeR3XpMhXVeVVqCawLuNDsW8qerXVvNHfj29MuQnUfSy2BXQzs62y/gN9ZtijO+ahuQ8aiuo+lmsC6kSuay8XUZ741EfmzZ6Ub+DfgR8CvkNfVM0gh/c/Aq8sqYAwvAbuCT1FflD7k+ueyAAV7eFQbdNwQnBSyFjmglO2qfBCq8D8jvdlhAnrAc6gdzLEZuBr90F4sUMY4dpntohblkehH1+3su5GoDID4N+xAfF3hJylfWAejoIPDMpwzE3gM+ADJkTejkS/kf2e8RxpcNdxLJVxvO/5bNo/oCBKIF9i5RN2n1wBfL6FQLoehZnByhnNeB/yY+KZuF9VHrq8NzstyryT2Q2/VCKL9fBG+TlRr1IHiDiLYJnEv4PdEvVwXoaalLKagCnR92Pup3STuhdy3Dzf7vwdcid7U7cFxx6M+rMcc+zNkn6oWvFdBDjW1XMiL0Ad8O+GYhUSt9BvRD3RLuMMKbB7Rt2kDei03Fyioy3RkJj/A7E8S2GLkfRSyA3g/8JUa51wAfNrsO7vGOZ1ER2tl8ywwKeGY0cDviL4w78GRiW0S/9Fsf43yhDUTRaBYYSXRDnzE7LuQ2sICuBz4vNn3oYz3bjSb8edl73U3XIF1ofBUl6RKScvRqBncP8e5s9AoMuQp5Iufho8TnYrMIDoSa0ZsnffgTKTdkdbpRCMfHweeLKEAxwJ3kN/xxPqNfIP0QeQDSFH9AWffm0gX1/Ui8qePwxpxL09xPetoWo0n0Uj4yGC7gpTEV0FUYKeaE5elvEEt/poCDicBdlSY1V/dei4dmPK8F1DfGYcVWLXj8rKcIYGB4r2vgqEmcR/85vD2gjd9G/BdigkL/EnpltijqjNothsd5J4HO5o8jsB4XHF2uBbPp9HMOy+nBTcdXeAaIevMdmpzeoBV8fxfgbI0il8TdRUcRfBChQI71pzwwwI3m4Ne6aTY5bQ8FnP9tHSgvtnlZ8WK0zCsVeQYGBLYbPPl/Tlv8h40KChz8vkTolqM12OGujU4F2XKCXmK5gnHTeIBsz0LJLA2NEdyyeNmfTZSWJadY2ML8GWz70vIta4Wc4BPmX1XllWoBmD9ZWYCbRUUs+sODPqQmSILi1Cl1ishymVIZRYyGqmlluArdqegCf8tpjyr8QVfFuMSPnkcdp8lOofcGzi0HTjCHPhEjou3E7VOTwb+Kcd1qtEPvBuZYsK+sQ3p3haitAvr0QQ7TpPSj944O2Isi6T0Rufha13S8ARy9Q45oh0/Kj5PG/8Fs30M5QoM1Ka/Aw1o7CR8ItUTovwBjVrLUALkJW+Q+pNEBXZoBd/s0MyRJ3chr6I7Uxy7C03+3wg8Us9C1RGrkZncjq9B7m1MWXKzBvgbpJ+ci+KLJ6EJ8SAaCd6BvGltqE+9uDXhezs1SctvzPakdmC82dmwNDwFeSj4hOzLkK9Foyk9W0CAVRqMb8fXoDdLfsAzqK938XUUUxA0gg1me3w7fg4le9BwcTz1FdijNL/A7MszroI/R6jX0LdFdqzjU1sFf4hchhdQi3IYMNv7NHOS5l+giXISXcijKmQd6eZc1hqxFU0bwjoZtqyjtWhHb5T7lo2lOd6yr5DORcE6Dt2D71eZhi0omrSZsCmgBiooLsmlWRIk56UHJe46jhJzPDGUnzjOsHsbUpHZKVJRbAu4o0LMSKTkmzaaA5Hu7j7UNJ5W8HoTUfLNXqSCe0fMMacjRfQzKIlzVs+wanSa7ecr+MP4PJ5NzcpUZPleRj4noNOR0OeTzsY3BrnSrcb3kcmDzfi9oYKfCKWeUR/1wDbpccxBb1zalOcg4+etpE/P7vIq9EM5J8e5Llah3VfBt31NLniTRnM78BqkmjoY+Ftk9bbzySNRJabpo89Cvo+2D1yF4rlmoJZoAlJGL8bPwVEBrgXenvI54rA+lM9U8JW9sXFJTcwWZNx8CT3Lt9EocQa+0nU2iimrxSH4Wei2okHFEWhAsxL1/euDe1yOmt/zif5QKih0q2pEZQJWYL0V/Dwb03JevNlYhZyL7FzuQmLCeBw+i6y7IZtQQpRrqN38DiJhnkI0D8cE4N9TldjHymJNBd/CbC3QuzMvozVdnnX2dVA99HcK/ihwIb5DTC3uAj5m9i0gvQOri82N8kT4hrkBDxNIjrLYnehH4Ucuc4mfo51p9j9CfBLmJK4muqJFB+pbsxCuixbyMsEbtgNFKbrMylrCJuebRB1aDiB+mY4TzPa15LOvDaIVLlySvLws1vXwUYKJM/guVcdlvHizM4gf+D4j5jjr3/L9Ave8K8X9amGde1fAkGnlp+bLEzNefHfA+kfYkZu1vm+mmPXdDuayaj/eYrZ/CkMCu49oupxDUNaA4eTjDKVW2IWfNSYrVlNhR3wjifZf7RTTRRZxVT+c6PRqK/KA/pPABvCbjKI6uKLYfEtxK01kwQ7lbc6RzUTtTyPJP38Cf+CWJcfJO832/QRlc63N3zMH1cuxJC3WP/KkAtdqIwgmcIhbl8zGntlmKQtvTrh2LWzdfzf8xxXYrUSbiSOJGgYbzQNETeSHkX8wdBrRt6UfPwcv+JPs9+e8XwW/Cf9xynOnEQ3m24njRucKbB1BO+lgg9QbST/+W/85svcNnfjZBJYR77tys9k+GrmIZ+V9RBUQO5GvfxqsoH+C4+5mHXBuMNt/TzlBeXn5jNmeicqYJfXtzUSH64NUD2p/An8ofz1+nHUtTsB3XV9OOgfd0ciU4xKRiX3wbxI1aO5PTL6jBvIQfhaeM5GrdtLiopPQIqfW7H8Vftyzy3lEw3LHIHe4eQn3G4Ga0DuJtgID+DHR1VhA1JyzEfiWe4AV2Bb8t+xchtdtYBH+nOakYN+VyCUgnD91BttXo07+aHPeIygfYS1+hZ8yaCz64TyEuonJSECjUWqk9yFt0bVEAx/C6Yiry6xGG35yyxsweVLisrm9Gk0y3V/JWWTTqR1DNoVpUiacbjQgODjDNS2rkDDTDq//BbiE/HOxnUgAX0x5/HzkihCyDf0YIsKO6wt+jwyALp+gfjmY0rAWRaGkcXuL4w6k6skyF/oUUhLnyYf4InIRSCuskUhR4PINYt7Map33JURHUd2oaRpONiAF6iLS+wyuRQOnU8gXM7AcTdhvI50rwg7gv9AI8Y4M91lIVLMxiNYJ9aiVVfvLRH0SXkBzoTS/0m6USSet48tjyNSelg4UcnQqUqp2oejLfuTy8DBK6PID0mfNSeIQtKBbD7IuT0B91HOoub0XjUjT9Fcu45F7gdslXIf6RY9aAusKLuQ6My5F/VmL8riRaJ0OoL7LhhoBtecz6/Cj8OdTTF3TIsqJ+POuS6kiLEi30MBjyHQe0lpooBzGoW7DzSOyGqmlci80sBX1Y26HexDwn/nK2MLhWqLC2onquqqwIJ2K50H84ekZaDXVFvlYhK+R/wIpFh9Ku7T9KPzVz7chvVlrhaNszEYRNq5iYiXK41jz7YL0StStSGv9srOvAzltWj+IFtU5CNWZK6yXUd0mCguypdRZhZJyuV5EE5B2O4vP+iuVCcgxx9bVe4k3psaSNQfScvx0qYciodnQmBZDdKI6srkeP43qNDV5klZdhG+Mm4nMCi2h+XSiurEZ85aTbDnwyCOwXcjEYJ12ZqHOtOwoxN2Z/VGdWMfc+5DtK7OTat6V0jchPd7DZv8bkP9cs6cabwTdqC6sjvRhVHe5VkXKKzCQCeFkNNx3ORwZ+vY0d+8szEJ1YH07f44s4LlXWyoiMJAG/834zeMBSHs93CaZ4WAhenbr6Xs/qqtCKr2iAgMF0p2MbEYuHSjV6828MgYjnehZl+B7dt2G3BoKp9MoQ2AgX5A5aMhvO9K5aDXVPdFfP+RE9IxzY767HNVN1nz7sZQlMJCgFqNZu025Mwml9b6RPWsUOR490934rtkDSICLKTElYJkCC1mG/PhWxnx3FjKKfpTy8toPBx3oGZ4i3qC7EtVBGcuhRKiHwECqljchNzTrC7EfiiNejYx3u1PmnTZU5tXoGayn1070zEeRQd2UhbTa+iLMRj4KU6p8vwZ54t5E8RVb68UY9CadR3Vl92rkh2Fj7UqlEQIDNSEfQ+25TXgVshH5jFxP86zeMA05gs6neoKVAaQT/AzR7AF1oVECC5mIVlNdQO1VYh9H7f93qFPTUoMwk8C7iI+DDhkEvop8NhuWJ7nRAgvpRo6T80h2UP0j0sfdgyakNtN0UQ5G6WpPCD5JPvvbkZPnJQxDyvjhEljIa5CrwTmkz+nUh0Zhv0SOor9BXkbrkRZhG0OG1r1RczwODcG7kIC6UXN3BOljjzeivngJ6VfbK53hFljIKJQAZQFy1GyWkeNWZBq5Kfhb9uLjmWkWgbl0IeGdgiIuG72i3hak97sd9aPNkhYeaE6BuYxB62jORhrwmRRfotGyCYXPrkAORffia2qahmYXmKUNzYOmB38nI8eWA1AftS9qXkOhbkLN2ouoj3sO9T+9aP63Mvhblv993fl/O+ue5PF+e6wAAAAASUVORK5CYII=";

static UIImage *common_otsd_200px_img = nil;//一次 App 生命周期内缓存海豚图避免频繁base64转image。
static UIImage *common_otsd_400px_img = nil;

static NSString * const kOTSDImageCacheDirectory = @"/otsd_default_image_cache/";

@implementation OTSDefaultImage

+ (void)clearAllCache
{
    @try {
        [[NSFileManager defaultManager] removeItemAtPath:[self otsd_baseCachePath] error:NULL];
    } @catch (NSException *exception) {
        
    } @finally {
        
    }
}

+(UIImage *)defaultImageWithToken:(NSString *)tokenString
{
    return [self otsd_imageWithToken:tokenString];
}

+ (UIImage *)defaultImageWithSize:(CGSize)size
                  backgroundColor:(UIColor *)backgroundColor
                        logoWidth:(CGFloat)logoWidth
                             text:(NSString *)textString
                     textFontSize:(CGFloat)textFontSize
                    textTopMargin:(CGFloat)textTopMargin
                            token:(NSString *)tokenString
{
    UIImage *returnImage = [self defaultImageWithToken:tokenString];
    if (returnImage) {
        return returnImage;
    }
    
    if (textTopMargin < 1) {
        textTopMargin = [self defaultTextTopMargin];
    }
    
    if (!textString || textString.length == 0) {
        textTopMargin = 0;
    }
    size = CGSizeMake(ceil(size.width), ceil(size.height));
    // 开始绘制
    UIGraphicsBeginImageContextWithOptions(size, YES, [[UIScreen mainScreen] scale]);
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    // 绘制背景
    if (!backgroundColor) {
        backgroundColor = [self defaultBackgroundColor];
    }
    CGContextSetFillColorWithColor(context, [backgroundColor CGColor]);
    CGContextFillRect(context, CGRectMake(0, 0, size.width, size.height));
    
    // 绘制 logo
    UIImage *logoImage = [self defaultLogoForSize:size];
    
    CGSize logoSize;
    CGSize imageSize = logoImage.size;
    if (logoWidth < 1) {
        CGFloat deviceScale = [[UIScreen mainScreen] scale];
        logoSize = CGSizeMake(imageSize.width / deviceScale, imageSize.height / deviceScale);
        
        CGFloat ratio = textString.length >  0 ? 0.5 : 0.7;
        if (size.width < size.height) {
            ratio = size.width / logoSize.width * ratio;
        } else {
            ratio = size.height / logoSize.height * ratio;
        }
        logoSize = CGSizeMake(logoSize.width * ratio, logoSize.height * ratio);
    } else {
        logoSize = CGSizeMake(logoWidth, logoWidth / imageSize.width * imageSize.height);
    }
    
    CGFloat x = (size.width - logoSize.width) / 2.0;
    CGFloat y = (size.height - logoSize.height) / 2.0 - textTopMargin;
    CGRect logoRect = CGRectMake(x, y, logoSize.width, logoSize.height);
    [logoImage drawInRect:logoRect];
    
    // 绘制文字
    if (textString) {
        if (textFontSize < 1) {
            textFontSize = [self defaultTextFontSize];
        }
        UIFont *textFont = [UIFont systemFontOfSize:textFontSize];
        CGSize textSize = [textString boundingRectWithSize:CGSizeMake(size.width, textFontSize) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:textFont} context:nil].size;
        
        [textString drawAtPoint:CGPointMake((size.width - textSize.width) / 2.0, (y + logoSize.height + textTopMargin)) withAttributes:@{NSFontAttributeName:textFont, NSForegroundColorAttributeName:[self defaultTextColor]}];
    }
    
    //生成图片
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    returnImage = newImage;
    
    //缓存图片
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        [self otsd_cacheImage:returnImage withToken:tokenString];
    });
    
    return returnImage;
}

#pragma mark - Convenience Methods
/// 正方形默认图，只需传边长和 token
+ (UIImage *)squareDefaultImageWithLength:(CGFloat)length token:(NSString *)tokenString
{
    return [self defaultImageWithSize:CGSizeMake(length, length)
                      backgroundColor:[self defaultBackgroundColor]
                            logoWidth:0
                                 text:nil
                         textFontSize:0
                        textTopMargin:0
                                token:tokenString];
}

/// 带文本正方形默认图
+ (UIImage *)squareDefaultImageWithLength:(CGFloat)length text:(NSString *)textString token:(NSString *)tokenString
{
    return [self defaultImageWithSize:CGSizeMake(length, length)
                      backgroundColor:[self defaultBackgroundColor]
                            logoWidth:0
                                 text:textString
                         textFontSize:[self defaultTextFontSize]
                        textTopMargin:[self defaultTextTopMargin]
                                token:tokenString];
}

/// 只需传图片size，token，其他使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                            token:(NSString *)tokenString
{
    return [self defaultImageWithSize:size
                      backgroundColor:[self defaultBackgroundColor]
                            logoWidth:0
                                 text:nil
                         textFontSize:0
                        textTopMargin:0
                                token:tokenString];
}

/// 只需传图片size，文本，token，其他使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                             text:(NSString *)textString
                            token:(NSString *)tokenString
{
    return [self defaultImageWithSize:size
                      backgroundColor:[self defaultBackgroundColor]
                            logoWidth:0
                                 text:textString
                         textFontSize:[self defaultTextFontSize]
                        textTopMargin:[self defaultTextTopMargin]
                                token:tokenString];
}

/// 只需传图片size，logo 的size，文本，token，其他使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                        logoWidth:(CGFloat)logoWidth
                             text:(NSString *)textString
                            token:(NSString *)tokenString
{
    return [self defaultImageWithSize:size
                      backgroundColor:[self defaultBackgroundColor]
                            logoWidth:logoWidth
                                 text:textString
                         textFontSize:[self defaultTextFontSize]
                        textTopMargin:[self defaultTextTopMargin]
                                token:tokenString];
}

/// 背景色使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                        logoWidth:(CGFloat)logoWidth
                             text:(NSString *)textString
                     textFontSize:(CGFloat)textFontSize
                    textTopMargin:(CGFloat)textTopMargin
                            token:(NSString *)tokenString
{
    return [self defaultImageWithSize:size
                      backgroundColor:[self defaultBackgroundColor]
                            logoWidth:logoWidth
                                 text:textString
                         textFontSize:textFontSize
                        textTopMargin:textTopMargin
                                token:tokenString];
}

/// 背景色使用默认，文本距 logo 距离使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                        logoWidth:(CGFloat)logoWidth
                             text:(NSString *)textString
                     textFontSize:(CGFloat)textFontSize
                            token:(NSString *)tokenString
{
    return [self defaultImageWithSize:size
                      backgroundColor:[self defaultBackgroundColor]
                            logoWidth:logoWidth
                                 text:textString
                         textFontSize:textFontSize
                        textTopMargin:[self defaultTextTopMargin]
                                token:tokenString];
}

/// 背景色使用默认，无文本
+ (UIImage *)defaultImageWithSize:(CGSize)size
                        logoWidth:(CGFloat)logoWidth
                            token:(NSString *)tokenString
{
    return [self defaultImageWithSize:size
                      backgroundColor:[self defaultBackgroundColor]
                            logoWidth:logoWidth
                                 text:nil
                         textFontSize:0
                        textTopMargin:[self defaultTextTopMargin]
                                token:tokenString];
}

#pragma mark - Interal Methonds
/// 根据 token 从磁盘中读取图片
+ (UIImage *)otsd_imageWithToken:(NSString *)tokenString
{
    NSString *path = [[self otsd_baseCachePath] stringByAppendingPathComponent:[self otsd_md5:tokenString]];
    NSData *imageData = [NSData dataWithContentsOfFile:path];
    UIImage *image = [UIImage imageWithData:imageData];
    return image;
}

/// 图片缓存到磁盘中
+ (void)otsd_cacheImage:(UIImage *)image withToken:(NSString *)tokenString
{
    NSString *path = [[self otsd_baseCachePath] stringByAppendingPathComponent:[self otsd_md5:tokenString]];
    NSData *imageData = UIImagePNGRepresentation(image);
    if (imageData.length > 100) {
        [imageData writeToFile:path atomically:YES];
    }
}

/// 图片缓存的路径
+ (NSString *)otsd_baseCachePath
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    
    NSString *path = [documentsDirectory stringByAppendingString:kOTSDImageCacheDirectory];
    BOOL isDirectory = YES;
    if (![[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&isDirectory]) {
        [[NSFileManager defaultManager] createDirectoryAtPath:path withIntermediateDirectories:YES attributes:nil error:NULL];
    }
    return path;
}

/// md5
+ (NSString *)otsd_md5:(NSString *)str
{
    const char *cStr = [str UTF8String];
    unsigned char result[16];
    CC_MD5( cStr, (CC_LONG)strlen(cStr), result);
    
    return [NSString stringWithFormat:@"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
            result[0], result[1], result[2], result[3],
            result[4], result[5], result[6], result[7],
            result[8], result[9], result[10], result[11],
            result[12], result[13], result[14], result[15]
            ];
}

#pragma mark - Default Configurations
/// 默认背景色
+ (UIColor *)defaultBackgroundColor
{
    return [UIColor colorWithRed:232.0 / 255.0 green:232.0 / 255.0 blue:232.0 / 255.0 alpha:1.0];
}

/*
 *2张默认图，按需使用
 *otsd_200px:186x200
 *otsd_400px:372x400
 */
/// 默认logo image
+  (UIImage *)defaultLogoForSize:(CGSize)size
{
    NSData *data = nil;
    UIImage *img = nil;
    if (size.width < 120 && size.height < 120) {//使用小图 200x200
        if (!common_otsd_200px_img) {
            data = [[NSData alloc] initWithBase64EncodedString:common_otsd_72px_base64 options:NSDataBase64DecodingIgnoreUnknownCharacters];
            common_otsd_200px_img = [UIImage imageWithData:data];
        }
        
        img = common_otsd_200px_img;
    } else {//使用大图 400x400
        if (!common_otsd_200px_img) {
            data = [[NSData alloc] initWithBase64EncodedString:common_otsd_108px_base64 options:NSDataBase64DecodingIgnoreUnknownCharacters];
            common_otsd_400px_img = [UIImage imageWithData:data];
        }
        
        img = common_otsd_400px_img;
    }
    return img;
}

/// 默认文本颜色
+ (UIColor *)defaultTextColor
{
    return [UIColor colorWithRed:102.0 / 255.0 green:102.0 / 255.0 blue:102.0 / 255.0 alpha:1.0];
}

/// 默认文本大小
+ (CGFloat)defaultTextFontSize
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return 13.0;
    } else {
        return 20.0;
    }
}

/// 默认文本距 logo 的距离
+ (CGFloat)defaultTextTopMargin
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return 10.0;
    } else {
        return 15.0;
    }
}
@end
