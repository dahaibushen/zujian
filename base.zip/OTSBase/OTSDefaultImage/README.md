#Readme
##OTSDefaultImage 产生背景
目前项目中使用的默认图片是各业务自行处理，每个尺寸切一套图，导致项目中默认图太多，而且冗余，已经有多人提出这个问题，所以考虑到是否可以动态生成默认图。

###OTSDefaultImage 基本原理
用户首次生成一张图片时会把这张图片缓存到磁盘，以后再生成这张图片时可以根据 token 从磁盘缓存里面读取而不需要再次生成。

###OTSDefaultImage 优化
目前无内存缓存，考虑需不需要做内存缓存。

###使用示例
```
UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 30, 200, 100)];
imageView.image = [OTSDefaultImage defaultImageWithSize:imageView.frame.size backgroundColor:nil logoWidth:50 text:@"加载完成" textFontSize:0 textTopMargin:0 token:@"com.ots.OTSDebug.200x100"];
[self.view addSubview:imageView];
```

```
imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 140, 320, 50)];
imageView.image = [OTSDefaultImage defaultImageWithSize:imageView.frame.size token:@"com.ots.OTSDebug.320x50"];
[self.view addSubview:imageView];
```

```
imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 200, 50, 100)];
imageView.image = [OTSDefaultImage defaultImageWithSize:imageView.frame.size token:@"com.ots.OTSDebug.50x100"];
[self.view addSubview:imageView];
```

```
imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 310, 80, 80)];
imageView.image = [OTSDefaultImage squareDefaultImageWithLength:80 text:@"正方形" token:@"com.ots.OTSDebug.80x80"];
[self.view addSubview:imageView];
```
