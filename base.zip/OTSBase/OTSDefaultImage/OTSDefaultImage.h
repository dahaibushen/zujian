//
//  OTSDefaultImage.h
//  OneStoreBase
//
//  Created by liuwei7 on 09/06/2017.
//  Copyright © 2017 OneStoreBase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OTSDefaultImage : NSObject

+ (void)clearAllCache;

/*
 * @brief 通过 token 获取已创建过的图片，如果未创建过将返回空。
 * @prama token:创建图片时所使用的 token。
 * @return 返回已创建且缓存的图片。
 */
+ (UIImage *)defaultImageWithToken:(NSString *)tokenString;

/*
 * @brief 如果生成过图片则会返回缓存中的图片，否则会先创建图片再返回且缓存。
 * @prama size 所需生成的默认图的尺寸，必传。
 * @prama backgroundColor 背景颜色，传 nil 时使用默认值。
 * @prama  logoWidth logo 的宽度，根据UED的标注，高度根据宽度等比缩放。
 * @prama  text 文本，可传空
 * @prama  textFontSize 文本字体大小，传0时使用默认大小
 * @prama  textTopMargin 文本距 logo 的距离，传0时使用默认值
 * @prama  token 所生成的图片的唯一标识，图片使用此 token 进行 key-value 的缓存，建议使用 @"com.onethestore.moduleName.key.widthxheight" 来避免冲突。
 */
+ (UIImage *)defaultImageWithSize:(CGSize)size
                  backgroundColor:(UIColor *)backgroundColor
                        logoWidth:(CGFloat)logoWidth
                             text:(NSString *)textString
                     textFontSize:(CGFloat)textFontSize
                    textTopMargin:(CGFloat)textTopMargin
                            token:(NSString *)tokenString;

#pragma mark - Convenience Methods
/// 正方形默认图，只需传边长和 token
+ (UIImage *)squareDefaultImageWithLength:(CGFloat)length token:(NSString *)tokenString;

/// 带文本正方形默认图
+ (UIImage *)squareDefaultImageWithLength:(CGFloat)length text:(NSString *)textString token:(NSString *)tokenString;

/// 只需传图片size，token，其他使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                            token:(NSString *)tokenString;

/// 只需传图片size，文本，token，其他使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                             text:(NSString *)textString
                            token:(NSString *)tokenString;

/// 只需传图片size，logo 的size，文本，token，其他使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                        logoWidth:(CGFloat)logoWidth
                             text:(NSString *)textString
                            token:(NSString *)tokenString;

/// 背景色使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                        logoWidth:(CGFloat)logoWidth
                             text:(NSString *)textString
                     textFontSize:(CGFloat)textFontSize
                    textTopMargin:(CGFloat)textTopMargin
                            token:(NSString *)tokenString;

/// 背景色使用默认，文本距 logo 距离使用默认
+ (UIImage *)defaultImageWithSize:(CGSize)size
                        logoWidth:(CGFloat)logoWidth
                             text:(NSString *)textString
                     textFontSize:(CGFloat)textFontSize
                            token:(NSString *)tokenString;

/// 背景色使用默认，无文本
+ (UIImage *)defaultImageWithSize:(CGSize)size
                        logoWidth:(CGFloat)logoWidth
                            token:(NSString *)tokenString;

@end
