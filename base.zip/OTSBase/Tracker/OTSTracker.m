//
//  OTSTracker.m
//  OTSBase
//
//  Created by Jerry on 2017/8/7.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "OTSTracker.h"

#import "JDMTA.h"
#import "JDMTAModel.h"
#import "OTSClientInfo.h"
#import <OTSBase/OTSBase.h>
#import <OTScore/OTSJSONUtil.h>
#import "OTSBITrackerBDPramaVO.h"
#define MACHINE UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? @"iPad" : @"iPhone"
#define SYSTEM [[[UIDevice currentDevice] systemVersion] floatValue]

@interface OTSTracker ()

@property (nonatomic, strong) NSMutableArray *trackerInfosCache;
@property (nonatomic, strong) NSMutableArray *pvInfosCache;
@property (nonatomic, strong) OTSOperationManager *opManager;

@end

@implementation OTSTracker

static NSString *app_lon = nil;
static NSString *app_lat = nil;
static NSString *app_idfa = nil;
static NSString *app_idfv = nil;
static NSString *app_build = nil;
static NSString *app_version = nil;

DEF_SINGLETON(OTSTracker)

NS_INLINE NSString *UnBoxingString(NSString *string) {
    return [string isKindOfClass:NSClassFromString(@"NSString")] && string.length > 0 ? string : @"";
}

//Event Click
+ (void)jdmta_event:(NSString *)sourceName
        SourceParam:(NSString *)sourceParam
         TargetName:(NSString *)targetName
            EventID:(NSString *)eventID
         EventParam:(NSString *)eventParam
         GoodsParam:(NSDictionary *)goodsParam {
    JDMTAClick *click = [JDMTAClick new];

    click.lon = UnBoxingString(app_lon);
    click.lat = UnBoxingString(app_lat);
    click.eventsID = UnBoxingString(eventID);
    click.eventParam = UnBoxingString(eventParam);
    click.tar = UnBoxingString(targetName);

    click.currentParameters = UnBoxingString(sourceName);
    click.pageParameters = UnBoxingString(sourceParam);
    click.shopID = UnBoxingString(goodsParam[@"shop_id"]);
    click.orderID = UnBoxingString(goodsParam[@"ord"]);
    click.skuNumber = UnBoxingString(goodsParam[@"sku"]);

    click.appVersion = app_version;
    click.appBuild = app_build;

    [JDMTA recordWithModel:click parameters:nil];
    
    
    #ifdef OTS_TEST
//    NSAssert(UnBoxingString(click.currentParameters).length > 0, @"页面ID不能为空");
//    NSAssert(UnBoxingString(click.eventsID).length > 0, @"事件ID不能为空");
    
    NSMutableDictionary *biDic = @{}.mutableCopy;
    biDic[@"eventsID"] = click.eventsID;
    biDic[@"eventParam"] = click.eventParam;
    biDic[@"targetName"] = click.tar;
    biDic[@"sourceName"] = click.currentParameters;
    biDic[@"sourceParam"] = click.pageParameters;

    [[OTSTracker sharedInstance] cacheTrackerInfo:biDic withType:OTSBITypeTracker];
    [[OTSTracker sharedInstance].sendBITrackParamAction execute:RACTuplePack(biDic,nil,@YES,nil)];
    #endif
}

//Event PV
+ (void)jdmta_event_pv:(NSString *)curPageName
             curPageParam:(NSDictionary *)curPageParam
           prePageName:(NSString *)prePageName
          prePageParam:(NSDictionary *)prePageParam
{
    JDMTAPageValue *pv = [JDMTAPageValue new];
    
    pv.shopID = UnBoxingString(curPageParam[@"shopId"]);
    pv.orderID = UnBoxingString(curPageParam[@"ord"]);
    pv.loadTime = UnBoxingString(curPageParam[@"ldt"]);
    pv.skuNumber = UnBoxingString(curPageParam[@"sku"]);
    
    pv.currentParameters = UnBoxingString(curPageName);
    pv.referencerURl = UnBoxingString(prePageName).length > 0 ? UnBoxingString(prePageName) : UnBoxingString([OTSTracker sharedInstance].ref);
    pv.pageParameters = curPageParam.count > 0 && !curPageParam[@"custom_id"] ? [OTSJSONUtil stringFromDict:curPageParam] : UnBoxingString(curPageParam[@"custom_id"]);
    pv.referencerParameters = prePageParam.count > 0 && !prePageParam[@"custom_id"] ? [OTSJSONUtil stringFromDict:prePageParam] : UnBoxingString(prePageParam[@"custom_id"]);

    pv.lon = UnBoxingString(app_lon);
    pv.lat = UnBoxingString(app_lat);
    pv.uct = @"";


    pv.preSession = @"";
    pv.preSequence = @"";
    pv.extend = @"";

    pv.utm_source = [JDMTA obtainCookiesWithKey:JDMTA_USC];
    pv.utm_campaign = [JDMTA obtainCookiesWithKey:JDMTA_UCP];
    pv.utm_medium = [JDMTA obtainCookiesWithKey:JDMTA_UMD];
    pv.utm_term = [JDMTA obtainCookiesWithKey:JDMTA_UTR];
    pv.adk = [JDMTA obtainCookiesWithKey:JDMTA_ADK];
    pv.ads = [JDMTA obtainCookiesWithKey:JDMTA_ADS];

    pv.appVersion = app_version;
    pv.appBuild = app_build;

    [JDMTA recordWithModel:pv parameters:nil];
    
    
    #ifdef OTS_TEST
//    NSAssert(UnBoxingString(pv.currentParameters).length > 0, @"页面ID不能为空");
    
    NSMutableDictionary *pvDic = @{}.mutableCopy;
    pvDic[@"pageName"] = pv.pageID;
    pvDic[@"pageParam"] = pv.pageParameters;
    pvDic[@"prePageName"] = pv.referencerURl;
    pvDic[@"prePageParam"] = pv.referencerParameters;
    [[OTSTracker sharedInstance].sendBITrackParamAction execute:RACTuplePack(nil,pvDic,@YES,nil)];
    [[OTSTracker sharedInstance] cacheTrackerInfo:pvDic withType:OTSBITypePV];
    #endif
}

+ (void)jdmta_event_tracking:(NSDictionary *)orderInfo {
    NSString *orderId = [orderInfo objectForKey:@"orderId"];
//    NSString *factPrice = [orderInfo objectForKey:@"factPrice"];
//    if (!factPrice) factPrice = @"";
    NSDictionary *ord_ext = [orderInfo objectForKey:@"ord_ext"];
    NSString *timeStr = [NSString stringWithFormat:@"%.6f", [[NSDate date] timeIntervalSince1970]];

    JDMTAOrder *order = [JDMTAOrder new];
    order.lon = [NSString stringWithFormat:@"99"];
    order.lat = [NSString stringWithFormat:@"121"];
    order.order_ts = timeStr;
    order.lv0_source_id = @"";

    order.lv1_event_id = @"";
    order.lv1_event_param = @"";
    order.lv1_page_name = @"";
    order.lv1_page_param = @"";

    order.lv2_event_id = @"";
    order.lv2_event_param = @"";
    order.lv2_page_name = @"";
    order.lv2_page_param = @"";

    order.lv3_event_id = @"";
    order.lv3_event_param = @"";
    order.lv3_page_name = @"";
    order.lv3_page_param = @"";

    order.lv4_event_id = @"";
    order.lv4_event_param = @"";
    order.lv4_page_name = @"";
    order.lv4_page_param = @"";

    order.lv5_event_id = @"";
    order.lv5_event_param = @"";
    order.lv5_page_name = @"";
    order.lv5_page_param = @"";

    order.sale_ord_id = (orderId ? orderId : @"");
    order.prod_id = @"";//(sku ? sku : @"");
    order.quantity = @"";////(skuCount ? skuCount : @"");
    order.order_total_fee = @"";// (skuCount ? factPrice : @"");
    order.pv_sid = @"";//(model.pv_sid ? model.pv_sid : @"");
    order.pv_seq = @"";//(model.pv_sid ? model.pv_sid : @"");
    order.skuTag = ord_ext[@"sku_tag"] ?: @"";
    order.ord_type = @"";
    order.appVersionCode = @"501";

    order.appVersion = @"501";
    order.appBuild = @"501";

    [JDMTA recordWithModel:order parameters:@{
            @"typ12": @"sr",
    }];
}

+ (void)jdmta_event_userdefine:(NSString *)eid ela:(NSString *)ela eli:(NSString *)eli {
    JDMTAUserDefine *define = [[JDMTAUserDefine alloc] init];
    define.ela = @"";
    define.eli = @"";
    define.eid = @"";
    define.lon = @"";
    define.lat = @"";
    define.currentParameters = @"";
    define.pageParameters = @"";
    define.skuNumber = @"";
    define.ord = @"";

    [JDMTA recordWithModel:define parameters:nil];
}

+ (void)jdmta_event_openUrl:(NSURL *)url {

    NSArray *array = [url.absoluteString componentsSeparatedByString:@"="];
    if (array.count > 1) {
        NSString *paramStr = [[array objectAtIndex:1] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:[paramStr dataUsingEncoding:NSUTF8StringEncoding]
                                                             options:NSJSONReadingMutableLeaves
                                                               error:nil];
        NSDictionary *m_params = dict[@"m_param"];
        [OTSTracker setUTMInfo:m_params];
    }
}

+ (void)setUTMInfo:(NSDictionary *)utmInfo {
    if ([utmInfo isKindOfClass:NSClassFromString(@"NSDictionary")]) {
        NSNumber *seqNum = [utmInfo[@"psq"] isKindOfClass:[NSNumber class]] ? utmInfo[@"psq"] : nil;

        [OTSTracker sharedInstance].psq = [NSString stringWithFormat:@"%ld", [seqNum integerValue]]; //psq int类型
        [OTSTracker sharedInstance].psn = [utmInfo[@"psn"] isKindOfClass:[NSString class]] ? utmInfo[@"psn"] : nil;
        [OTSTracker sharedInstance].ref = [utmInfo[@"ref"] isKindOfClass:[NSString class]] ? utmInfo[@"ref"] : nil;

        [JDMTA accessAppCookiesInformations:utmInfo];

    }
}

- (void)setOrderTrackInfo:(NSURL *)aUrl {
    if (aUrl) {
        NSDictionary *params = [self getParameterOfURL:aUrl.copy];
        self.unpl = UnBoxingString(params[@"unpl"]).length > 0 ? UnBoxingString(params[@"unpl"]) : nil;
        self.jda = UnBoxingString(params[@"jda"]).length > 0 ? UnBoxingString(params[@"jda"]) : nil;;
    }
}
- (NSDictionary *)getParameterOfURL:(NSURL *)aURL {
    NSURL *url = aURL.copy;
    NSString *query = [url.query stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSArray<NSString *> *params = [query componentsSeparatedByString:@"&"];
    NSMutableDictionary *paramsDic = [NSMutableDictionary dictionary];
    
    if (params) {
        for (NSString *subStr in params) {
            if ([subStr containsString:@"="]) {
                NSArray<NSString *> *pairs = [subStr componentsSeparatedByString:@"="];
                NSString *key = pairs.firstObject;
                NSString *value = pairs.lastObject;
                if ([key isEqualToString:@"body"] && value) {
                    NSDictionary *resultDic = [OTSJSONUtil dictFromString:value];
                    if (resultDic) {
                        [paramsDic addEntriesFromDictionary:resultDic];
                    }
                } else {
                    [paramsDic setValue:value forKey:key];
                }
            }
        }
    }
    
    return paramsDic.copy;
}
+ (NSDictionary *)dictionaryAppendedGloblePrms:(NSDictionary *)dictionary {
    return @{};
}

+ (NSString *)utmInfo {
    NSMutableString *utmStr = [NSMutableString stringWithCapacity:0];

    [utmStr appendFormat:@"yhdapp;"];
    [utmStr appendFormat:@"%@;", MACHINE];
    [utmStr appendFormat:@"%@;", app_build];
    [utmStr appendFormat:@"%f;", SYSTEM];
    [utmStr appendFormat:@"%@;", app_idfv]; //openUDID
    [utmStr appendFormat:@"%@;", app_idfa];

    [utmStr appendFormat:@"psn/%@;", UnBoxingString([OTSTracker sharedInstance].psn)];
    [utmStr appendFormat:@"psq/%@;", UnBoxingString([OTSTracker sharedInstance].psq)];
    [utmStr appendFormat:@"ref/%@;", UnBoxingString([OTSTracker sharedInstance].ref)];
    [utmStr appendFormat:@"ads/%@;", [JDMTA obtainCookiesWithKey:JDMTA_ADK]];
    [utmStr appendFormat:@"adk/%@;", [JDMTA obtainCookiesWithKey:JDMTA_ADS]];

    [utmStr appendFormat:@"usc/%@;", [JDMTA obtainCookiesWithKey:JDMTA_USC]];
    [utmStr appendFormat:@"utr/%@;", [JDMTA obtainCookiesWithKey:JDMTA_UTR]];
    [utmStr appendFormat:@"umd/%@;", [JDMTA obtainCookiesWithKey:JDMTA_UMD]];
    [utmStr appendFormat:@"ucp/%@;", [JDMTA obtainCookiesWithKey:JDMTA_UCP]];

    return utmStr;
}

+ (void)initWebViewUserAgent {
    UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectZero];
    NSString *secretAgent = [webView stringByEvaluatingJavaScriptFromString:@"navigator.userAgent"];

    NSString *utmStr = [NSString stringWithFormat:@"%@%@", [OTSTracker utmInfo], secretAgent];
    NSDictionary *userAgent = @{@"UserAgent": utmStr};
    [[NSUserDefaults standardUserDefaults] registerDefaults:userAgent];
}

+ (void)updateWebUserAgent {
    UIWebView *webView = [[UIWebView alloc] initWithFrame:CGRectZero];
    NSString *secretAgent = [webView stringByEvaluatingJavaScriptFromString:@"navigator.userAgent"];

    NSString *regex = @"yhdapp.*?ucp.*?;";
    NSRegularExpression *reg = [NSRegularExpression regularExpressionWithPattern:regex options:0 error:nil];
    secretAgent = [reg stringByReplacingMatchesInString:secretAgent options:0 range:NSMakeRange(0, secretAgent.length) withTemplate:@""];

    NSString *utmStr = [NSString stringWithFormat:@"%@", [OTSTracker utmInfo]];

    secretAgent = [NSString stringWithFormat:@"%@%@", utmStr, secretAgent];

    NSDictionary *userAgent = @{@"UserAgent": secretAgent};
    [[NSUserDefaults standardUserDefaults] registerDefaults:userAgent];
}

- (void)sendJDADExposeWithUrlStr:(NSString *)urlStr {
    if (urlStr.length == 0) {
        return;
    }
    
    OTSOperationParam *param = [OTSOperationParam paramWithUrl:urlStr type:kRequestGet param:nil callback:nil];
    param.alertError = NO;
    param.needSignature = NO;
    [self.opManager requestWithParam:param];
}

+ (void)initMTA {

    app_idfa = [OTSClientInfo sharedInstance].idfa;
    app_idfv = [OTSClientInfo sharedInstance].deviceCode;
    app_version = [OTSClientInfo sharedInstance].clientVersion;
    app_build = [OTSClientInfo sharedInstance].clientAppVersion;
    app_lat = [[OTSClientInfo sharedInstance].latitude stringValue];
    app_lon = [[OTSClientInfo sharedInstance].longitude stringValue];
    
    [JDMTA startWithAppSiteID:@"JA2017_313800"];                                    //测试: cs07
    [JDMTA setAppChannelInfo:@"appstore"];
    [JDMTA setAppVersion:app_version];
    [JDMTA setAppDebugMode:NO];
    [JDMTA setAppUniqueID:app_idfv];
    [JDMTA setAppFilterNullEnable:YES];

    [self initWebViewUserAgent];
}

+ (void)setDebugMode:(BOOL)mode {
    [JDMTA setAppDebugMode:mode];
}


#pragma mark  BICache
-(void)cacheTrackerInfo:(NSDictionary *)bdInfo withType:(OTSBIType)type {
    switch (type) {
        case OTSBITypeTracker:
            if (self.trackerInfosCache.count > 10 ) {
                [self writeBICacheTofileWithType:OTSBITypeTracker];
            }
            
            [self.trackerInfosCache addObject:bdInfo];
            break;
            
        case OTSBITypePV:
            if (self.pvInfosCache.count > 10) {
                [self writeBICacheTofileWithType:OTSBITypePV];
            }
            [self.pvInfosCache addObject:bdInfo];
            break;
    }
}

- (void)writeBICacheTofileWithType:(OTSBIType)type {
    //获取应用程序沙盒的Documents目录
    NSString *plistPath = NSTemporaryDirectory();
    switch (type) {
        case OTSBITypeTracker:
            if (self.trackerInfosCache.count > 0) {
                NSMutableArray *marr = [self arrayFromUserStatisticsConfigPlistWithType:OTSBITypeTracker];
                NSString *filename =[plistPath stringByAppendingPathComponent:@"OTSPageIdForBIConfig.plist"];
                [marr addObjectsFromArray:self.trackerInfosCache];
                [marr writeToFile:filename atomically:YES];
                [self.trackerInfosCache removeAllObjects];
            }
            break;
            
        case OTSBITypePV:
            if (self.pvInfosCache.count > 0) {
                NSMutableArray *marr = [self arrayFromUserStatisticsConfigPlistWithType:OTSBITypePV];
                NSString *filename = [plistPath stringByAppendingPathComponent:@"OTSPagePVForBIConfig.plist"];
                [marr addObjectsFromArray:self.pvInfosCache];
                [marr writeToFile:filename atomically:YES];
                [self.pvInfosCache removeAllObjects];
            }
            break;
    }
}

- (NSMutableArray *)arrayFromUserStatisticsConfigPlistWithType:(OTSBIType)type {
    NSString *plistPath = NSTemporaryDirectory();
    NSString *filename;
    
    switch (type) {
        case OTSBITypeTracker:
            filename = [plistPath stringByAppendingPathComponent:@"OTSPageIdForBIConfig.plist"];
            break;
        case OTSBITypePV:
            filename = [plistPath stringByAppendingPathComponent:@"OTSPagePVForBIConfig.plist"];
            break;
    }
    
    NSMutableArray *arr = [NSMutableArray  arrayWithContentsOfFile:filename];
    if(!arr){
        arr  = [NSMutableArray array];
    } else if (arr.count > 20 && type == OTSBITypeTracker) { //Tracker显示最近20条记录
        NSArray *tmpArr = [arr subarrayWithRange:NSMakeRange(arr.count - 20, 20)];
        arr = [NSMutableArray arrayWithArray:tmpArr];
    }
    
    return arr;
}

- (NSMutableArray *)trackerInfosCache {
    if (!_trackerInfosCache) {
        _trackerInfosCache = [NSMutableArray array];
    }
    return _trackerInfosCache;
}

- (NSMutableArray *)pvInfosCache {
    if (!_pvInfosCache) {
        _pvInfosCache = [NSMutableArray array];
    }
    return _pvInfosCache;
}

- (OTSOperationManager *)opManager {
    if (!_opManager) {
        _opManager = [[OTSNetworkManager sharedInstance] generateOperationMangerWithOwner:self];
    }
    return _opManager;
}

@end
