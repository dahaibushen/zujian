//
//  OTSBITrackerBDPramaVO.m
//  OneStoreMain
//
//  Created by yuan jun on 14/10/29.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSBITrackerBDPramaVO.h"
#import <OTSCore/OTSCore.h>

@implementation OTSBITrackerBDPramaVO

- (id)init {
    self = [super init];
    if (self) {

    }
    return self;
}

- (id)copyWithZone:(NSZone *)zone {
    id copy = [[[self class] alloc] init];
    if (copy) {
        [copy setW_tp:[self.w_tp copyWithZone:zone]];
        [copy setW_tc:[self.w_tc copyWithZone:zone]];
        [copy setW_pt:[self.w_pt copyWithZone:zone]];
        [copy setW_pv:[self.w_pv copyWithZone:zone]];
        [copy setB_ai:[self.b_ai copyWithZone:zone]];
        [copy setW_un:[self.w_un copyWithZone:zone]];
        [copy setB_tu:[self.b_tu copyWithZone:zone]];
        [copy setU_cm:[self.u_cm copyWithZone:zone]];
        [copy setB_ei:[self.b_ei copyWithZone:zone]];
        [copy setB_li:[self.b_li copyWithZone:zone]];
        [copy setGuid:[self.guid copyWithZone:zone]];
        [copy setB_oc:[self.b_oc copyWithZone:zone]];
        [copy setB_fi:[self.b_fi copyWithZone:zone]];
        [copy setB_rs:[self.b_rs copyWithZone:zone]];
        [copy setB_ma:[self.b_ma copyWithZone:zone]];
        [copy setB_pr:[self.b_pr copyWithZone:zone]];
        [copy setW_tu:[self.w_tu copyWithZone:zone]];
        [copy setB_ak:[self.b_ak copyWithZone:zone]];
        [copy setW_ck:[self.w_ck copyWithZone:zone]];
        [copy setB_ct:[self.b_ct copyWithZone:zone]];
        [copy setW_rpv:[self.w_rpv copyWithZone:zone]];
        [copy setW_rpt:[self.w_rpt copyWithZone:zone]];
        [copy setB_scp:[self.b_scp copyWithZone:zone]];
        [copy setB_pmi:[self.b_pmi copyWithZone:zone]];
        [copy setB_lci:[self.b_lci copyWithZone:zone]];
        [copy setB_pms:[self.b_pms copyWithZone:zone]];
        [copy setB_pyi:[self.b_pyi copyWithZone:zone]];
        [copy setW_tpa:[self.w_tpa copyWithZone:zone]];
        [copy setW_tpi:[self.w_tpi copyWithZone:zone]];
        [copy setB_aci:[self.b_aci copyWithZone:zone]];
        [copy setW_url:[self.w_url copyWithZone:zone]];
        [copy setW_rfu:[self.w_rfu copyWithZone:zone]];
        [copy setW_pif:[self.w_pif copyWithZone:zone]];
        [copy setW_run:[self.w_run copyWithZone:zone]];
        [copy setW_tpc:[self.w_tpc copyWithZone:zone]];
        [copy setW_tce:[self.w_tce copyWithZone:zone]];
        [copy setW_tcs:[self.w_tcs copyWithZone:zone]];
        [copy setW_tca:[self.w_tca copyWithZone:zone]];
        [copy setW_tct:[self.w_tct copyWithZone:zone]];
        [copy setW_tcd:[self.w_tcd copyWithZone:zone]];
        [copy setW_tci:[self.w_tci copyWithZone:zone]];
        [copy setB_pri:[self.b_pri copyWithZone:zone]];
        [copy setB_cpt:[self.b_cpt copyWithZone:zone]];
        [copy setB_abv:[self.b_abv copyWithZone:zone]];
        [copy setU_uid:[self.u_uid copyWithZone:zone]];
        [copy setB_cti:[self.b_cti copyWithZone:zone]];
        [copy setSessionId:[self.sessionId copyWithZone:zone]];
    }
    return copy;
}

- (NSMutableDictionary *)convertToDictionary {
    return [NSMutableDictionary dictionaryWithDictionary:[self toDictionary] ?: @{}];
}

- (BOOL)fillTCWithTCString:(NSString *)tcString {
    if (tcString.length > 0) {// tc
        // 拼接tc
        if ([tcString safeRangeOfString:@"."].location != NSNotFound) {
            NSArray *tcArray = [tcString componentsSeparatedByString:@"."];
            if (tcArray.count == 5) {
                self.w_tcs = tcArray[0];
                self.w_tca = tcArray[1];
                self.w_tcd = tcArray[2];
                self.w_tct = tcArray[3];
                self.w_tci = tcArray[4];

                return YES;
            } else if (tcArray.count == 4) {// 广告的tc
                self.w_tcs = tcArray[0];
                self.w_tca = tcArray[1];
                self.w_tcd = tcArray[2];
                self.w_tct = tcArray[3];

                return YES;
            }
        }
    }
    return NO;
}

- (void)reverseBIInfo {

    NSString *pt = self.w_pt;
    NSString *pv = self.w_pv;

    self.w_pt = self.w_rpt;
    self.w_pv = self.w_rpv;

    self.w_rpt = pt;
    self.w_rpv = pv;

    if ([self.b_pyi isEqualToString:@"1"]) {
        self.b_pyi = @"7";
    } else if ([self.b_pyi isEqualToString:@"7"]) {
        self.b_pyi = @"1";
    }
}

- (BOOL)isEmpty {
    return !(_w_pt.length > 0) || !(_w_rpt.length > 0) || !(_b_pyi.length > 0);
}
@end
