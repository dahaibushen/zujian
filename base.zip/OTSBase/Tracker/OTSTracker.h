//
//  OTSTracker.h
//  OTSBase
//
//  Created by Jerry on 2017/8/7.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ReactiveObjC/ReactiveObjC.h>
@class OTSBITrackerBDPramaVO;

typedef NS_ENUM(NSInteger, OTSBIType) {
    OTSBITypeTracker ,
    OTSBITypePV
};

@interface OTSTracker : NSObject


@property(strong, nonatomic) RACCommand *sendBITrackParamAction;

@property(nonatomic ,strong) NSString *psn;
@property(nonatomic ,strong) NSString *psq;
@property(nonatomic ,strong) NSString *ref;

@property(nonatomic ,strong) NSString *jda;
@property(nonatomic ,strong) NSString *unpl;

+ (instancetype)sharedInstance;

/**
 *  写入点击埋点数据
 *
 *  @param sourceName       当前页面类名
 *  @param sourceParam      当前页面参数
 *  @param eventID          事件ID
 *  @param eventParam       事件参数
 *  @param targetName       下个页面类名
 *  @param goodsParam       商品参数
 */
+ (void)jdmta_event:(NSString *)sourceName
              SourceParam:(NSString *)sourceParam
               TargetName:(NSString *)targetName
                  EventID:(NSString *)eventID
               EventParam:(NSString *)eventParam
         GoodsParam:(NSDictionary *)goodsParam;

/**
 *  写入PV埋点数据
 *
 *  @param curPageName       当前页面类名
 *  @param curPageParam      当前页面参数(shopID,sku,ord etc.)
 *  @param prePageName       前置页面类名
 *  @param pageParam         前置页面参数(shopID,sku,ord etc.)
 */
+ (void)jdmta_event_pv:(NSString *)curPageName
          curPageParam:(NSDictionary *)curPageParam
           prePageName:(NSString *)prePageName
          prePageParam:(NSDictionary *)prePageParam;
/**
 *  写入openURL埋点数据
 *
 *  @param url
 */
+ (void)jdmta_event_openUrl:(NSURL *)url;

/**
 *  更新 utmInfo
 *
 */
+ (void)setUTMInfo:(NSDictionary *)utmInfo;

/**
 *  更新 WebUserAgent
 *
 */
+ (void)updateWebUserAgent;

/**
 *  京东 广告 收费曝光
 *
 */
- (void)sendJDADExposeWithUrlStr:(NSString *)urlStr;
/**
 *  联盟 追单
 *
 */

- (void)setOrderTrackInfo:(NSURL *)aUrl;
/**
 *  初始化
 *
 */
+ (void)initMTA;

+ (void)setDebugMode:(BOOL)mode;

- (void)writeBICacheTofileWithType:(OTSBIType)type;

@end
