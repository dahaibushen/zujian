//
//  OneStoreMain
//
//  Created by yuan jun on 14/10/29.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <OTSCore/OTSValueObject.h>

/**
 *  将统计vo赋值给vc的bdPramas，即可在下次统计的时候，加入tracker
 */
@interface OTSBITrackerBDPramaVO : OTSValueObject <NSCopying>

/**
 *  filter_info(上传键值对)(暂时没有用到的参数)
 */
@property(nonatomic, copy) NSString *b_fi;
/**
 *  记录前置页面的pv信息
 */
@property(nonatomic, copy) NSString *w_rpv;
/**
 *  记录前置页面的pt信息
 */
@property(nonatomic, copy) NSString *w_rpt;
/**
 *  记录当前页面的翻页信息（如果有分页的话）
 */
@property(nonatomic, copy) NSString *b_scp;
/**
 *  记录当前页面的商品ID信息（如果有的话）
 */
@property(nonatomic, copy) NSString *b_pmi;
/**
 *  记录当前页面的商家ID信息（如果有的话）
 */
@property(nonatomic, copy) NSString *u_cm;
/**
 *  activy_id（促销活动id）(一个商品可能会对应多个活动ID,用‘，’分割)（目前没有用到）
 */
@property(nonatomic, copy) NSString *b_aci;
/**
 *  记录当前页面的order_code信息，不要传成orderid（如果有的话）
 */
@property(nonatomic, copy) NSString *b_oc;
/**
 *  在搜索列表页选择的类目ID
 */
@property(nonatomic, copy) NSString *b_lci;
/**b_pms
 *  pm_status_type_id（当前商品状态）
 1:未开卖
 2：已开卖
 3：已订阅
 */
@property(nonatomic, copy) NSString *b_pms;
/**
 *b_pyi
 *position_type_id(普通判断：1是普通页面的跳转       2代表页面的不跳转,一般性事件（如点击收藏）  （3，4代表加入购物车）  3点击加入购物车之后还要调转到属性选择的 4是点击购车就加入的，不会再跳转到其他页面  （5，6代表一键购）5是点击了立即购买还需要跳转到比如属性选择页面的        6点击了立即购买就直接进入结算的。
 */
@property(nonatomic, copy) NSString *b_pyi;
/**
 *  页面的区域信息（指该埋点操作在页面的模块位置）
 */
@property(nonatomic, copy) NSString *w_tpa;
/**
 *  页面的具体的index信息（指该埋点操作在页面模块中的具体位置，例如点击第几个item跳转页面）
 */
@property(nonatomic, copy) NSString *w_tpi;
/**
 *  打开渠道id
 */
@property(nonatomic, copy) NSString *b_tu;
/**
 *  当前页面的连接地址
 */
@property(nonatomic, copy) NSString *w_url;
/**
 *  前一页链接地址
 */
@property(nonatomic, copy) NSString *w_rfu;
/**
 *  tracker自动化打点的pageType + "." + pageId +".0.0.0."+uniId
 */
@property(nonatomic, copy) NSString *w_pif;
/**
 *  tracker自动化打点的tracker position（tp）
 */
@property(nonatomic, copy) NSString *w_tp;
/**
 *  tracker自动化打点的tracker content（tc）
 */
@property(nonatomic, copy) NSString *w_tc;
/**
 *  页面类型，比如1代表cms，2代表首页等
 */
@property(nonatomic, copy) NSString *w_pt;
/**
 *  页面依据业务生成的id，如cms页是活动id，商品详情页是pmId
 */
@property(nonatomic, copy) NSString *w_pv;
/**
 *  附加信息
 */
@property(nonatomic, copy) NSString *b_ai;
/**
 *  页面唯一id，通过算法生成
 */
@property(nonatomic, copy) NSString *w_un;
/**
 *  来源页的页面唯一id,同unid
 */
@property(nonatomic, copy) NSString *w_run;
/**
 *  页面组件，自动打点使用
 */
@property(nonatomic, copy) NSString *w_tpc;
/**
 *  曝光数据的点击量
 */
@property(nonatomic, copy) NSString *w_tce;
/**
 *  表示数据投放系统来源类型，如ad 广告  pms 精准化等，自动打点使用
 */
@property(nonatomic, copy) NSString *w_tcs;

- (BOOL)fillTCWithTCString:(NSString *)tcString;

/**
 *  表示投放系统来源类型的数据算法，比如精准化推荐可能会有多套算法，这里指定算法的版本，自动打点使用
 */
@property(nonatomic, copy) NSString *w_tca;
/**
 *  表示数据类型（普通商品，landing商品,抵用券,品牌，类目等），自动打点使用
 */
@property(nonatomic, copy) NSString *w_tct;
/**
 *  表示数据内容（商品用pmInfoId，landing用landing id等），这个值是和dataType有关联的，自动打点使用
 */
@property(nonatomic, copy) NSString *w_tcd;
/**
 *  表示同一个内容在区域内顺位，自动打点使用
 */
@property(nonatomic, copy) NSString *w_tci;
/**
 *  事件ID
 */
@property(nonatomic, copy) NSString *b_ei;
/**
 *  和事件相关的ID
 */
@property(nonatomic, copy) NSString *b_li;

/**
 *  序列化参数
 *
 *  @return dict
 */
- (NSMutableDictionary *)convertToDictionary;

/**
 *  反转标志来源与目标的参数
 */

- (void)reverseBIInfo;

/**
 *  是否为空
 */

- (BOOL)isEmpty;

#pragma mark-固定参数
/**
 *  一号店应用运行容器 (如:yhdapp,微信,支付宝 等)
 */
//@property(nonatomic, copy,readonly)NSString *s_ct;
/**
 *  App 版本
 */
//@property(nonatomic, copy,readonly)NSString *s_ctv;
/**
 *  初始化固定的参数，iPad，iPhone
 */
//@property(nonatomic, copy,readonly)NSString *s_plt;
/**
 *  ClientSystenVersion终端系统
 */
//@property(nonatomic, copy,readonly)NSString *s_pv;
/**
 *  手机类型(品牌)
 */
//@property(nonatomic, copy,readonly)NSString *s_pt;
/**
 *  手机上网类型 2g 3g 4g
 */
//@property(nonatomic, copy,readonly)NSString *s_nt;
/**
 *  分辨率
 */
//@property(nonatomic, copy,readonly)NSString *s_rst;
/**
 *  s_pro运营商
 */
//@property(nonatomic, copy,readonly)NSString *s_pro;
/**
 *  省份id
 */
//@property(nonatomic, copy,readonly)NSString *u_pid;
/**
 *  下载渠道
 */
//@property(nonatomic, copy,readonly)NSString *d_tru;
/**
 *  guid对应 devicecode
 */
@property(nonatomic, copy) NSString *guid;
/**
 *  sessionId用户回话 ID
 */
@property(nonatomic, copy) NSString *sessionId;
/**
 *  u_uid已登录用户传用户 id 未登录用户给空
 */
@property(nonatomic, copy) NSString *u_uid;
/**
 *  统计搜索列表结果数
 */
@property(nonatomic, copy) NSString *b_rs;
/**
 *  经度纬度地址
 */
@property(nonatomic, copy) NSString *b_ma;
/**
 *  城市ID
 */
@property(nonatomic, copy) NSString *b_cti;
/**
 *  城市名称
 */
@property(nonatomic, copy) NSString *b_ct;
/**
 *  省份ID
 */
@property(nonatomic, copy) NSString *b_pri;
/**
 *  省份名称
 */
@property(nonatomic, copy) NSString *b_pr;
/**
 *  扩展字段Tracker_u （tracker来源）
 */
@property(nonatomic, copy) NSString *w_tu;
/**
 *  扩展字段KEYwordid  (关键字)
 */
@property(nonatomic, copy) NSString *b_ak;
/**
 *  扩展字段Websiteid和uid拼接而成  (拼接规则websiteid:xxx;uid:xxx)
 */
@property(nonatomic, copy) NSString *w_ck;
/**
 *  扩展字段用来区分deeplink的
 */
@property(nonatomic, copy) NSString *b_cpt;
/**
 *  扩展字段用来记录搜索等模块abtest实验用
 */
@property(nonatomic, copy) NSString *b_abv;
@end
