//
//  CircularProgressView.h
//  OneStorePad
//
//  Created by Roy on 15/5/12.
//  Copyright (c) 2015年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CircularProgressView : UIView

@property(nonatomic, strong) UIColor *trackTintColor;//背景圆环的颜色
@property(nonatomic, strong) UIColor *progressTintColor;//进度圆环的颜色
@property(nonatomic, assign) float progress;//进度值{0.0 ~ 1.0}
@property(nonatomic, assign) float circularWidth;//圆环宽度的默认值是3.2;

@end
