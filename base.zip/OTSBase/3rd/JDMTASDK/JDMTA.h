//
//  JDMTA.h
//  MTA
//
//  Created by guochaoyang on 16/3/8.
//  Copyright © 2016年 360Buy. All rights reserved.
//

#import <Foundation/Foundation.h>

@class JDMTABase;
@interface JDMTA : NSObject

#pragma mark - SDK初始化方法

/**
 *  设置app站点标记
 *
 *  @param siteID 如 JA2015_311210 ,siteID为大数据统一分配
 */
+ (void)startWithAppSiteID:(NSString*)siteID;

/**
 *  设置projectID 
 *
 *   @param projectID 例如：01代表京东app(上海数据团队)
 */
+ (void)setAppProjectID:(NSString *)projectID;
/**
 *  设置app渠道来源
 *
 *  @param channel 如 App Store
 */
+ (void)setAppChannelInfo:(NSString*)channel;

/**
 *  设置device
 *
 *  @param channel APP客户端类型：IOS, IOS-HD（高清）, ANDROID，APP可根据需求选择性传入
 */
+ (void)setAppDeviceModel:(NSString*)deviceModel;

/**
 *  传入明文pin又SDK自行加密上报
 *
 *  @param pin 明文pin（用户登录标志）
 */
+ (void)setAppUserPin:(NSString *)pin;

/**
 * 设置是否开启debug模式，默认为关闭。
 *
 * @param isDebug 默认为NO 开启debug模式后将输出SDK日志，请勿在release版本中打开debug模式。
 **/
+ (void)setAppDebugMode:(BOOL)isDebug;

/**
 *  埋点日志过滤空字符开关 默认YES(默认过滤空字符)
 *
 *  @param enable BOOL
 */
+ (void)setAppFilterNullEnable:(BOOL)enable;
/**
 *  设置app版本号
 *
 *  @param version 如 5.0.0
 */
+ (void)setAppVersion:(NSString*)version;

/**
 *  设置设备唯一标志
 *
 *  @param uniqueID 用户自定义设备唯一标志 如 OpenUDID
 */
+ (void)setAppUniqueID:(NSString*)uniqueID;

/**
 *  设置设备广告标示符
 *
 *  @param idfa 广告标示符，适用于对外：例如广告推广，换量等跨应用的用户追踪等。
 */
+ (void)setAppIDFA:(NSString*)idfa;

/**
 *  设置策略请求地址
 *
 *  @param policy policy
 */
+ (void)setAppPolicyDomain:(NSString*)policy;

/**
 *  设置数据上报地址
 *
 *  @param upload 上报地址
 */
+ (void)setAppDataUploadDomain:(NSString*)upload;

/**
 *  清楚SDK内部登录态信息，App退出登录使用
 */
+ (void)clearAppUserPinInfo;

/**
 * 获得是否开启debug模式
 **/
+ (BOOL)getDebugMode;

/**
 *  获取SDK内部app的累计访问次数
 *
 *  @return vts
 */
+ (NSString *)getAppCurrentVisitTimes;

/**
 *  获取SDK内部纪录的当前页面次序
 *
 *  @return seq
 */
+ (NSString *)getAppCurrentSequence;

/**
 *  获取SDK初始化传入的UniqueID
 *
 *  @return UniqueID
 */
+ (NSString *)getAppUniqueID;

/**
 * pap value
 */
+ (NSString *)getPapValue;

/**
 *  获取当前SDK持有的常驻内存tracking信息，
 *
 *  @return value
 */
+ (NSDictionary *)obtainTrackingSourceInfo;

/**
 *  获取本地缓存在硬盘的cookie信息
 *
 *  @param key 详情key参照 JDMTAModel JDMTA_key*
 *
 *  @return cookies
 */
+ (NSString *)obtainCookiesWithKey:(NSString *)key;

#pragma mark - SDK数据接入API

/**
 *  接入引流信息 Tracking Source  持有在内存，杀掉app内容清除
 *
 *  @param tracking 传入字典信息
 */
+ (void)accessTrackingInformations:(NSDictionary *)tracking;

/**
 *  接入大数据统一引流信息  UTM: 统一用户尾部标志  持有在硬盘，杀掉app依旧存在
 *
 *  @param userUtm 传入字典信息
 */
+ (void)accessAppCookiesInformations:(NSDictionary *)cookies;

/**
 *  上报数据
 *
 *  @param model      基础事件类型对象 参照点击、PV、性能、订单、自定义、异常
 *  @param parameters 扩展自定义参数
 */
+ (void)recordWithModel:(JDMTABase *)model parameters:(NSDictionary *)parameters;

@end
