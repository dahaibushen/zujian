//
//  JDMTAModel.h
//  MTA
//
//  Created by guochaoyang on 16/3/8.
//  Copyright © 2016年 360Buy. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const JDMTA_ADK;
extern NSString * const JDMTA_ADS;
extern NSString * const JDMTA_USC;
extern NSString * const JDMTA_UCP;
extern NSString * const JDMTA_UMD;
extern NSString * const JDMTA_UTR;
extern NSString * const JDMTA_EXT;
/**
 *  点击流SDK统一日志格式，属性中标注有 “(上海数据逻辑)”的字段为主站app上海数据团队在使用
 *  如有其他应用需要接入请联系尹俊杰，未标注的为京东大数据基本统一日志格式，请接入方参照统一
 *  日志格式进行上报(标注有上海数据逻辑标志的字段可以忽略)
 */
@interface JDMTABase : NSObject
/**
 *  实现Model -> JSON格式
 *
 *  @return 返回字典格式数据
 */
- (NSDictionary *)dictionary;

@end

#pragma mark - 点击流SDK pv 统计上报
/**
 *  点击流SDK pv 统计上报
 */
@interface JDMTAPageValue : JDMTABase
//需要外部传入的数据定义成属性
@property (nonatomic,strong) NSString * referencerURl;        //ref:上一个页面的URL 可为空
@property (nonatomic,strong) NSString * referencerParameters; //rpr:上一个页面的参数
@property (nonatomic,strong) NSString * loadTime;             //ldt:页面加载时长
@property (nonatomic,strong) NSString * lon;                  //lon:经度
@property (nonatomic,strong) NSString * lat;                  //lat:纬度
@property (nonatomic,strong) NSString * pv_sid;               //pv_sid:上海sessionID逻辑                 (上海数据逻辑)
@property (nonatomic,strong) NSString * pv_seq;               //pv_seq:上海sequence逻辑                  (上海数据逻辑)
@property (nonatomic,strong) NSString * uct;                  //uct:联合登录标志 详情见融合采集方案
@property (nonatomic,strong) NSString * currentParameters;    //ctp:当前页面参数 如：当前页面的类名   不能为空
@property (nonatomic,strong) NSString * pageParameters;       //par:当前页面参数 如：｛skuid:"101"｝
@property (nonatomic,strong) NSString * pageID;               //page_id:页面ID 具体参照埋点文档            (上海数据逻辑)
@property (nonatomic,strong) NSString * skuTag;               //sku_tag:主站app 商详页传入商品活动标签      (上海数据逻辑)
@property (nonatomic,strong) NSString * clickURL;             //click_url:跳转URL                       (上海数据逻辑)
@property (nonatomic,strong) NSString * shopID;               //shp: shopID
@property (nonatomic,strong) NSString * skuNumber;            //sku: 商品sku号
@property (nonatomic,strong) NSString * orderID;              //ord: 订单编号

@property (nonatomic,strong) NSString * screenOrientation;    //HVScreen_tag:                            (上海数据逻辑)
@property (nonatomic,strong) NSString * appVersionCode;       //apc: 与安卓灰度有关，iOS暂时可以不传
@property (nonatomic,strong) NSString * appVersion;           //apv: app 版本号
@property (nonatomic,strong) NSString * appBuild;             //bld: app build号
@property (nonatomic,strong) NSString * sourceType;           //sourceType:  上海接入来源                  (上海数据逻辑)
@property (nonatomic,strong) NSString * sourceValue;          //sourceValue: 上海接入来源                  (上海数据逻辑)
@property (nonatomic,strong) NSString * m_source;             //m_source: 上海 M->原生 传入参数             (上海数据逻辑)
@property (nonatomic,strong) NSString * mba_muid;             //mba_muid: 上海 M->原生 传入参数             (上海数据逻辑)
@property (nonatomic,strong) NSString * mba_sid;              //mba_sid: 上海 M->原生 传入参数              (上海数据逻辑)
@property (nonatomic,strong) NSString * jda;                  //jda: 外部传入cookie                        (上海数据逻辑)
@property (nonatomic,strong) NSString * jdv;                  //jdv: 外部传入cookie                        (上海数据逻辑)
@property (nonatomic,strong) NSString * jda_ts;               //jdv:外部传入cookie                         (上海数据逻辑)
@property (nonatomic,strong) NSString * adk;                  //adk: 外部传入cookie
@property (nonatomic,strong) NSString * ads;                  //ads: 外部传入cookie
@property (nonatomic,strong) NSString * preSession;           //psn: 用于原生->H5通信使用
@property (nonatomic,strong) NSString * preSequence;          //psq: 用于原生->H5通信使用
@property (nonatomic,strong) NSString * utm_source;           //usc: 广告接入来源
@property (nonatomic,strong) NSString * utm_campaign;         //ucp: 广告接入来源
@property (nonatomic,strong) NSString * utm_medium;           //umd: 广告接入来源
@property (nonatomic,strong) NSString * utm_term;             //utr: 广告接入来源
@property (nonatomic,strong) NSString * extend;               //ext: 作为扩展位置处理，可传入“json字符串”

@end

#pragma mark - 点击流SDK click event 统计上报
/**
 *  点击流SDK click event 统计上报
 */
@interface JDMTAClick : JDMTABase

@property (nonatomic,strong) NSString * lon;                  //lon:经度
@property (nonatomic,strong) NSString * lat;                  //lat:纬度
@property (nonatomic,strong) NSString * eventsID;             //cls:点击事件ID  不能为空
@property (nonatomic,strong) NSString * eventParam;           //clp:点击事件参数 不能为空
@property (nonatomic,strong) NSString * tar;                  //tar:点击去向页面参数
@property (nonatomic,strong) NSString * pv_sid;               //pv_sid:上海sessionID逻辑         (上海数据逻辑)
@property (nonatomic,strong) NSString * pv_seq;               //pv_seq:上海sequence逻辑          (上海数据逻辑)
@property (nonatomic,strong) NSString * currentParameters;    //ctp:当前页面参数 如：当前页面的类名
@property (nonatomic,strong) NSString * pageParameters;       //par:当前页面参数 如：｛skuid:"101"｝
@property (nonatomic,strong) NSString * pageID;               //page_id:页面ID 具体参照埋点文档    (上海数据逻辑)
@property (nonatomic,strong) NSString * skuTag;               //sku_tag:主站app 商详传入活动标签   (上海数据逻辑)
@property (nonatomic,strong) NSString * shopID;               //shp:shopID
@property (nonatomic,strong) NSString * skuNumber;            //sku:商品sku号
@property (nonatomic,strong) NSString * orderID;              //ord:订单编号
@property (nonatomic,strong) NSString * appVersionCode;       //apc:与安卓灰度有关，iOS暂时可以不传
@property (nonatomic,strong) NSString * appVersion;           //apv:app 版本号
@property (nonatomic,strong) NSString * appBuild;             //bld:app build号
@property (nonatomic,strong) NSString * m_source;             //m_source:上海 M->原生 传入参数    (上海数据逻辑)
@property (nonatomic,strong) NSString * mba_muid;             //mba_muid:上海 M->原生 传入参数    (上海数据逻辑)
@property (nonatomic,strong) NSString * mba_sid;              //mba_sid:上海 M->原生 传入参数     (上海数据逻辑)

@property (nonatomic,strong) NSString * sourceType;           //sourceType: 上海接入来源          (上海数据逻辑)
@property (nonatomic,strong) NSString * sourceValue;          //sourceValue:上海接入来源          (上海数据逻辑)
@property (nonatomic,strong) NSString * jda;                  //jda:外部传入cookie               (上海数据逻辑)
@property (nonatomic,strong) NSString * jdv;                  //jdv:外部传入cookie               (上海数据逻辑)
@property (nonatomic,strong) NSString * jda_ts;               //jdv:外部传入cookie               (上海数据逻辑)

@property (nonatomic,strong) NSString * event_func;           //

@end

#pragma mark - 点击流SDK 性能 统计上报
/**
 *  点击流SDK 性能统计上报
 */
@interface JDMTAPerformance : JDMTABase

@property (nonatomic,strong) NSString * lon;                  //lon:经度
@property (nonatomic,strong) NSString * lat;                  //lat:纬度
@property (nonatomic,strong) NSString * currentParameters;    //ctp:当前页面参数 如：当前页面的类名 不能为空
@property (nonatomic,strong) NSString * pageParameters;       //par:当前页面参数 如：｛skuid:"101"｝
@property (nonatomic,strong) NSString * ctm;                  //ctm: 原生页面加载开始时间 精确到毫秒
@property (nonatomic,strong) NSString * end_ts;               //end_ts: 原生页面加载时长 精确到毫秒
@property (nonatomic,strong) NSString * pic_ts;               //pic_ts: 图片开始加载时间戳
@property (nonatomic,strong) NSString * pic_url;              //pic_url: 图片URL
@property (nonatomic,strong) NSString * pic_endts;            //pic_endts:图片加载结束时间戳
@property (nonatomic,strong) NSString * pic_size;             //pic_size: 图片大小

@property (nonatomic,strong) NSString * cdn_ip;               //cdn_ip: (m.360buyimg.com的IP) 如:cdn_ip=10.8.0.123
@property (nonatomic,strong) NSString * ldns_ip;              //ldns_ip:本地的DNS的IP 如:ldns_ip=10.8.120.12
@property (nonatomic,strong) NSString * mload_ts;             //mload_ts:内嵌M加载时长
@property (nonatomic,strong) NSString * mload_endts;          //mload_endts:内嵌M加载结束时间戳
@property (nonatomic,strong) NSString * mload_status;         //mload_status:内嵌M加载状态
@property (nonatomic,strong) NSString * mload_type;           //mload_type:内嵌M加载类型
@property (nonatomic,strong) NSString * mload_url;            //mload_url:内嵌M的URL

@property (nonatomic,strong) NSString * appVersionCode;       //apc:客户端版本号code 与安卓灰度有关，iOS暂时可以不传
@property (nonatomic,strong) NSString * appVersion;           //apv:app 版本号
@property (nonatomic,strong) NSString * appBuild;             //bld:app build号

@end

#pragma mark - 点击流SDK 订单 统计上报
/**
 *  点击流SDK 订单 统计上报
 */
@interface JDMTAOrder : JDMTABase

@property (nonatomic,strong) NSString * lon;                  //lon:经度
@property (nonatomic,strong) NSString * lat;                  //lat:纬度
@property (nonatomic,strong) NSString * order_ts;             //order_ts:下单客户端时间戳 毫秒

@property (nonatomic,strong) NSString * lv0_source_id;

@property (nonatomic,strong) NSString * lv1_page_name;
@property (nonatomic,strong) NSString * lv1_page_param;
@property (nonatomic,strong) NSString * lv1_event_id;
@property (nonatomic,strong) NSString * lv1_event_param;

@property (nonatomic,strong) NSString * lv2_page_name;
@property (nonatomic,strong) NSString * lv2_page_param;
@property (nonatomic,strong) NSString * lv2_event_id;
@property (nonatomic,strong) NSString * lv2_event_param;

@property (nonatomic,strong) NSString * lv3_page_name;
@property (nonatomic,strong) NSString * lv3_page_param;
@property (nonatomic,strong) NSString * lv3_event_id;
@property (nonatomic,strong) NSString * lv3_event_param;

@property (nonatomic,strong) NSString * lv4_page_name;
@property (nonatomic,strong) NSString * lv4_page_param;
@property (nonatomic,strong) NSString * lv4_event_id;
@property (nonatomic,strong) NSString * lv4_event_param;

@property (nonatomic,strong) NSString * lv5_page_name;
@property (nonatomic,strong) NSString * lv5_page_param;
@property (nonatomic,strong) NSString * lv5_event_id;
@property (nonatomic,strong) NSString * lv5_event_param;

@property (nonatomic,strong) NSString * sale_ord_id;          //sale_ord_id:父单号，服务器回传的订单编号
@property (nonatomic,strong) NSString * prod_id;              //prod_id:服务端回传 商品编号
@property (nonatomic,strong) NSString * quantity;             //quantity:服务端回传 商品数量

@property (nonatomic,strong) NSString * order_total_fee;      //order_total_fee:服务端回传 优惠后订单金额
@property (nonatomic,strong) NSString * pv_sid;               //pv_sid:上海sessionID逻辑                (上海数据逻辑)
@property (nonatomic,strong) NSString * pv_seq;               //pv_seq:上海sequence逻辑                 (上海数据逻辑)
@property (nonatomic,strong) NSString * skuTag;               //sku_tag:主站app 商详传入活动标签          (上海数据逻辑)
@property (nonatomic,strong) NSString * ord_type;             //ord_type:虚拟订单类型
@property (nonatomic,strong) NSString * appVersionCode;       //apc:与安卓灰度有关，iOS暂时可以不传
@property (nonatomic,strong) NSString * appVersion;           //apv:app 版本号
@property (nonatomic,strong) NSString * appBuild;             //bld:pp build号

@property (nonatomic,strong) NSString * sourceType;           //sourceType:上海接入来源                  (上海数据逻辑)
@property (nonatomic,strong) NSString * sourceValue;          //sourceValue:上海接入来源                 (上海数据逻辑)
@property (nonatomic,strong) NSString * mba_muid;             //mba_muid:上海 M->原生 传入参数            (上海数据逻辑)
@property (nonatomic,strong) NSString * mba_sid;              //mba_sid:上海 M->原生 传入参数             (上海数据逻辑)
@property (nonatomic,strong) NSString * m_source;             //m_source:上海 M->原生 传入参数            (上海数据逻辑)
@property (nonatomic,strong) NSString * jda;                  //jda:外部传入cookie                      (上海数据逻辑)
@property (nonatomic,strong) NSString * jdv;                  //jdv:外部传入cookie                      (上海数据逻辑)
@property (nonatomic,strong) NSString * jda_ts;               //jda:外部传入cookie                      (上海数据逻辑)

@end

#pragma mark - 点击流SDK 自定义事件 统计上报
/**
 *  点击流 自定义事件 统计上报
 */
@interface JDMTAUserDefine : JDMTABase
//lts:SDK 硬编码写死 “ce”

@property (nonatomic,strong) NSString * eid;                  //eid:自定义事件ID 不能为空
@property (nonatomic,strong) NSString * ela;                  //ela:自定义事件对应的模块ID 不能为空
@property (nonatomic,strong) NSString * eli;                  //eli:自定义事件对应模块ID的描述信息
@property (nonatomic,strong) NSString * lon;                  //lon:经度
@property (nonatomic,strong) NSString * lat;                  //lat:纬度
@property (nonatomic,strong) NSString * currentParameters;    //ctp:当前页面参数 如：当前页面的类名
@property (nonatomic,strong) NSString * pageParameters;       //par:当前页面参数 如：｛skuid:"101"｝
@property (nonatomic,strong) NSString * shopID;               //shp:shopID
@property (nonatomic,strong) NSString * skuNumber;            //sku:商品sku号
@property (nonatomic,strong) NSString * ord;                  //ord:订单编号

@property (nonatomic,strong) NSString * appVersionCode;       //apc:客户端版本号code 与安卓灰度有关，iOS暂时可以不传
@property (nonatomic,strong) NSString * appVersion;           //apv:app 版本号
@property (nonatomic,strong) NSString * appBuild;             //bld:app build号

@end

#pragma mark - 点击流SDK 异常日志 统计上报
/**
 *  点击流 异常日志 统计上报
 */
@interface JDMTAException : JDMTABase

@property (nonatomic,strong) NSString * edc;                  //edc: 异常描述
@property (nonatomic,strong) NSString * lon;                  //lon:经度
@property (nonatomic,strong) NSString * lat;                  //lat:纬度
@property (nonatomic,strong) NSString * currentParameters;    //ctp:当前页面参数 如：当前页面的类名
@property (nonatomic,strong) NSString * pageParameters;       //par:当前页面参数 如：｛skuid:"101"｝

@property (nonatomic,strong) NSString * appVersionCode;       //apc:客户端版本号code 与安卓灰度有关，iOS暂时可以不传
@property (nonatomic,strong) NSString * appVersion;           //apv:app 版本号
@property (nonatomic,strong) NSString * appBuild;             //bld:app build号
@end
