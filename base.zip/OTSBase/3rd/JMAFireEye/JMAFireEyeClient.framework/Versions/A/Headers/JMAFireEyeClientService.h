//
//  JMAiPadClientService.h
//  JMAiOSClient
//
//  Created by 杨友涛 on 17/2/22.
//  Copyright © 2017年 JD. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JMAFireEyeClientService : NSObject

/**
 * FireEye注册。
 * @param deviceCode    设备唯一标识
 * @param unionId       渠道
 * @param subunionId    子渠道
 * @param partner       渠道名
 */
+ (void)registerFireEye:(NSString*)deviceCode
                unionId:(NSString*)unionId
             subunionId:(NSString*)subunionId
                partner:(NSString*)partner;

/**
 * 火眼埋点上报
 * @param eventParam    事件参数，eventParam目前需要传入2个key:
 * “appkey”             apptoken, 由火眼系统生成。此参数一定不能为空。
 * “gisinfo”            经纬度
 * @param completionHandler 火眼上报回调接口（金融单独使用）
 */
+ (void)reportFireEye:(NSDictionary*)eventParam
    completionHandler:(void (^)(BOOL reportSF))completionHandler;

@end
