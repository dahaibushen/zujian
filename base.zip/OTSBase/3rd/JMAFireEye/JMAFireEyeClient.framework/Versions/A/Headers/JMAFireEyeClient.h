//
//  JMAiPadClient.h
//  JMAiOSClient
//
//  Created by 杨友涛 on 17/2/22.
//  Copyright © 2017年 JD. All rights reserved.
//

/**
 2017.3.30  ipad4.0版本。sdk2.0.3版本。FMDB版本:2.6.0.
 2017.7.31  金融4.3版本。sdk2.1.2版本。FMDB版本:2.6.0.
 */

#import<JMAFireEyeClient/JMAFireEyeClientService.h>

/**
 * @
 note 正式环境请注释掉下面宏定义。
 */
//#define TARGET_ON 1
