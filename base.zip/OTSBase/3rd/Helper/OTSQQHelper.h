//
//  OTSQQHelper.h
//  OTSBase
//
//  Created by jinjiaju on 2017/8/23.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *const NotificationQQShare;//QQ分享分享返回APP时的通知

typedef NS_ENUM(NSUInteger, QQStatus) {
    QQStatusSuccess,
    QQStatusNoInstall, //没有安装QQ
    QQStatusNoSupportApi,//当前api不支持
};

typedef NS_ENUM(NSUInteger, QQShareType) {
    QQFriend = 0,
    QQZone  = 1
};

typedef void(^OTSQQUnionLoginCallBack)(NSString *openId, NSString *accessToken, NSError *error);

@interface OTSQQHelper : NSObject

+ (instancetype)sharedInstance;

@property (nonatomic, class, readonly) BOOL supportSSOLogin;
@property (nonatomic, class, readonly) BOOL isQQShareValid;
@property (nonatomic, class, readonly) NSString *QQAppInstallUrl;

- (void)requestTencentLoginComplete:(OTSQQUnionLoginCallBack)callBack;

/**
 *  功能:QQ注册1号店app
 */
- (BOOL)registeQQSDKWithAppId:(NSString*)appId;

+ (BOOL)handleOpenURL:(NSURL *)aUrl;

+ (BOOL)canHandleOpenURL:(NSURL*)url;

//qq分享
- (BOOL)handleOpenURLFromQQ:(NSURL *)aUrl;

/**
 *	功能:获取QQ的状态
 *
 *	@return 参见QQStatus
 */
- (QQStatus)QQPublishStatus;

/**
 *	功能:查看QQ的状态，如果没有安装就弹提示让其去安装
 *
 *	@return:QQStatus 状态
 */
- (QQStatus)checkingQQStatus;

- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                   withThumbData:(NSData *)aThumbData
                     withLineUrl:(NSString *)aLinkUrl
                       withScene:(QQShareType)qqShareType;


@end


