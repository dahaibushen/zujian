//
//  OTSSinaHelper.m
//  OTSBase
//
//  Created by jinjiaju on 2017/9/1.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "OTSSinaHelper.h"
#import <OTSCore/OTSCore.h>
#import "NSObject+BeeNotification.h"
#import <OTSCore/OTSAlertController.h>
#import <Weibo_SDK/WeiboSDK.h>

NSString *const NotificationSinaShare = @"notification.sina.share";

@interface OTSSinaHelper () <WeiboSDKDelegate>

@end

@implementation OTSSinaHelper

DEF_SINGLETON(OTSSinaHelper);

+ (BOOL)supportsWeiboShareAPI {
    return [WeiboSDK isWeiboAppInstalled] && [WeiboSDK isCanShareInWeiboAPP];
}

+ (BOOL)registeWeiboSDKWithAppId:(NSString*)appId {
#ifdef OTS_TEST
    [WeiboSDK enableDebugMode:true];
#endif
    return [WeiboSDK registerApp:appId];
}

/**
 *  功能:处理从新浪打开的url
 */
- (BOOL)handleOpenURLFromSina:(NSURL *)aUrl {
    return [WeiboSDK handleOpenURL:aUrl delegate:self];
}

- (void)didReceiveWeiboRequest:(WBBaseRequest *)request {
    
}

- (void)didReceiveWeiboResponse:(WBBaseResponse *)response {
    [self postNotification:NotificationSinaShare withObject:response];
}

//新浪微博分享
- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                   withThumbData:(NSData *)aThumbData
                     withLineUrl:(NSString *)aLinkUrl {
    WBWebpageObject *webpageObject=[WBWebpageObject object];
    webpageObject.objectID=aTitle;
    webpageObject.webpageUrl=aLinkUrl;
    webpageObject.title=aTitle;
    webpageObject.description=aDescription;
    webpageObject.thumbnailData=aThumbData;
    
    WBMessageObject* messageObject=[WBMessageObject message];
    messageObject.text = aTitle;
    messageObject.mediaObject=webpageObject;
    WBSendMessageToWeiboRequest* request= [WBSendMessageToWeiboRequest requestWithMessage: messageObject];
    BOOL success = [WeiboSDK sendRequest:request];
    if (!success) {
        [OTSAlertController alertWithMessage:@"新浪分享失败" andCompleteBlock:nil];
    }
}


@end
