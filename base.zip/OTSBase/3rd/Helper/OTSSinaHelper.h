//
//  OTSSinaHelper.h
//  OTSBase
//
//  Created by jinjiaju on 2017/9/1.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *const NotificationSinaShare;//新浪分享返回APP时的通知

@interface OTSSinaHelper : NSObject

@property (nonatomic, class, readonly) BOOL supportsWeiboShareAPI;

+ (instancetype)sharedInstance;

+ (BOOL)registeWeiboSDKWithAppId:(NSString*)appId;

- (BOOL)handleOpenURLFromSina:(NSURL *)aUrl;

- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                   withThumbData:(NSData *)aThumbData
                     withLineUrl:(NSString *)aLinkUrl;

@end
