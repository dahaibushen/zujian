//
//  PhoneWeChat.h
//  OneStoreMain
//
//  Created by 黄吉明 on 10/27/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT NSString *const NotificationWeichatShare;//微信分享返回APP时的通知
FOUNDATION_EXPORT NSString *const NotificationWeichatPay;//微信支付返回APP时的通知

typedef void(^OTSWeChatRespBlock)(id aResponseObject, NSError* anError);
typedef void(^OTSWeChatUnionLoginCallBack)(NSString *code, NSError *error);

typedef NS_ENUM(NSUInteger, OTSWechatScene) {
    OTSWechatSceneSession = 0,
    OTSWechatSceneTimeline,
    OTSWechatSceneFavorite
};

@interface OTSWeChatHelper : NSObject

@property (nonatomic, class, readonly) NSString *WXAppInstallUrl;
@property (nonatomic, class, readonly) BOOL isWXAppSupportApi;

+ (instancetype)sharedInstance;

//微信注册1号店app
+ (BOOL)registeWechatSDKWithAppId:(NSString*)appId;

//处理从微信打开的url
- (BOOL)handleOpenURLFromWeChat:(NSURL *)aUrl;

//微信支付
- (void)payWithInfo:(NSDictionary *)payInfo complete:(OTSWeChatRespBlock)block;

//联合登陆
- (void)requestUnionLoginComplete:(OTSWeChatUnionLoginCallBack)callBack;

/**
 *	功能:客服端向微信发送文字内容,默认是发送给好友
 *
 *	@param aText:内容
 */
- (void)sendTextContentWithText:(NSString*)aText;

/**
 * 功能:客服端向微信发送文字内容,默认是发送给好友
 *
 *	@param aText aText:内容
 *	@param aScene:参见(WXScene)
 */
- (void)sendTextContentWithText:(NSString *)aText
                      withScene:(OTSWechatScene)aScene;

/**
 *	功能:客服端向微信发送可点击的页面信息,默认是发送给好友
 *
 *	@param aTitle       :页面的title
 *	@param aDescription :页面的描述
 *	@param withThumbData  :消息内容的缩略图Data
 *	@param aLinkUrl     :页面的url
 *  @param aScene       :(enum WXScene)aScene,发送到微信不同的场景
 */
- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                   withThumbData:(NSData *)aThumbData
                     withLineUrl:(NSString *)aLinkUrl
                       withScene:(OTSWechatScene)aScene;

/**
 *	功能:客服端向微信发送可点击的页面信息,默认是发送给好友
 *
 *	@param aTitle       :页面的title
 *	@param aDescription :页面的描述
 *	@param aThumbImage  :消息内容的缩略图
 *	@param aLinkUrl     :页面的url
 *  @param aScene       :(enum WXScene)aScene,发送到微信不同的场景
 */
- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                  withThumbImage:(UIImage *)aThumbImage
                     withLineUrl:(NSString *)aLinkUrl
                       withScene:(OTSWechatScene)aScene;


/**
 *	功能:客服端向微信发送可点击的页面信息,默认是发送给好友
 *
 *	@param aTitle       :页面的title
 *	@param aDescription :页面的描述
 *	@param aImageUrl    :图片url
 *	@param aLinkUrl     :页面的url
 *  @param aScene       :(enum WXScene)aScene,发送到微信不同的场景
 */
- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                    withImageUrl:(NSString *)aImageUrl
                     withLineUrl:(NSString *)aLinkUrl
                       withScene:(OTSWechatScene)aScene;

@end
