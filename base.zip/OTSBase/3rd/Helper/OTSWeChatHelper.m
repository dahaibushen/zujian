//
//  PhoneWeChat.m
//  OneStoreMain
//
//  Created by 黄吉明 on 10/27/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "OTSWeChatHelper.h"
#import "NSObject+BeeNotification.h"
#import <OTSCore/UIImage+Size.h>
#import <OTSCore/OTSCore.h>
#import <WechatOpenSDK/WXApi.h>

NSString *const NotificationWeichatPay = @"notification.weixin.pay";
NSString *const NotificationWeichatShare = @"notification.weixin.share";

@interface OTSWeChatHelper()<WXApiDelegate>

@property (nonatomic, copy) OTSWeChatRespBlock payResultBlock;
@property (nonatomic, copy) OTSWeChatUnionLoginCallBack unionLoginCallBack;

@end

@implementation OTSWeChatHelper

DEF_SINGLETON(OTSWeChatHelper)

+ (NSString*)WXAppInstallUrl {
    return [WXApi getWXAppInstallUrl];
}

+ (BOOL)isWXAppSupportApi {
    return [WXApi isWXAppInstalled] && [WXApi isWXAppSupportApi];
}

#pragma mark - API
+ (BOOL)registeWechatSDKWithAppId:(NSString*)appId {
    return [WXApi registerApp:appId];
}

- (BOOL)handleOpenURLFromWeChat:(NSURL *)aUrl {
    return [WXApi handleOpenURL:aUrl delegate:self];
}

- (void)requestUnionLoginComplete:(OTSWeChatUnionLoginCallBack)callBack {
    SendAuthReq *req = [[SendAuthReq alloc] init];
    req.scope = @"snsapi_userinfo,snsapi_message,snsapi_friend,snsapi_contact";
    req.state = @"weixin";
    [WXApi sendReq:req];
    
    self.unionLoginCallBack = callBack;
}

- (void)payWithInfo:(NSDictionary *)payInfo complete:(OTSWeChatRespBlock)block {
    PayReq *request = [[PayReq alloc] init] ;
    request.partnerId = payInfo[@"partnerid"];
    request.prepayId= payInfo[@"prepayid"];
    request.package = payInfo[@"package"];
    request.nonceStr = payInfo[@"noncestr"];
    request.timeStamp = [payInfo[@"timestamp"] unsignedIntValue];
    request.sign = payInfo[@"sign"];
    [WXApi sendReq:request];
    self.payResultBlock = block;
}

#pragma mark - WXApiDelegate
//从微信直接调用1号店时，调用的API
- (void)onReq:(BaseReq *)req {
    // TODO: ...
}

//一号店发送信息到微信,微信返回时调用API
- (void)onResp:(BaseResp *)resp {
    if ([resp isKindOfClass:[SendAuthResp class]]) { // 微信登录
        SendAuthResp *authResp = (SendAuthResp*)resp;
        [self handleWechatUnionLoginWithResponse:authResp];
    } else if ([resp isKindOfClass:[PayResp class]]) { //  微信支付
        if (self.payResultBlock) {
            self.payResultBlock(resp, nil);
        }
        [self postNotification:NotificationWeichatPay withObject:resp];
    } else if ([resp isKindOfClass:[SendMessageToWXResp class]]) { // 微信分享
        [self postNotification:NotificationWeichatShare withObject:resp];
    }
}

#pragma mark - Wechat Share
- (void)sendTextContentWithText:(NSString*)aText {
    if (![OTSWeChatHelper isWXAppSupportApi]) {
        return;
    }
    
    SendMessageToWXReq *req = [self  respWithText:aText];
    [WXApi sendReq:req];
}

- (void)sendTextContentWithText:(NSString *)aText
                      withScene:(OTSWechatScene)aScene {
    if (![OTSWeChatHelper isWXAppSupportApi]) {
        return;
    }
    SendMessageToWXReq *req = [self respWithText:aText];
    req.scene = aScene;
}

- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                  withThumbImage:(UIImage *)aThumbImage
                     withLineUrl:(NSString *)aLinkUrl
                       withScene:(OTSWechatScene)aScene {
    if (![OTSWeChatHelper isWXAppSupportApi]) {
        return;
    }
    
    WXMediaMessage *message = [WXMediaMessage message];
    message.title = aTitle;
    message.description = aDescription;
    [message setThumbImage:[aThumbImage scaleToSize:CGSizeMake(150, 150)]];
    
    [self sendLinkContentWithMessageContent:message withLineUrl:aLinkUrl withScene:aScene];
}

- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                   withThumbData:(NSData *)aThumbData
                     withLineUrl:(NSString *)aLinkUrl
                       withScene:(OTSWechatScene)aScene {
    if (![OTSWeChatHelper isWXAppSupportApi]) {
        return;
    }
    
    WXMediaMessage *message = [WXMediaMessage message];
    message.title = aTitle;
    message.description = aDescription;
    UIImage*  aThumbImage=[UIImage imageWithData: aThumbData];
    if(aThumbImage!=nil){
        [message setThumbImage:[aThumbImage scaleToSize:CGSizeMake(150, 150)]];
    }
    [self sendLinkContentWithMessageContent:message withLineUrl:aLinkUrl withScene:aScene];
}

- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                    withImageUrl:(NSString *)aImageUrl
                     withLineUrl:(NSString *)aLinkUrl
                       withScene:(OTSWechatScene)aScene {
    if (![OTSWeChatHelper isWXAppSupportApi]) {
        return;
    }
    
    WXMediaMessage *message = [WXMediaMessage message];
    message.title = aTitle;
    message.description = aDescription;
    WXImageObject *imageObject = [WXImageObject object];
    imageObject.imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:aImageUrl]];
    message.mediaObject = imageObject;
    
    [self sendLinkContentWithMessageContent:message withLineUrl:aLinkUrl withScene:aScene];
}

#pragma mark - Private Utility
- (void)handleWechatUnionLoginWithResponse:(SendAuthResp*)response {
    NSError *error = nil;
    NSString *responseCode = nil;
    
    if (response.errCode != WXSuccess) { //微信登陆不成功
        error = [NSError errorWithDomain:@"com.ots.base" code:0 userInfo:@{NSLocalizedDescriptionKey: @"登录失败"}];
    } else {
        responseCode = response.code;
    }
    
    !self.unionLoginCallBack ?: self.unionLoginCallBack(responseCode, error);
}

- (SendMessageToWXReq *)respWithText:(NSString*)aText {
    SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
    req.text = aText;
    req.bText = YES;
    return req;
}

- (void)sendLinkContentWithMessageContent:(WXMediaMessage *)contentMessage
                              withLineUrl:(NSString *)aLinkUrl
                                withScene:(OTSWechatScene)aScene {
 
    WXWebpageObject *ext = [WXWebpageObject object];
    ext.webpageUrl = aLinkUrl;
    
    contentMessage.mediaObject = ext;
    
    SendMessageToWXReq* req = [[SendMessageToWXReq alloc] init];
    req.bText = NO;
    req.message = contentMessage;
    req.scene = aScene;
    
    [WXApi sendReq:req];
}

@end
