//
//  OTSQQHelper.m
//  OTSBase
//
//  Created by jinjiaju on 2017/8/23.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "OTSQQHelper.h"

#import <OTSCore/OTSAlertController.h>
#import <TencentOpenAPI/TencentOAuth.h>
#import <TencentOpenAPI/QQApiInterface.h>
#import <OTSCore/OTSCore.h>
#import "NSObject+BeeNotification.h"

NSString *const NotificationQQShare = @"notification.qq.share";

@interface OTSQQHelper()<TencentSessionDelegate, QQApiInterfaceDelegate>

@property (nonatomic, strong) TencentOAuth *tencentOAuth;
@property (nonatomic, copy) OTSQQUnionLoginCallBack qqUnionLoginCallBack;
@property (nonatomic, copy) NSString *appId;

@end

@implementation OTSQQHelper

DEF_SINGLETON(OTSQQHelper);

- (void)requestTencentLoginComplete:(OTSQQUnionLoginCallBack)callBack {
    NSArray *permissions = [NSArray arrayWithObjects:kOPEN_PERMISSION_GET_USER_INFO, kOPEN_PERMISSION_GET_SIMPLE_USER_INFO, kOPEN_PERMISSION_GET_INFO, nil];
    [self.tencentOAuth authorize:permissions inSafari:NO];
    self.qqUnionLoginCallBack = callBack;
}


#pragma mark -TencentLoginDelegate
//登录成功后的回调
- (void)tencentDidLogin {
    NSString *openId = self.tencentOAuth.openId;
    NSString *accessToken = self.tencentOAuth.accessToken;
    !self.qqUnionLoginCallBack ?: self.qqUnionLoginCallBack(openId, accessToken, nil);
}

//登录失败后的回调 cancelled 代表用户是否主动退出登录
- (void)tencentDidNotLogin:(BOOL)cancelled {
    NSError *error = [NSError errorWithDomain:@"com.ots.base" code:0 userInfo:@{NSLocalizedDescriptionKey: @"登录失败"}];
    !self.qqUnionLoginCallBack ?: self.qqUnionLoginCallBack(nil, nil, error);
}

// 登录时网络有问题的回调
- (void)tencentDidNotNetWork {
    NSError *error = [NSError errorWithDomain:@"com.ots.base" code:0 userInfo:@{NSLocalizedDescriptionKey: @"网络错误"}];
    !self.qqUnionLoginCallBack ?: self.qqUnionLoginCallBack(nil, nil, error);
}


#pragma mark - API
/**
 *  功能:QQ注册1号店app
 */
- (BOOL)registeQQSDKWithAppId:(NSString*)appId {
    _tencentOAuth = nil;
    _appId = appId.copy;
    return nil != self.tencentOAuth;
}

+ (BOOL)handleOpenURL:(NSURL *)aUrl {
    if ([TencentOAuth CanHandleOpenURL:aUrl]){
        return [TencentOAuth HandleOpenURL:aUrl];
    }
    return NO;
}

+ (BOOL)canHandleOpenURL:(NSURL*)url {
    return [TencentOAuth CanHandleOpenURL:url];
}

#pragma mark -QQ Share
- (BOOL)handleOpenURLFromQQ:(NSURL *)aUrl {
    return [QQApiInterface handleOpenURL:aUrl delegate:self];
}

- (QQStatus)checkingQQStatus {
    QQStatus status = [self  QQPublishStatus];
    if (status != QQStatusSuccess) {
        [OTSAlertController alertWithTitle:nil message:@"您还没有安装QQ，要下载安装吗？" leftButtonTitle:@"取消" rightButtonTitle:@"下载" andCompleteBlock:^(OTSAlertController *alertController, NSInteger buttonIndex) {
            
            if (buttonIndex == 1) {
                [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[QQApiInterface getQQInstallUrl]]];
            }
            
        }];
    }
    return status;
}

- (QQStatus)QQPublishStatus {
    QQStatus status = QQStatusSuccess;
    if (![QQApiInterface isQQInstalled]) {
        status = QQStatusNoInstall;
    }
    if (![QQApiInterface isQQSupportApi]) {
        status = QQStatusNoSupportApi;
    }
    return status;
}

- (void)sendLinkContentWithTitle:(NSString *)aTitle
                 withDescription:(NSString *)aDescription
                   withThumbData:(NSData *)aThumbData
                     withLineUrl:(NSString *)aLinkUrl
                       withScene:(QQShareType)qqShareType {
    if ([self  QQPublishStatus] != QQStatusSuccess) {
        return;
    }
    
    NSURL *shareUrl = [NSURL URLWithString:aLinkUrl];
    QQApiNewsObject *newsObj = [QQApiNewsObject objectWithURL:shareUrl title:aTitle description:aDescription previewImageData:aThumbData];
    SendMessageToQQReq* req = [SendMessageToQQReq reqWithContent:newsObj];
    if (qqShareType == QQZone) {
        dispatch_async(dispatch_get_main_queue(), ^{
            QQApiSendResultCode sent = [QQApiInterface SendReqToQZone:req];
            
            if (sent != EQQAPISENDSUCESS) {
                [OTSAlertController alertWithMessage:@"QQ空间分享失败" andCompleteBlock:nil];
            }
        });
    } else {
        dispatch_async(dispatch_get_main_queue(), ^{
            QQApiSendResultCode sent = [QQApiInterface sendReq:req];
            if (sent != EQQAPISENDSUCESS) {
                [OTSAlertController alertWithMessage:@"QQ好友分享失败" andCompleteBlock:nil];
            }
        });
    }
}

#pragma mark - QQApiInterfaceDelegate QQ分享
- (void)onReq:(QQBaseReq *)req {
    
}

- (void)onResp:(QQBaseResp *)resp {
    [self postNotification:NotificationQQShare withObject:resp];
}

- (void)isOnlineResponse:(NSDictionary *)response {
    
}

#pragma mark - Getter & Setter
- (TencentOAuth *)tencentOAuth {
    if (!_tencentOAuth) {
        _tencentOAuth = [[TencentOAuth alloc] initWithAppId:self.appId andDelegate:self];
    }
    return _tencentOAuth;
}

+ (BOOL)supportSSOLogin {
    return [TencentOAuth iphoneQQSupportSSOLogin];
}

+ (BOOL)isQQShareValid {
    return [QQApiInterface isQQInstalled] && [QQApiInterface isQQSupportApi];
}

+ (NSString*)QQAppInstallUrl {
    return [QQApiInterface getQQInstallUrl];
}

@end
