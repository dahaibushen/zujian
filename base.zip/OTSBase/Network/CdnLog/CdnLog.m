//
//  CdnLog.m
//  OneStoreNetwork
//
//  Created by huangjiming on 5/3/16.
//  Copyright © 2016 OneStoreNetwork. All rights reserved.
//

#import "CdnLog.h"

@implementation CdnLog

@dynamic cdnLog, netType, saveTime;

@end
