//
//  CdnLogVO.m
//  OneStoreNetwork
//
//  Created by huangjiming on 5/3/16.
//  Copyright © 2016 OneStoreNetwork. All rights reserved.
//

#import "CdnLogVO.h"

@implementation CdnLogVO

@end
