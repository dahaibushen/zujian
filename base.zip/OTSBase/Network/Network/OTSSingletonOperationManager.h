//
//  OTSSingletonOperationManager.h
//  OneStoreCommon
//
//  Created by airspuer on 15/8/4.
//  Copyright (c) 2015年 OneStoreCommon. All rights reserved.
//

#import "OTSOperationManager.h"

@interface OTSSingletonOperationManager : OTSOperationManager

+ (OTSSingletonOperationManager *)sharedInstance;

@end
