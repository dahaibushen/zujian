//
//  OTSOperationManager.h
//  OneStoreFramework
//  功能:重写AFHTTPSessionManager
//  Created by huang jiming on 14-7-22.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>
#import "OTSOperationParam.h"
#import "OTSBatchOperaionParam.h"
#import <ReactiveObjC/RACSignal.h>

NS_ASSUME_NONNULL_BEGIN

FOUNDATION_EXPORT NSString *const OTSNetworkErrorNotification; //显示错误界面(无网络连接，或者服务器忙)
FOUNDATION_EXPORT NSString *const OTSHideNetworkErrorNotification; //隐藏无网络错误界面

@interface OTSOperationManager : AFHTTPSessionManager

/**
 *  初始化函数,宿主owner
 */
+ (instancetype)managerWithOwner:(nullable NSObject*)owner;

/**
 *  功能:发送请求
 */
- (nullable NSURLSessionDataTask *)requestWithParam:(OTSOperationParam *)aParam;

/**
 *  发送网络请求，创建信号
 *
 *  @param aParam 参数
 *
 *  @return RACSignal 对象
 */
- (RACSignal *)rac_requestWithParam:(OTSOperationParam *)aParam;

/**
 *  功能:取消当前manager queue中所有网络请求
 */
- (void)cancelAllOperations;

/**
 *  功能:执行错误界面缓存的operation
 */
- (void)performCachedOperationForShowErrorView;

/**
 *  功能:设置共享头数据
 */
+ (void)setGlobalHeaderValue:(nullable NSString*)value forKey:(NSString*)key;

/**
 *  功能:获取共享头数据
 */
+ (NSDictionary<NSString*, NSString*> *)getGlobalHeaderInfo;

@end

NS_ASSUME_NONNULL_END
