//
//  OTSSingletonOperationManager.m
//  OneStoreCommon
//
//  Created by airspuer on 15/8/4.
//  Copyright (c) 2015年 OneStoreCommon. All rights reserved.
//

#import "OTSSingletonOperationManager.h"
#import <OTSCore/OTSCore.h>


@implementation OTSSingletonOperationManager

DEF_SINGLETON(OTSSingletonOperationManager)

- (id)init
{
    if (self) {
        self = [[self class] managerWithOwner:nil];
    }
    return self;
}

@end
