//
//  OTSLogic.h
//  OneStoreFramework
//
//  Created by Aimy on 14-6-24.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSOperationManager.h"

@interface OTSLogic : NSObject

@property (nonatomic, strong, readonly) OTSOperationManager *operationManger;
@property (nonatomic) BOOL loading;

+ (id)logicWithOperationManager:(OTSOperationManager *)aOperationManger;

@end
