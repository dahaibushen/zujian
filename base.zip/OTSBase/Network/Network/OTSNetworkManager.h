//
//  OTSNetworkManager.h
//  OneStoreFramework
//  功能:网络管理
//  Created by Aimy on 14-6-29.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <Foundation/Foundation.h>

@class OTSOperationManager;

@interface OTSNetworkManager : NSObject

@property(nonatomic, getter=isUseHTTPSForVenus, assign)BOOL useHTTPSForVenus;//venus 接口是否用 HTTPS
@property(nonatomic, getter=isUseHTTPSForH5, assign)BOOL useHTTPSForH5;//H5 站点是否用 HTTPS
@property(nonatomic, getter=isUseHTTPSForInterface, assign)BOOL useHTTPSForInterface;// Interface接口是否用 HTTPS
@property(nonatomic, strong) NSArray *httpsWhiteList;//HTTPS 白名单

+ (OTSNetworkManager *)sharedInstance;

/**
 *  功能:产生一个operation manager,当owner销毁的时候一并销毁OTSOperationManager
 */
- (OTSOperationManager *)generateOperationMangerWithOwner:(id)owner;

/**
 *  功能:添加operation manager
 */
- (void)addOperationManger:(OTSOperationManager *)aOperationManager;

/**
 *  功能:移除operation manager
 */
- (void)removeOperationManger:(OTSOperationManager *)aOperationManager;

@end
