//
//  OTSLogic.m
//  OneStoreFramework
//
//  Created by Aimy on 14-6-24.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSLogic.h"

@interface OTSLogic ()

@property (nonatomic, strong) OTSOperationManager *operationManger;

@end

@implementation OTSLogic

+ (id)logicWithOperationManager:(OTSOperationManager *)aOperationManger;
{
    OTSLogic *logic = [[self alloc] init];
    logic.operationManger = aOperationManger;
    logic.loading = NO;
    return logic;
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

@end
