//
//  CMCLog.h
//  OneStoreNetwork
//
//  Created by Dingyang on 16/8/21.
//  Copyright © 2016年 OneStoreNetwork. All rights reserved.
//

#import "OTSManagedObject.h"

@interface CMSLog : OTSManagedObject

@property(nonatomic, copy) NSString *cmsLog;
@property(nonatomic, copy) NSDate *saveTime;

@end
