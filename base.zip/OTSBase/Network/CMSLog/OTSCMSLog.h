//
//  OTCCMSLog.h
//  OneStoreNetwork
//
//  Created by Dingyang on 16/8/21.
//  Copyright © 2016年 OneStoreNetwork. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OTSCMSLog : NSObject

+ (OTSCMSLog *)sharedInstance;

/**
 *  功能:保存cms日志
 */
- (void)saveCMSLog:(NSString *)CMSLog;

/**
 *  功能:发送cdn日志
 */
- (void)sendLog;

@end
