//
//  CMCLog.m
//  OneStoreNetwork
//
//  Created by Dingyang on 16/8/21.
//  Copyright © 2016年 OneStoreNetwork. All rights reserved.
//

#import "CMSLog.h"

@implementation CMSLog

@dynamic cmsLog, saveTime;

@end
