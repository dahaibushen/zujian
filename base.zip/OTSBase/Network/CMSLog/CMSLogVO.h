//
//  CMSLogVO.h
//  OneStoreNetwork
//
//  Created by Dingyang on 16/8/21.
//  Copyright © 2016年 OneStoreNetwork. All rights reserved.
//

#import <OTSCore/OTSValueObject.h>

@interface CMSLogVO : OTSValueObject
@property(nonatomic, copy) NSString *time;
@property (nonatomic,strong) NSMutableArray *list;
@property (nonatomic,copy) NSString *provinceid;
@property (nonatomic,copy) NSString *cityid;
@property (nonatomic,copy) NSString *devicecode;
@property (nonatomic,copy) NSString *clientSystem;
@property (nonatomic,copy) NSString *clientSystemversion;
@property (nonatomic,copy) NSString *appversion;

@end
