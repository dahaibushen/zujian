//
//  OTCCMSLog.m
//  OneStoreNetwork
//
//  Created by Dingyang on 16/8/21.
//  Copyright © 2016年 OneStoreNetwork. All rights reserved.
//

#import "OTSCMSLog.h"
#import <ReactiveObjC/ReactiveObjC.h>
#import "CMSLogVO.h"
#import "CMSLog.h"
#import "OTSClientInfo.h"
#import "OTSGlobalValue.h"
#import "OTSOperationManager.h"
#import "OTSNetworkManager.h"
#import "OTSCoreDataManager.h"
#import "OTSGlobalDefine.h"
#import <OTSCore/OTSCore.h>

#define OTS_SEND_CMS_LOG_TIME       60
#define OTS_SEND_CMS_LOG_COUNT      30

@interface OTSCMSLog()
@property(nonatomic, strong) OTSOperationManager *operationManger;
@property(nonatomic, strong) OTSCoreDataManager *coreDataManager;
@property(nonatomic, strong) NSDate *latestSendDate;//最近一次发送时间

@end

@implementation OTSCMSLog
DEF_SINGLETON(OTSCMSLog)

- (instancetype)init
{
    self = [super init];
    if (self) {
        WEAK_SELF;
        [[[NSNotificationCenter defaultCenter] rac_addObserverForName:OTS_CMS_LOG object:nil] subscribeNext:^(id x) {
            STRONG_SELF;
            
            NSNotification *notification = x;
            NSString *obj = notification.object;
            [self saveCMSLog:obj];
            [self sendLog];
        }];
    }
    return self;
}

#pragma mark - Property

- (OTSCoreDataManager *)coreDataManager
{
    if (_coreDataManager == nil) {
        _coreDataManager = [OTSCoreDataManager managerWithCoreDataPath:@"Model.momd"];
    }
    
    return _coreDataManager;
}

- (OTSOperationManager *)operationManger
{
    if (_operationManger == nil) {
        _operationManger = [[OTSNetworkManager sharedInstance] generateOperationMangerWithOwner:self];
    }
    
    return _operationManger;
}

- (NSDate *)latestSendDate
{
    if (_latestSendDate == nil) {
        _latestSendDate = [NSDate date];
    }
    return _latestSendDate;
}

/**
 *  功能:transform string to dictionary
 */
- (NSMutableDictionary *)transformStringToDictionary: (NSString *)obj {
   
    NSData *jsonData = [obj dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *perforMance = [NSJSONSerialization JSONObjectWithData:jsonData options:NSJSONReadingMutableLeaves error:nil];
    
    NSMutableDictionary *cmsProperty = @{}.mutableCopy;
    NSInteger dnsTime = 0, conttime = 0, downloadtime = 0, dmpttime = 0, requestTime = 0;
    [cmsProperty safeSetObject:[OTSClientInfo sharedInstance].nettype forKey:@"netType"];
    
    if ([[perforMance allKeys] containsObject:@"url"]) {
        [cmsProperty safeSetObject:[perforMance objectForKey:@"url"] forKey:@"url"];
    }
    
    if ([[perforMance allKeys] containsObject:@"ishijack"]) {
        [cmsProperty safeSetObject:[perforMance objectForKey:@"ishijack"] forKey:@"ishijack"];
    }
     // PerformanceTiming 时间为 miliseconds since the UNIX epoch 直接相减即可
    if ([[perforMance allKeys] containsObject:@"domainLookupStart"] && [[perforMance allKeys] containsObject:@"domainLookupEnd"]) {
         dnsTime = [[perforMance objectForKey:@"domainLookupEnd"] integerValue] - [[perforMance objectForKey:@"domainLookupStart"] integerValue];
        [cmsProperty safeSetObject:@(dnsTime).stringValue forKey:@"dnsTime"];
    }
    
    if ([[perforMance allKeys] containsObject:@"connectStart"] && [[perforMance allKeys] containsObject:@"connectEnd"]) {
         conttime = [[perforMance objectForKey:@"connectEnd"] integerValue] - [[perforMance objectForKey:@"connectStart"] integerValue];
        [cmsProperty safeSetObject:@(conttime).stringValue forKey:@"contTime"];
    }
    
    if ([[perforMance allKeys] containsObject:@"responseStart"] && [[perforMance allKeys] containsObject:@"responseEnd"]) {
         downloadtime = [[perforMance objectForKey:@"responseEnd"] integerValue] - [[perforMance objectForKey:@"responseStart"] integerValue];
        [cmsProperty safeSetObject:@(downloadtime).stringValue forKey:@"downloadTime"];
    }
    
    if ([[perforMance allKeys] containsObject:@"domLoading"] && [[perforMance allKeys] containsObject:@"domContentLoadedEventEnd"]) {
         dmpttime = [[perforMance objectForKey:@"domContentLoadedEventEnd"] integerValue] - [[perforMance objectForKey:@"domLoading"] integerValue];
        [cmsProperty safeSetObject:@(dmpttime).stringValue forKey:@"dmptTime"];
    }
    
    if ([[perforMance allKeys]containsObject:@"requestStart"] && [[perforMance allKeys]containsObject:@"responseStart"]) {
         requestTime = [[perforMance objectForKey:@"responseStart"] integerValue] - [[perforMance objectForKey:@"requestStart"] integerValue];
    }
    //    域名解析时间 +建立连接花费时间+请求花费时间+接收数据花费时间 +dom花费时间
    NSInteger totaltime = dnsTime + conttime + downloadtime + dmpttime + requestTime;
    [cmsProperty safeSetObject:@(totaltime).stringValue forKey:@"totaltime"];
    
    return cmsProperty;

 }

/**
 *  功能:保存cdn日志
 */
- (void)saveCMSLog:(NSString *)cmsLog
{
    [self.coreDataManager insertAndWaitWithClass:[CMSLog class] insertBlock:^(id entity) {
        CMSLog *obj = (CMSLog *)entity;
        obj.cmsLog = cmsLog;
        obj.saveTime = [NSDate date];
    }];
}
/**
 *  功能:发送cdn日志
 */

- (void)sendLog {
    
    NSDate *currentDate = [NSDate date];
    NSTimeInterval timeInterval = [currentDate timeIntervalSinceDate:self.latestSendDate];//单位秒
    
    NSUInteger logCount = [self.coreDataManager countWithEntityName:[CMSLog class] Predicate:nil];
    
    if (logCount >= OTS_SEND_CMS_LOG_COUNT || timeInterval > OTS_SEND_CMS_LOG_TIME) {
        NSString *cmcLogString =[self p_cmsLog];
        if (cmcLogString.length > 0) {
            [self p_sendLogWithLogs:cmcLogString];
        }
        [self.coreDataManager deleteAndWaitWithEntityName:[CMSLog class] predicate:nil deleteCount:0];
    }
}

/**
 *  功能:获取所有日志字符串
 */
- (NSString *)p_cmsLog {
    NSArray * allCMSLogs = [self.coreDataManager fetchWithEntityName:[CMSLog class] predicate:nil fetchLimit:0 sortDescriptors:nil];
    
    //拼装日志
    CMSLogVO *logVO =[CMSLogVO new];
    NSTimeInterval dTime = [OTSGlobalValue sharedInstance].dTime;//服务器时间-本地时间
    long long serverTimeStamp = ([[NSDate date] timeIntervalSince1970]+dTime) * 1000;//精确到毫秒
    logVO.time = [NSString stringWithFormat:@"%lld", serverTimeStamp];
    
    NSMutableArray *allLogs = @[].mutableCopy;
    for (int i=0; i<allCMSLogs.count; i++) {
        CMSLog *fetchedObj = (CMSLog*)[allCMSLogs safeObjectAtIndex:i];
        NSString *log = [fetchedObj cmsLog];
        NSMutableDictionary *oneLog = [self transformStringToDictionary:log];
        if (oneLog) {
            [allLogs safeAddObject:oneLog];
        }
    }
    logVO.list = allLogs;
    NSDictionary *headerInfo = [OTSOperationManager getGlobalHeaderInfo];
    logVO.provinceid = headerInfo[@"provinceId"];
    logVO.cityid = headerInfo[@"cityId"];
    logVO.devicecode = [OTSClientInfo sharedInstance].deviceCode;
    logVO.clientSystem = [OTSClientInfo sharedInstance].clientSystem;
    logVO.clientSystemversion = [OTSClientInfo sharedInstance].clientVersion;
    logVO.appversion = [OTSClientInfo sharedInstance].clientAppVersion;
    
    NSString *cmsLogString = [logVO toJSONString];
    
    return cmsLogString;
}

/**
 *  功能:发送所有日志
 */
- (void)p_sendLogWithLogs:(NSString *)cmsLogs {
    
    //发送日志
    NSMutableDictionary *mDict = @{}.mutableCopy;
    [mDict safeSetObject:cmsLogs forKey:@"message"];
    [mDict safeSetObject:@(3) forKey:@"type"];
    OTSOperationParam *param = [OTSOperationParam paramWithUrl:@"http://interface.m.yhd.com/mobilelog/cmsReceive.action" type:kRequestPost param:mDict callback:nil];
    param.needSignature = NO;
    [self.operationManger requestWithParam:param];
    
    //记录最新发送时间
    self.latestSendDate = [NSDate date];
}

@end
