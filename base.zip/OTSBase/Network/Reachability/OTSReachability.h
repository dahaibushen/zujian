//
//  OTSReachability.h
//  OneStoreFramework
//
//  Created by qinqubo on 14/10/4.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *const NotificationNetworkStatusChange;//网络状态更新

typedef NS_ENUM(NSInteger, ENetWorkStatus) {
    kConnectToNull = 0,
    kConnectTo2G   = 1 << 0,
    kConnectTo3G   = 1 << 1,
    kConnectTo4G   = 1 << 2,
    kConnectToWWAN = 1 << 3,
    kConnectToWifi = 1 << 4,
    /**
     *  联网了
     */
    kConnectToAny  = (kConnectTo2G | kConnectTo3G | kConnectTo4G | kConnectToWWAN | kConnectToWifi)
};

@interface OTSReachability : NSObject

+ (OTSReachability *)sharedInstance;

@property (nonatomic, assign) ENetWorkStatus currentNetStatus;

/**
 *  功能:获取网络连接状况
 */
- (void)generateNetStatus;

@end
