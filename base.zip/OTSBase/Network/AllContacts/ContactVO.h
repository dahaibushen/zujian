//
//  ContactVO.h
//  OneStoreNetwork
//
//  Created by admin on 2016/11/24.
//  Copyright © 2016年 OneStoreNetwork. All rights reserved.
//

#import "OTSManagedObject.h"

@interface ContactVO : OTSManagedObject

@property (nonatomic, strong) NSString *contactMobile;
@property (nonatomic, strong) NSString *loginUserID;

@end
