//
//  OTSSendAllContacts.h
//  OTSVO
//
//  Created by admin on 2016/11/15.
//  Copyright © 2016年 OTSVO. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OTSSendAllContacts : NSObject

+ (OTSSendAllContacts *)sharedInstance;

/**
 *  功能:获取联系人信息
 */
- (void)sendCellPhoneContactsNamesAndTelNumbers;

@end
