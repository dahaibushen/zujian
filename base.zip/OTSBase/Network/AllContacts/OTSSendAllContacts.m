//
//  OTSSendAllContacts.m
//  OTSVO
//
//  Created by admin on 2016/11/15.
//  Copyright © 2016年 OTSVO. All rights reserved.
//

#import "OTSSendAllContacts.h"

#import <AddressBookUI/AddressBookUI.h>
#import "ContactVO.h"
#import <OTSCore/OTSCore.h>
#import <OTSCore/NSString+plus.h>
#import "OTSGlobalValue.h"
#import "OTSCoreDataManager.h"
#import "OTSOperationManager.h"
#import "OTSNetworkManager.h"


static const NSInteger MaxTransforAmount = 500;
static NSString *const signatureKey = @"asdsdd9d405b9ba0";

@interface OTSSendAllContacts ()

@property(nonatomic, strong) OTSOperationManager *operationManger;
@property(nonatomic, strong) OTSCoreDataManager *coreDataManager;
@property(nonatomic, assign) NSInteger faildSendTimes;
@property(nonatomic, strong) NSString *userId;

@end

@implementation OTSSendAllContacts
DEF_SINGLETON(OTSSendAllContacts)

- (void)sendCellPhoneContactsNamesAndTelNumbers {
    _faildSendTimes = 0;
    NSMutableArray *allContactsArray = @[].mutableCopy;
    ABAddressBookRef addressBookRef = ABAddressBookCreate();
    CFArrayRef arrayRef = ABAddressBookCopyArrayOfAllPeople(addressBookRef);
    long count = CFArrayGetCount(arrayRef);
    for (int i = 0; i < count; i++) {
        //获取联系人对象的引用
        ABRecordRef people = CFArrayGetValueAtIndex(arrayRef, i);
        //获取当前联系人的电话 数组
        ABMultiValueRef phones = ABRecordCopyValue(people, kABPersonPhoneProperty);
        for (NSInteger j = 0; j < ABMultiValueGetCount(phones); j++) {
            NSString *rawPhone = (__bridge_transfer NSString *)(ABMultiValueCopyValueAtIndex(phones, j));
            if ([self generatePureTelNumberWithRawNumber:rawPhone]) {
                NSString *purePhone  = [self generatePureTelNumberWithRawNumber:rawPhone];
                [allContactsArray addObject:purePhone];
            }
        }
        CFRelease(phones);
    }
    CFRelease(addressBookRef);
    
    CFRelease(arrayRef);
    
    

    NSPredicate *coreDataPredicate = [NSPredicate predicateWithFormat:@"(%K = %@)",@"loginUserID",[NSString stringWithFormat:@"%@", self.userId]];
    NSArray * allStoredContacts = [self.coreDataManager fetchWithEntityName:[ContactVO class] predicate:coreDataPredicate fetchLimit:0 sortDescriptors:nil];
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"NOT(SELF in %@.contactMobile)",allStoredContacts,allStoredContacts];
    NSArray * filterdArray = [allContactsArray filteredArrayUsingPredicate:predicate];
    if (filterdArray.count == 0) {
        return;
    }
    [self sendAllContactsInfor:filterdArray];
}

- (void)sendAllContactsInfor:(NSArray *)inforArray {
    NSInteger sendTotalTimes = inforArray.count / MaxTransforAmount + ((inforArray.count % MaxTransforAmount) > 0 ? 1 : 0);
    for (int i = 0 ; i < sendTotalTimes; i++) {
        NSRange range =  NSMakeRange(i * MaxTransforAmount, MIN(MaxTransforAmount, (inforArray.count - i * MaxTransforAmount)));
        NSIndexSet *index = [NSIndexSet indexSetWithIndexesInRange: range];
        NSMutableArray * batchArray = [inforArray objectsAtIndexes:index].mutableCopy;
        dispatch_queue_t queue =  dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
        dispatch_async(queue, ^{
            [self batchSendContactsInfor:batchArray];
        });
    }
}
//批量发送
- (void)batchSendContactsInfor:(NSMutableArray *)inforArray {
    NSString *mobileJsonString = [self transforToJsonWithArray:inforArray];
    if (!mobileJsonString) {
        return;
    }
    NSString *mobileAESString = [self getAESStringWithOriginalString:mobileJsonString];
    //发送日志
    NSMutableDictionary *mDict = @{}.mutableCopy;
    [mDict safeSetObject:mobileAESString forKey:@"phonebookfriendsinfo"];
    [mDict safeSetObject:[OTSGlobalValue sharedInstance].token forKey:@"ut"];
    [mDict safeSetObject:@1 forKey:@"channelid"];
    WEAK_SELF;
    OTSOperationParam *param = [OTSOperationParam paramWithBusinessName:@"passport" methodName:@"getPhoneBookFriends" versionNum:nil type:kRequestPost param:mDict callback:^(id aResponseObject, NSError *anError) {
        STRONG_SELF;
        if (!anError && aResponseObject) {
            _faildSendTimes = 0;
            [self storageTransferdPhoneNumberArray:inforArray];
        }
    }];
    param.needSignature = YES;
    [self.operationManger requestWithParam:param];
}

- (NSString *)getAESStringWithOriginalString:(NSString *)originalString {
    return [originalString encryptByAESKey:signatureKey];
}

- (NSString *)generatePureTelNumberWithRawNumber:(NSString *)mobilNum {
    if (!mobilNum) {
        return nil;
    }
    else if (mobilNum.length > 17) {//过长
        return nil;
    }
    NSString *tempPhone = [mobilNum stringByReplacingOccurrencesOfString:@"+86" withString:@""];
    NSString *newPhone = [tempPhone stringByReplacingOccurrencesOfString:@"-" withString:@""];
    newPhone = [newPhone stringByReplacingOccurrencesOfString:@" " withString:@""];
    if (![newPhone isPureInt]) {//不全是数字
        return nil;
    }
    return newPhone;
}

- (NSString *)transforToJsonWithArray:(NSMutableArray *)array {
    NSError *error = nil;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:array
                                                       options:NSJSONWritingPrettyPrinted
                                                         error:&error];
    NSString *jsonString;
    if ([jsonData length] > 0 && error == nil) {
        jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    return jsonString;
}

- (void)storageTransferdPhoneNumberArray:(NSMutableArray *)numberArray {
    NSString *loginUserID = [NSString stringWithFormat:@"%@", self.userId];
    for (NSString *phoneObj in numberArray) {
        [self.coreDataManager insertAndWaitWithClass:[ContactVO class] insertBlock:^(id entity) {
            ContactVO * vo = (ContactVO *)entity;
            vo.contactMobile = phoneObj;
            vo.loginUserID = loginUserID;
        }];
    }
}
#pragma mark setter&getter

- (OTSCoreDataManager *)coreDataManager
{
    if (_coreDataManager == nil) {
        _coreDataManager = [OTSCoreDataManager managerWithCoreDataPath:@"Model.momd"];
    }
    return _coreDataManager;
}

- (OTSOperationManager *)operationManger
{
    if (_operationManger == nil) {
        _operationManger = [[OTSNetworkManager sharedInstance] generateOperationMangerWithOwner:self];
    }
    return _operationManger;
}

- (NSString*)userId {
    id service = NSClassFromString(@"OTSAccountService");
    NSString *userId = nil;
    
    OTSSuppressPerformSelectorLeakWarning(
                                          userId = [service performSelector:NSSelectorFromString(@"userId")];
                                          );
    return userId;
}

@end

