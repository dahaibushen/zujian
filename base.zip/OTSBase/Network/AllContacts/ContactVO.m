//
//  ContactVO.m
//  OneStoreNetwork
//
//  Created by admin on 2016/11/24.
//  Copyright © 2016年 OneStoreNetwork. All rights reserved.
//

#import "ContactVO.h"

@implementation ContactVO
@dynamic contactMobile,loginUserID;
@end
