//
//  OTSUpLoadNetworkInterface.m
//  OneStoreFramework
//
//  Created by airspuer on 14-11-3.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSNIUpLoad.h"
#import <OTSBase/OTSBase.h>
#import <OTSCore/OTSNetworkQuery.h>

@interface OTSNIUpLoad()

@end

@implementation OTSNIUpLoad

+ (OTSUploadOperationParam *)uploadFileForReturn:(NSMutableArray *)aFileValues
                                            param:(id)paramDic
                                 completionBlock:(OTSCompletionBlock)aCompletionBlock;
{     
    NSString *currentUrlAddress = @"http://e.m.yhd.com/commentH5/appImageUpload.do";
    
    OTSUploadOperationParam *uploadParam = [OTSUploadOperationParam paramWithUrl:currentUrlAddress name:@"files" files:aFileValues param:paramDic mimeType:kJpg callback:^(id aResponseObject, NSError *anError) {
        aCompletionBlock(aResponseObject,anError);
    }];
    return uploadParam;
}



/**
 *  功能:获取签名字符串
 */
- (NSString *)getSignature:(NSDictionary *)aDict timeStamp:(NSString *)aTimeStamp
{
    NSMutableDictionary *theDict = [aDict mutableCopy];
    //signature_method
    [theDict safeSetObject:@"md5" forKey:@"signature_method"];
    //timestamp
    [theDict safeSetObject:aTimeStamp forKey:@"timestamp"];
    //trader
    [theDict safeSetObject:[OTSClientInfo sharedInstance].traderName forKey:@"trader"];
    
    //拼装
    NSMutableString *mString = [NSMutableString string];
    NSArray *queryPairs = [OTSNetworkQuery queryPairsFromDictionary:theDict];
    NSArray *sortedQueryPairs = [queryPairs sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)];
    for (OTSQueryPair *queryPair in sortedQueryPairs) {
        [mString safeAppendString:[queryPair queryString]];
    }
    
    //加上私钥
    NSString *signatureKey = [OTSKeychain getKeychainValueForType:KeyChainSignatureKey];//[[OTSGlobalValue sharedInstance].signatureKey];
    
    
    [mString safeAppendString:signatureKey];
    
    //md5运算
    NSString *signature = mString.md5String;
    signature = [signature uppercaseString];
    
    return signature;
}




@end
