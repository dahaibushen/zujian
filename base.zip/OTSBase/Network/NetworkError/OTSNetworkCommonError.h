//
//  OTSNetworkCommonError.h
//  OneStoreFramework
//
//  Created by huangjiming on 8/15/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "OTSNetworkError.h"

@interface OTSNetworkCommonError : OTSNetworkError

+ (OTSNetworkCommonError *)sharedInstance;

@end
