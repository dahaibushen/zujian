//
//  OTSNetworkLog.h
//  OneStoreFramework
//  功能:接口日志
//  Created by huang jiming on 14-8-6.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "OTSOperationParam.h"
#import <OTSCore/OTSValueObject.h>

@interface OTSNetworkLog : OTSValueObject

NS_ASSUME_NONNULL_BEGIN

+ (instancetype)sharedInstance;

/**
 *  功能:保存接口日志
 */
- (void)saveLogWithParam:(OTSOperationParam * _Nullable)aParam;

/**
 *  功能:将本地保存的接口日志发送到服务器
 */
- (void)sendLog;

NS_ASSUME_NONNULL_END

@end
