//
//  OTSNetworkLog.m
//  OneStoreFramework
//
//  Created by huang jiming on 14-8-6.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSNetworkLog.h"
#import "NetworkLogVO.h"
#import "NetworkLog.h"
#import "OTSCoreDataManager.h"
#import <OTSCore/OTSJSONUtil.h>
#import "OTSNetworkManager.h"
#import "OTSReachability.h"
#import "OTSOperationManager.h"
#import <OTSCore/Foundation+safe.h>
#import "OTSGlobalValue.h"
#import <OTSCore/NSFileManager+Utility.h>

#define LOG_COREDATA @"Model.momd"
#define FETCH_LIMIT_FOR_NOT_WIFT    10
#define FETCH_LIMIT_FOR_WIFT        5

@interface OTSOperationParam ()

#pragma mark - 拼装requestUrl相关
@property(nonatomic, readonly) NSString *methodName;                    //方法名
@property(nonatomic, copy) NSString *businessName;                      //业务名

#pragma mark - 接口调用相关
@property(nonatomic, copy) NSString *requestUrl;                        //请求url

#pragma mark - 接口日志相关
@property(nonatomic, assign) NSTimeInterval startTimeStamp;             //接口调用开始时间，精确到ms
@property(nonatomic, assign) NSTimeInterval endTimeStamp;               //接口调用结束时间，精确到ms
@property(nonatomic, assign) NSInteger errorType;                       //接口错误类型(0无错误，1接口超时，2接口出错，3rtn_code不为0)
@property(nonatomic, assign) NSString *errorCode;                       //接口错误码

@end

@interface OTSNetworkLog()

@property(nonatomic, copy) NSString *requestUrl;//请求url
@property(nonatomic, strong) NSNumber *costTime;//耗费时间
@property(nonatomic, copy) NSString *netType;//网络类型
@property(nonatomic, strong) NSNumber *errorType;//0:无错误 1:接口超时 2:接口错误 3:rtn_code不为0
@property(nonatomic, copy) NSString *errorCode;//rtn_code不为0时的错误码
@property(nonatomic, strong) NSNumber *timeStamp;//当前时间戳，精确到秒

@property(nonatomic, strong) OTSOperationManager *operationManger;
@property(nonatomic, strong) OTSCoreDataManager *coreDataManager;

@end

@implementation OTSNetworkLog

+ (instancetype)sharedInstance
{
    static dispatch_once_t once;
    static OTSNetworkLog * __singleton__;
    dispatch_once(&once, ^{
        __singleton__ = [[OTSNetworkLog alloc] init];
    } );
    
    return __singleton__;
}

- (id)init
{
    self = [super init];
    if (self != nil) {
        [self deleteOldLogs];
    }
    return self;
}

#pragma mark - Property
- (OTSOperationManager *)operationManger
{
    if (_operationManger == nil) {
        _operationManger = [[OTSNetworkManager sharedInstance] generateOperationMangerWithOwner:self];
    }
    
    return _operationManger;
}

- (OTSCoreDataManager *)coreDataManager
{
    if (_coreDataManager == nil) {
        _coreDataManager = [OTSCoreDataManager managerWithCoreDataPath:LOG_COREDATA];
    }
    
    return _coreDataManager;
}

#pragma mark - Inner
/**
 *  功能:删除30天以前的日志
 */
- (void)deleteOldLogs
{
    NSArray *networkLogs = [self.coreDataManager fetchWithEntityName:[NetworkLog class] predicate:nil pageSize:@100 sortDescriptors:nil].copy;
    for (NetworkLog *networkLog in networkLogs) {
        NSDate *saveTime = networkLog.saveTime;
        NSTimeInterval timeInterval = [saveTime timeIntervalSinceNow];
        if (saveTime==nil || timeInterval < -30*24*3600) {
            [self.coreDataManager deleteWithManageObject:networkLog];
        }
    }
}

#pragma mark - API

- (void)saveLogWithParam:(OTSOperationParam *)aParam
{
    if (aParam.methodName.length <= 0) {//没有接口名字的不保存
        return;
    }
    if ([aParam.methodName rangeOfString:@"/mobilelog/receive.action"].location != NSNotFound) {//发送日志接口不保存
        return;
    }
    if (aParam.errorType != 0) {//rtn_code不为0的不保存
        return;
    }
    
    NetworkLogVO *logVO = [[NetworkLogVO alloc] init];
    //方法名
    NSString *frontStr = [[aParam.methodName componentsSeparatedByString:@"?"] safeObjectAtIndex:0];
    NSArray *componets = [frontStr componentsSeparatedByString:@"/"];
    if (componets.count > 1) {
        NSString *businessN = [componets safeObjectAtIndex:componets.count-2];
        NSString *methodN = [componets lastObject];
        logVO.methodname = [NSString stringWithFormat:@"/%@/%@", businessN, methodN];
    } else {
        logVO.methodname = [NSString stringWithFormat:@"/%@/%@", aParam.businessName, aParam.methodName];
    }
    
    //耗时
    logVO.duration = @(aParam.endTimeStamp - aParam.startTimeStamp);
    
    //时间戳
    NSTimeInterval dTime = [OTSGlobalValue sharedInstance].dTime;//服务器时间-本地时间
    long long serverTimeStamp = ([[NSDate date] timeIntervalSince1970]+dTime) * 1000;//精确到毫秒
    logVO.timestamp = [NSString stringWithFormat:@"%lld", serverTimeStamp];
    //接口错误类型
    logVO.errortype = [NSNumber numberWithInteger:aParam.errorType];
    //省份id
//    logVO.provinceId = OTSAddressService.API.addressVO.provinceId;
    //trader
    logVO.trader = [OTSClientInfo sharedInstance];
    //存储
    NSString *theStr = [logVO toJSONString];
#ifdef OTSTest
    if (theStr.length > 0) {
        [theStr writeToFile:[OTSNetworkLog logVOToJSONStringPathForCache] atomically:YES];
    }
#endif
    [self.coreDataManager insertAndWaitWithClass:[NetworkLog class] insertBlock:^(id entity) {
        NetworkLog *obj = (NetworkLog *)entity;
        obj.networkLog = theStr;
        obj.saveTime = [NSDate date];
    }];
}

+ (NSString *)logVOToJSONStringPathForCache
{
    NSString *filePath = [[NSFileManager appLibPath] stringByAppendingPathComponent:@"Caches/logVOToJSONString/test.txt"];
    return filePath;
}

/**
 *  功能:将本地保存的接口日志发送到服务器
 */
- (void)sendLog
{
    if ([OTSReachability sharedInstance].currentNetStatus == kConnectToWifi) {//连接到wifi才发送
        NSUInteger networkCount = [self.coreDataManager countWithEntityName:[NetworkLog class] Predicate:nil];
        NSArray *networkLogs;
        if (networkCount < FETCH_LIMIT_FOR_WIFT) {
            return;
        } else if (networkCount>=FETCH_LIMIT_FOR_WIFT && networkCount<FETCH_LIMIT_FOR_NOT_WIFT) {
            networkLogs = [self.coreDataManager fetchWithEntityName:[NetworkLog class] predicate:nil fetchLimit:FETCH_LIMIT_FOR_WIFT sortDescriptors:nil];
        } else {
            networkLogs = [self.coreDataManager fetchWithEntityName:[NetworkLog class] predicate:nil fetchLimit:FETCH_LIMIT_FOR_NOT_WIFT sortDescriptors:nil];
        }
        
        //拼装日志
        NSMutableString *allLogs = [[NSMutableString alloc] init];
        for (int i=0; i<networkLogs.count; i++) {
            NetworkLog* fetchedObj = (NetworkLog*)[networkLogs safeObjectAtIndex:i];
            NSString *oneLog = [fetchedObj networkLog];
            if (oneLog != nil) {
                if (i+1 == networkLogs.count) {
                    [allLogs appendFormat:@"%@", oneLog];
                } else {
                    [allLogs appendFormat:@"%@$", oneLog];
                }
            }
        }
        
        //发送日志
        if (allLogs.length > 0) {
            NSMutableDictionary *mDict = [NSMutableDictionary dictionary];
            [mDict safeSetObject:allLogs forKey:@"message"];
            OTSOperationParam *param = [OTSOperationParam paramWithUrl:@"http://interface.m.yhd.com/mobilelog/receive.action" type:kRequestPost param:mDict callback:nil];
            param.needSignature = NO;
            [self.operationManger requestWithParam:param];
        }
        
        //删除日志
        [self.coreDataManager deleteAndWaitWithEntityName:[NetworkLog class] predicate:nil deleteCount:networkLogs.count];
        //继续发送
        if (networkCount > FETCH_LIMIT_FOR_NOT_WIFT) {
            [self sendLog];
        }
    }
}

@end

