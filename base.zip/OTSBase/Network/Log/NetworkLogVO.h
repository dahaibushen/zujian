//
//  NetworkLogVO.h
//  OTSBase
//
//  Created by liuwei7 on 2017/9/28.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "OTSClientInfo.h"
#import <OTSCore/OTSValueObject.h>

@interface NetworkLogVO : OTSValueObject

@property(nonatomic, strong) NSString *methodname;
@property(nonatomic, strong) NSNumber *duration;//接口耗时，精确到毫秒
@property(nonatomic, strong) NSNumber *errortype;
@property(nonatomic, strong) NSString *timestamp;//时间戳，精确到秒
@property(nonatomic, strong) NSNumber *provinceId;
@property(nonatomic, strong) OTSClientInfo *trader;

@end
