//
//  NetworkLog.m
//  OneStoreFramework
//
//  Created by huang jiming on 14-8-7.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "NetworkLog.h"

@implementation NetworkLog

@dynamic networkLog;
@dynamic saveTime;

@end
