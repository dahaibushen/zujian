//
//  OTSURLCache.m
//  OneStoreFramework
//
//  Created by huang jiming on 14-7-28.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSURLCache.h"
#import <OTSCore/OTSCore.h>

@implementation OTSURLCache

#pragma mark - Life Cycle
+ (instancetype)standardURLCache {
    static OTSURLCache *_standardURLCache = nil;
    static dispatch_once_t onceTokenInCache;
    dispatch_once(&onceTokenInCache, ^{
        _standardURLCache = [[OTSURLCache alloc] initWithMemoryCapacity:(6 * 1024 * 1024) diskCapacity:(50 * 1024 * 1024) diskPath:nil];
    });
    return _standardURLCache;
}

- (NSCachedURLResponse *)cachedResponseForRequest:(NSURLRequest *)aRequest {
    NSURLRequest *modifiedRequest = [self getModifiedRequest:aRequest];
    return [super cachedResponseForRequest:modifiedRequest];
}

- (void)storeCachedResponse:(NSCachedURLResponse *)cachedResponse
                 forRequest:(NSURLRequest *)aRequest {
    NSURLRequest *modifiedRequest = [self getModifiedRequest:aRequest];
    [super storeCachedResponse:cachedResponse forRequest:modifiedRequest];
}

- (void)removeCachedResponseForRequest:(NSURLRequest *)request {
    NSURLRequest *modifiedRequest = [self getModifiedRequest:request];
    [super removeCachedResponseForRequest:modifiedRequest];
}

#pragma mark - Inner
/**
 *  功能:获取经过处理的request，把参数中跟签名、时间戳相关的参数及trader去掉
 *  aRequest:原request
 *  返回:经过处理的request
 */
- (NSURLRequest *)getModifiedRequest:(NSURLRequest *)aRequest {
    NSString *requestUrlStr = aRequest.URL.absoluteString;
    NSArray *componentArray = [requestUrlStr componentsSeparatedByString:@"?"];
    if (componentArray.count > 1) {
        NSString *headStr = [componentArray safeObjectAtIndex:0];
        NSString *queryUrl = [componentArray lastObject];
        NSArray *paramArray = [queryUrl componentsSeparatedByString:@"&"];
        NSMutableArray *modifiedParamArray = [@[] mutableCopy];
        for (NSString *paramStr in paramArray) {
            if (![paramStr hasPrefix:@"signature="] &&
                ![paramStr hasPrefix:@"signature_method="] &&
                ![paramStr hasPrefix:@"timestamp="] &&
                ![paramStr hasPrefix:@"trader=iosSystem"]) {
                [modifiedParamArray safeAddObject:paramStr];
            }
        }
        NSString *modifiedParamStr = [modifiedParamArray componentsJoinedByString:@"&"];
        
        NSString *modifiedUrlStr = nil;
        if (modifiedParamStr.length > 0) {
            modifiedUrlStr = [NSString stringWithFormat:@"%@?%@", headStr, modifiedParamStr];
        } else {
            modifiedUrlStr = headStr;
        }
        
        NSMutableURLRequest *modifiedRequest = [aRequest mutableCopy];
        modifiedRequest.URL = [NSURL URLWithString:modifiedUrlStr];
        return modifiedRequest;
        
    } else {
        return aRequest;
    }
}

@end
