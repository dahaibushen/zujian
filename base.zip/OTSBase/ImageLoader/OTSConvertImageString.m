//
//  OTSConvertImageString.m
//  OneStoreFramework
//
//  Created by zhangbin on 14-9-28.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSConvertImageString.h"
#import <OTSCore/OTSCore.h>

//支持phone pad
#define kMaxImageWidth  1024
#define kMaxImageHeight 1024

const NSInteger kMaxImagePixel = 1600;

@implementation OTSConvertImageString

+ (NSString *)convertPicURL:(NSString *)picURL toSize:(CGSize)size {
    return [self convertPicURL:picURL viewWidth:size.width viewHeight:size.height];
}

+ (NSString *)convertPicURL:(NSString *)picURL
                  viewWidth:(NSInteger)aWidth
                 viewHeight:(NSInteger)aHeight {
    return [self convertPicURL:picURL viewWidth:aWidth viewHeight:aHeight withImageSizeLinkType:OTSImageSizeLinkType_x];
}

+ (NSString *)convertPicURL:(NSString *)picURL
                  viewWidth:(NSInteger)aWidth
                 viewHeight:(NSInteger)aHeight
      withImageSizeLinkType:(OTSImageSizeLinkType)imageSizeLinkType {
    if (aWidth > kMaxImageWidth) {
        aWidth = kMaxImageWidth;
    }
    if (aHeight > kMaxImageHeight) {
        aHeight = kMaxImageHeight;
    }

    CGFloat scale = [UIScreen mainScreen].scale;
    CGFloat widthPixel = aWidth * scale;
    CGFloat heightPixel = aHeight * scale;

    if (widthPixel > kMaxImagePixel || heightPixel > kMaxImagePixel) {
        CGFloat rate = kMaxImagePixel / MAX(widthPixel, heightPixel);
        if (widthPixel > heightPixel) {
            widthPixel = kMaxImagePixel;
            heightPixel = heightPixel * rate;
        } else {
            heightPixel = kMaxImagePixel;
            widthPixel = widthPixel * rate;
        }
    }

    NSString *sizeString = nil;
    if (imageSizeLinkType == OTSImageSizeLinkType_y) {
        //y表示填充,不会有白边
        sizeString = [NSString stringWithFormat:@"%ldy%ld", (long) widthPixel, (long) heightPixel];
        return [self convertPicURL:picURL toSizeFormat:sizeString withImageSizeLinkType:OTSImageSizeLinkType_y];
    } else {
        //x 表等比缩放
        sizeString = [NSString stringWithFormat:@"%ldx%ld", (long) widthPixel, (long) heightPixel];
        return [self convertPicURL:picURL toSizeFormat:sizeString withImageSizeLinkType:OTSImageSizeLinkType_x];
    }
}

+ (NSString *)convertPicURL:(NSString *)picURL toSizeFormat:(NSString *)sizeStr {

    return [self convertPicURL:picURL toSizeFormat:sizeStr withImageSizeLinkType:OTSImageSizeLinkType_x];

}

+ (NSString *)convertPicURL:(NSString *)picURL toSizeFormat:(NSString *)sizeStr withImageSizeLinkType:(OTSImageSizeLinkType)imageSizeLinkType {
    if (!picURL) {
        return nil;
    }

    if (!sizeStr) {
        return picURL;
    }

    static NSRegularExpression *sizeRE_x = nil, *sizeRE_y = nil, *serviceRE = nil, *sizeSubRE_x = nil, *sizeSubRE_y = nil, *extSubRE = nil;

    NSRegularExpression *sizeRE = nil, *sizeSubRE = nil;

    if (!sizeRE_y) {
        sizeRE_y = [NSRegularExpression regularExpressionWithPattern:@"\\d{1,4}y\\d{1,4}.(jpg|webp|png)$" options:0 error:nil];
    }
    if (!sizeSubRE_y) {
        sizeSubRE_y = [NSRegularExpression regularExpressionWithPattern:@"\\d{1,4}y\\d{1,4}" options:0 error:nil];
    }

    if (!sizeRE_x) {
        sizeRE_x = [NSRegularExpression regularExpressionWithPattern:@"\\d{1,4}x\\d{1,4}.(jpg|webp|png)$" options:0 error:nil];
    }
    if (!sizeSubRE_x) {
        sizeSubRE_x = [NSRegularExpression regularExpressionWithPattern:@"\\d{1,4}x\\d{1,4}" options:0 error:nil];
    }

    if (imageSizeLinkType == OTSImageSizeLinkType_y) {
        sizeRE = sizeRE_y;
        sizeSubRE = sizeSubRE_y;
    } else {
        sizeRE = sizeRE_x;
        sizeSubRE = sizeSubRE_x;
    }

    if (!extSubRE) {
        //后缀
        extSubRE = [NSRegularExpression regularExpressionWithPattern:@".(jpg|webp|png)$" options:0 error:nil];
    }

    if (!serviceRE) {
        //设置服务器url正则表达式
        serviceRE = [NSRegularExpression regularExpressionWithPattern:@"^http://d\\d+.yihaodian(img)?.com/" options:0 error:nil];
    }

    //获取尺寸range
    NSRange sizeRange = [[sizeRE firstMatchInString:picURL options:0 range:NSMakeRange(0, [picURL length])] rangeAtIndex:0];
    if (NSEqualRanges(sizeRange, NSMakeRange(0, 0))) {
        if (imageSizeLinkType == OTSImageSizeLinkType_y) {
            sizeRE = sizeRE_x;
            sizeSubRE = sizeSubRE_x;
        } else {
            sizeRE = sizeRE_y;
            sizeSubRE = sizeSubRE_y;
        }
        sizeRange = [[sizeRE firstMatchInString:picURL options:0 range:NSMakeRange(0, [picURL length])] rangeAtIndex:0];
    }

    //获取服务器range
    NSRange serviceRange = [[serviceRE firstMatchInString:picURL options:0 range:NSMakeRange(0, [picURL length])] rangeAtIndex:0];

    //处理
    if (sizeRange.length > 0 && serviceRange.length > 0) {
        // 给的图片url，已经限制了图片大小，所以替换大小字段
        NSString *sizeString = [picURL substringWithRange:sizeRange];
        NSString *subSizeString = [sizeSubRE stringByReplacingMatchesInString:sizeString
                                                                      options:0
                                                                        range:NSMakeRange(0, sizeString.length)
                                                                 withTemplate:sizeStr];
        NSString *str = [sizeRE stringByReplacingMatchesInString:picURL
                                                         options:0
                                                           range:NSMakeRange(0, picURL.length)
                                                    withTemplate:subSizeString];
        return str;
    } else if (serviceRange.length > 0) {
        // 给的图片url，没有限制了图片大小，加上大小字段
        NSString *extString = [picURL substringWithRange:[[extSubRE firstMatchInString:picURL options:0 range:NSMakeRange(0, picURL.length)] rangeAtIndex:0]];
        NSString *str = [extSubRE stringByReplacingMatchesInString:picURL
                                                           options:0
                                                             range:NSMakeRange(0, picURL.length)
                                                      withTemplate:[NSString stringWithFormat:@"_%@%@", sizeStr, extString]];
        return str;
    } else {
        // 不由可变的图片服务器提供
        return picURL;
    }
}

+ (NSString *)getJDPictureURLWithWidth:(NSInteger)width height:(NSInteger)height path:(NSString *)path {
    if (!path.length) return nil;
    
    NSURLComponents *components = [NSURLComponents componentsWithString:path];
    
    if (!components.scheme) {
        return nil;
    }
    
    if (!components.host) {
        return nil;
    }

    
    NSInteger imageWidth = width * [UIScreen mainScreen].scale;
    NSInteger imageHeight = height * [UIScreen mainScreen].scale;
    NSString *sizeString = [NSString stringWithFormat:@"%zdx%zd", imageWidth, imageHeight];
    
    NSRegularExpression *sizeRegularExpression = [NSRegularExpression regularExpressionWithPattern:@"\\d{1,4}x\\d{1,4}" options:0 error:nil];
    NSArray<NSTextCheckingResult *> *matches = [sizeRegularExpression matchesInString:components.path options:0 range:NSMakeRange(0, components.path.length)];
    if (matches.count > 0) {
        for (NSTextCheckingResult *match in matches.reverseObjectEnumerator) {
            components.path = [components.path stringByReplacingCharactersInRange:match.range withString:sizeString];
        }
    } else {
        NSRegularExpression *jdImageHostRegularExpression = [NSRegularExpression regularExpressionWithPattern:@"^\\w+.360buyimg\\.com" options:0 error:nil];
        if ([jdImageHostRegularExpression numberOfMatchesInString:components.host options:0 range:NSMakeRange(0, components.host.length)] > 0) {
            NSRegularExpression *pathRegularExpression = [NSRegularExpression regularExpressionWithPattern:@"^/\\w+/(\\w+)/" options:0 error:nil];
            NSTextCheckingResult *match = [pathRegularExpression firstMatchInString:components.path options:0 range:NSMakeRange(0, components.path.length)];
            if (match) {
                NSRange matchRange = [match rangeAtIndex:1];
                NSString *replaceString = [components.path substringWithRange:matchRange];
                replaceString = [NSString stringWithFormat:@"s%@_%@", sizeString, replaceString];
                components.path = [components.path stringByReplacingCharactersInRange:matchRange withString:replaceString];
            }
        }
    }
    
    
    return components.string;
}

+ (NSString *)getJDPictureURLWithWidth:(NSInteger)width height:(NSInteger)height path:(NSString *)path host:(NSString *)host {
    if (!path || !host) {
        return nil;
    }
    return [self getJDPictureURLWithWidth:width height:height path:[host stringByAppendingString:path]];
}

@end
