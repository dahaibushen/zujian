//
//  OTSConvertImageString.h
//  OneStoreFramework
//
//  Created by zhangbin on 14-9-28.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>


typedef NS_ENUM(NSInteger, OTSImageSizeLinkType) {
    OTSImageSizeLinkType_x = 1,        //尺寸为: ***x**** 等比缩放
    OTSImageSizeLinkType_y = 2         //尺寸为: ***y**** 填充
};

@interface OTSConvertImageString : NSObject

///**
// *    功能:图片的url转换成任意格式大小的图片url
// *
// *    @param picURL  :源图片url
// *    @param size :要转换成的格式大小
// *
// *    @return 转换后的图片url
// */
//+ (NSString *)convertPicURL:(NSString *)picURL
//                     toSize:(CGSize)size;
//
///**
// *    功能:图片的url,根据控件的宽、高来获取适配的url
// *
// *    @param picURL  :源图片url
// *    @param aWidth  :控件的宽
// *    @param aHeight :控件的高
// *
// *    @return 转换后的图片url
// */
//+ (NSString *)convertPicURL:(NSString *)picURL
//                  viewWidth:(NSInteger)aWidth
//                 viewHeight:(NSInteger)aHeight;
//
///**
// *    功能:图片的url,根据控件的宽、高获取撑满该尺寸的图片 URL(不要白边)
// *
// *    @param picURL  :源图片url
// *    @param aWidth  :控件的宽
// *    @param aHeight :控件的高
// *
// *    @return 转换后的图片url
// */
//+ (NSString *)convertPicURL:(NSString *)picURL
//                  viewWidth:(NSInteger)aWidth
//                 viewHeight:(NSInteger)aHeight
//      withImageSizeLinkType:(OTSImageSizeLinkType)imageSizeLinkType;
//
///**
//
// *    功能:图片的url转换成任意格式大小的图片url
// *
// *    @param picURL  :源图片url
// *    @param sizeStr :要转换成的格式大小
// *
// *    @return 转换后的图片url
// */
//+ (NSString *)convertPicURL:(NSString *)picURL
//               toSizeFormat:(NSString *)sizeStr;

/**
 * 获取指定宽高的图片地址,例：//img13.360buyimg.com/n1/s377x377_jfs/t6058/194/9754653273/274965/39a6aaac/5996a34cNca2b084d.jpg!cc_377x377
 *
 * @param width
 * @param height
 * @param path     jfs中图片的相对路径，形如：jfs/t4825/335/2417169723/58212/e5f00cc3/58ff11f7Ncc9fe1ef.jpg
 * @return
 */
+ (NSString *)getJDPictureURLWithWidth:(NSInteger)width height:(NSInteger)height path:(NSString *)path;

/**
 获取指定宽高的图片
 URL 组成一般是 scheme://host/业务/s30x30_path
 
 @param width 宽度
 @param height 高度
 @param path 业务后面的path jfs/t4825/335/2417169723/58212/e5f00cc3/58ff11f7Ncc9fe1ef.jpg
 @param host host，如  https://m.360buyimg.com/mobilecms/s30x30_  或者 https://m.360buyimg.com/mobilecms/
 @return
 */
+ (NSString *)getJDPictureURLWithWidth:(NSInteger)width height:(NSInteger)height path:(NSString *)path host:(NSString *)host;

@end
