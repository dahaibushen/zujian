//
//  UIViewController+custom.m
//  OneStoreFramework
//
//  Created by Aimy on 14-7-30.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "UIViewController+BarButtonItem.h"

static const CGFloat OTSUpdownLayoutNaviBtnImgWidth = 24.0;
static const CGFloat OTSUpdownLayoutNaviBtnTitleHeight = 14.0;

@implementation OTSDataNaviBtn

@end

@implementation OTSUpdownLayoutNaviBtn
- (CGRect)imageRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(contentRect.size.width/2-OTSUpdownLayoutNaviBtnImgWidth/2, contentRect.size.height/2-(OTSUpdownLayoutNaviBtnImgWidth+OTSUpdownLayoutNaviBtnTitleHeight)/2, OTSUpdownLayoutNaviBtnImgWidth, OTSUpdownLayoutNaviBtnImgWidth);
}

- (CGRect)titleRectForContentRect:(CGRect)contentRect
{
    return CGRectMake(0, contentRect.size.height/2-(OTSUpdownLayoutNaviBtnImgWidth+OTSUpdownLayoutNaviBtnTitleHeight)/2+OTSUpdownLayoutNaviBtnImgWidth, contentRect.size.width, OTSUpdownLayoutNaviBtnTitleHeight);
}

@end

@implementation UIViewController (BarButtonItem)



#pragma mark - navi button
- (void)setNaviButtonType:(OTSBarButtonItem)aType
                  isBgImg:(BOOL)aIsBgImg
                    frame:(CGRect)aFrame
                     text:(NSString *)aText
                    color:(UIColor *)aColor
                     font:(UIFont *)aFont
             shadowOffset:(CGSize)aShadowOffset
                alignment:(UIControlContentHorizontalAlignment)aAlignment
               edgeInsets:(UIEdgeInsets)aEdgeInsets
                   isLeft:(BOOL)aLeft {
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    if (CGRectEqualToRect(CGRectZero, aFrame)) {
        btn.frame = CGRectMake(0, 0, 24, 24);
    }
    else {
        btn.frame = aFrame;
    }
    
    SEL selector = nil;
    if (aLeft) {
        selector = @selector(leftBtnClicked:);
    }
    else {
        selector = @selector(rightBtnClicked:);
    }
    
    [btn addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    
    //根据样式不同更改按钮图片
    UIImage *normalImage = nil;
    UIImage *highlightImage = nil;
    switch (aType) {
        case OTSBarButtonItemNone: {//空的，无图片
            normalImage = nil;
            highlightImage = nil;
            break;
        }
        case OTSBarButtonItemReturnHome: {//返回首页
            normalImage = [UIImage imageNamed:@"navigation_back_home"];
            highlightImage = [UIImage imageNamed:@"navigation_back_home_sel"];
            break;
        }
        case OTSBarButtonItemSetting: {//设置
            normalImage = [UIImage imageNamed:@"navigationbar_btn_setting"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_setting_sel"];
            break;
        }
        case OTSBarButtonItemSearch: {//搜索
            normalImage = [UIImage imageNamed:@"navigationbar_btn_search"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_search_sel"];
            break;
        }
        case OTSBarButtonItemFavorite: {//收藏
            normalImage = [UIImage imageNamed:@"navigationbar_btn_favorate"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_favorate_sel"];
            break;
        }
        case OTSBarButtonItemShare: {//灰色分享
            normalImage = [UIImage imageNamed:@"share"];
            highlightImage = [UIImage imageNamed:@"share"];
            break;
        }
        case OTSBarButtonItemRockNow: { // 摇一摇
            normalImage = [UIImage imageNamed:@"navigationbar_btn_rockBuy"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_rockBuy_sel"];
            break;
        }
        case OTSBarButtonItemScan: { // 扫描
            normalImage = [UIImage imageNamed:@"navigationbar_btn_scan"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_scan_sel"];
            break;
        }
        case OTSBarButtonItemMessageCenter: { // 消息中心
            normalImage = [UIImage imageNamed:@"navigationbar_btn_message"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_message_sel"];
            break;
        }
        case OTSBarButtonItemWhiteBack: { // 白色边框
            normalImage = [UIImage imageNamed:@"navigationbar_btn_whiteback"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_whiteback_sel"];
            break;
        }
        case OTSBarButtonItemCategory: { // 白色边框
            normalImage = [UIImage imageNamed:@"navigationbar_btn_category"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_category_sel"];
            break;
        }
            
        case NaviButon_Brand_Category: { // 白色边框
            normalImage = [UIImage imageNamed:@"tuan_icon_classify_22"];
            highlightImage = [UIImage imageNamed:@"tuan_icon_classify_22"];
            break;
        }
            
        case OTSBarButtonItemLogo: { // 白色边框
            normalImage = [UIImage imageNamed:@"navigationbar_btn_logo"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_logo"];
            btn.frame = CGRectMake(0, 0, 36, 34);
            break;
        }
        case OTSBarButtonItemGray: {
            normalImage = [UIImage imageNamed:@"grzx_btn_normal"];
            highlightImage = [UIImage imageNamed:@"grzx_btn_pressed"];
            break;
        }
        case OTSBarButtonItemSpecialCity_return:{
            normalImage = [UIImage imageNamed:@"Shared_Native_Return_Gray"];
            highlightImage = [UIImage imageNamed:@"Shared_Native_Return_Gray"];
            break;
        }
        default:
            normalImage = nil;
            highlightImage = nil;
            break;
    }
    
    if (aIsBgImg) {
        [btn setBackgroundImage:normalImage forState:UIControlStateNormal];
        [btn setBackgroundImage:highlightImage forState:UIControlStateHighlighted];
    } else {
        [btn setImage:normalImage forState:UIControlStateNormal];
        [btn setImage:highlightImage forState:UIControlStateHighlighted];
    }
    
    //按钮文字
    if (aText != nil) {
        [btn setTitle:aText forState:UIControlStateNormal];
    }
    
    if (aColor) {
        [btn setTitleColor:aColor forState:UIControlStateNormal];
    }
    
    if (aFont) {
        btn.titleLabel.font = aFont;
    }
    
    if (!CGSizeEqualToSize(CGSizeZero, aShadowOffset)) {
        btn.titleLabel.shadowOffset = aShadowOffset;
    }
    
    btn.contentHorizontalAlignment = aAlignment;
    
    if (!UIEdgeInsetsEqualToEdgeInsets(aEdgeInsets, UIEdgeInsetsZero)) {
        btn.contentEdgeInsets = aEdgeInsets;
    }
    
    
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    
    if (aLeft) {
        self.navigationItem.leftBarButtonItem = btnItem;
    }
    else {
        self.navigationItem.rightBarButtonItem = btnItem;
    }
}

- (void)setNaviButtonType:(OTSBarButtonItem)aType
                    frame:(CGRect)aFrame
                     text:(NSString *)aText
                    color:(UIColor *)aColor
                     font:(UIFont *)aFont
             shadowOffset:(CGSize)aShadowOffset
                alignment:(UIControlContentHorizontalAlignment)aAlignment
               edgeInsets:(UIEdgeInsets)aEdgeInsets
                   isLeft:(BOOL)aLeft {
    [self setNaviButtonType:aType isBgImg:NO frame:aFrame text:aText color:aColor font:aFont shadowOffset:aShadowOffset alignment:aAlignment edgeInsets:aEdgeInsets isLeft:aLeft];
}

- (void)setNaviButtonType:(OTSBarButtonItem)aType position:(OTSBarButtonItemPosition)position {
    [self setNaviButtonType:aType frame:CGRectZero text:nil color:nil font:nil shadowOffset:CGSizeZero alignment:UIControlContentHorizontalAlignmentLeft edgeInsets:UIEdgeInsetsZero isLeft:(position == OTSBarButtonItemPositionLeft)];
}

- (void)setNaviButtonText:(NSString *)aText position:(OTSBarButtonItemPosition)position {
    BOOL isLeft = position == OTSBarButtonItemPositionLeft;
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:aText style:UIBarButtonItemStylePlain target:self action:isLeft ? @selector(leftBtnClicked:) : @selector(rightBtnClicked:)];
    if (isLeft) {
        self.navigationItem.leftBarButtonItem = item;
    } else {
        self.navigationItem.rightBarButtonItem = item;
    }
}

- (void)setUpdownLayoutNaviButtonType:(OTSBarButtonItem)aType text:(NSString *)aText href:(NSString *)aHref items:(NSArray *)aItems position:(OTSBarButtonItemPosition)position {
    BOOL isLeft = position == OTSBarButtonItemPositionLeft;
    OTSDataNaviBtn *btn = nil;
    if (aType!=OTSBarButtonItemNone && aText.length>0) {
        btn = [OTSUpdownLayoutNaviBtn buttonWithType:UIButtonTypeCustom];
    } else {
        btn = [OTSDataNaviBtn buttonWithType:UIButtonTypeCustom];
    }
    btn.frame = CGRectMake(0, 0, 44, 44);
    btn.href = aHref;
    btn.items = aItems;
    
    SEL selector = nil;
    if (isLeft) {
        selector = @selector(leftBtnClicked:);
    }
    else {
        selector = @selector(rightBtnClicked:);
    }
    
    [btn addTarget:self action:selector forControlEvents:UIControlEventTouchUpInside];
    
    //根据样式不同更改按钮图片
    UIImage *normalImage = nil;
    UIImage *highlightImage = nil;
    switch (aType) {
        case OTSBarButtonItemNone: {//空的，无图片
            normalImage = nil;
            highlightImage = nil;
            break;
        }
        case OTSBarButtonItemSetting: {//设置
            normalImage = [UIImage imageNamed:@"navigationbar_btn_setting"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_setting_sel"];
            break;
        }
        case OTSBarButtonItemSearch: {//搜索
            normalImage = [UIImage imageNamed:@"navigationbar_btn_search"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_search_sel"];
            break;
        }
        case OTSBarButtonItemFavorite: {//收藏
            normalImage = [UIImage imageNamed:@"navigationbar_btn_favorate"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_favorate_sel"];
            break;
        }
        case OTSBarButtonItemShare: {//灰色分享
            normalImage = [UIImage imageNamed:@"navigationbar_btn_share_gray"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_share_gray_sel"];
            break;
        }
        case OTSBarButtonItemRockNow: { // 摇一摇
            normalImage = [UIImage imageNamed:@"navigationbar_btn_rockBuy"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_rockBuy_sel"];
            break;
        }
        case OTSBarButtonItemScan: { // 扫描
            normalImage = [UIImage imageNamed:@"navigationbar_btn_scan"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_scan_sel"];
            break;
        }
        case OTSBarButtonItemMessageCenter: { // 消息中心
            normalImage = [UIImage imageNamed:@"navigationbar_btn_message"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_message_sel"];
            break;
        }
        case OTSBarButtonItemWhiteBack: { // 白色边框
            normalImage = [UIImage imageNamed:@"navigationbar_btn_whiteback"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_whiteback_sel"];
            break;
        }
        case OTSBarButtonItemCategory: { // 白色边框
            normalImage = [UIImage imageNamed:@"navigationbar_btn_category"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_category_sel"];
            break;
        }
        case OTSBarButtonItemLogo: { // 白色边框
            normalImage = [UIImage imageNamed:@"navigationbar_btn_logo"];
            highlightImage = [UIImage imageNamed:@"navigationbar_btn_logo"];
            btn.frame = CGRectMake(0, 0, 36, 34);
            break;
        }
        case OTSBarButtonItemGray: {
            normalImage = [UIImage imageNamed:@"grzx_btn_normal"];
            highlightImage = [UIImage imageNamed:@"grzx_btn_pressed"];
            btn.frame = CGRectMake(0, 0, 44, 31);
            break;
        }
        default:
            normalImage = nil;
            highlightImage = nil;
            break;
    }
    
    [btn setImage:normalImage forState:UIControlStateNormal];
    [btn setImage:highlightImage forState:UIControlStateHighlighted];
    
    //按钮文字
    if (aText != nil) {
        [btn setTitle:aText forState:UIControlStateNormal];
    }
    
    //文字颜色
    [btn setTitleColor:[UIColor colorWithRed:102.0/255 green:102.0/255 blue:102.0/255 alpha:1] forState:UIControlStateNormal];
    
    //文字字体
    if (aType!=OTSBarButtonItemNone && aText.length>0) {
        btn.titleLabel.font = [UIFont systemFontOfSize:12.0];
    } else {
        btn.titleLabel.font = [UIFont systemFontOfSize:14.0];
    }
    
    //文字居中
    btn.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
    btn.titleLabel.textAlignment = NSTextAlignmentCenter;
    
    UIBarButtonItem *btnItem = [[UIBarButtonItem alloc] initWithCustomView:btn];
    if (isLeft) {
        self.navigationItem.leftBarButtonItem = btnItem;
    } else {
        self.navigationItem.rightBarButtonItem = btnItem;
    }
}

- (void)setNaviBackButtonWithImageName:(NSString*)imageName {
    NSMutableArray *items = [NSMutableArray array];
    
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:imageName] style:UIBarButtonItemStylePlain target:self action:@selector(leftBtnClicked:)];
    backItem.tag = 0;
    backItem.imageInsets = UIEdgeInsetsMake(0, 8, 0, -8);
    
#if __IPHONE_OS_VERSION_MAX_ALLOWED >= 110000
    if (@available(iOS 11.0, *)) {
        backItem.imageInsets = UIEdgeInsetsMake(0, -8, 0, 8);
    } else {
        UIBarButtonItem *negativeSeperator = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
        negativeSeperator.width = -16;
        [items addObject:negativeSeperator];
    }
#else
    UIBarButtonItem *negativeSeperator = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFixedSpace target:nil action:nil];
    negativeSeperator.width = -16;
    [items addObject:negativeSeperator];
#endif
    [items addObject:backItem];
    self.navigationItem.leftBarButtonItems = items;
}

- (void)setNaviBackButtonWithImageNameArray:(NSArray<NSString*>*)imageNameArray {
    NSParameterAssert(imageNameArray.count);
    
    NSMutableArray *leftItems = [NSMutableArray array];
    if (self.navigationItem.leftBarButtonItems) {
        [leftItems addObjectsFromArray:self.navigationItem.leftBarButtonItems];
    }
    
    for (int i = 0; i < imageNameArray.count; i++) {
        UIButton *customBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        customBtn.frame = CGRectMake(0, 0, 30, 30);
        
        UIImage *image = [UIImage imageNamed:imageNameArray[i]];
        
        [customBtn setImage:[image imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
        [customBtn addTarget:self action:@selector(leftBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        [customBtn setImageEdgeInsets:UIEdgeInsetsMake(0, -10, 0, 10)];
        UIBarButtonItem *customItem = [[UIBarButtonItem alloc] initWithCustomView:customBtn];
        customItem.tag = i;
    
        [leftItems addObject:customItem];
    }
    
    self.navigationItem.leftBarButtonItems = leftItems;
}

- (void)leftBtnClicked:(id)sender {
    UINavigationController *nc = self.navigationController;
    if ([self.tabBarController.parentViewController isKindOfClass:[UINavigationController class]]) {
        nc = (UINavigationController*)self.tabBarController.parentViewController;
    }
    [nc popViewControllerAnimated:YES];
}

- (void)rightBtnClicked:(id)sender {
    
}

@end
