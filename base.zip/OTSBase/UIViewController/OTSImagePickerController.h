//
//  OTSImagePickerController.h
//  OneStoreBase
//
//  Created by 刘巧毅 on 15/9/1.
//  Copyright (c) 2015年 OneStoreBase. All rights reserved.
//
#import <UIKit/UIKit.h>
@class UIImagePickerController;
@interface OTSImagePickerController : UIImagePickerController

@end
