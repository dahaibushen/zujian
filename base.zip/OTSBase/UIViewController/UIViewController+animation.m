//
//  UIViewController+animation.m
//  OneStoreFramework
//
//  Created by Aimy on 14-7-30.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "UIViewController+animation.h"

@implementation UIViewController (OTSAnimation)

- (id<UIViewControllerAnimatedTransitioning>)pushAnimations
{
    return nil;
}

- (id<UIViewControllerAnimatedTransitioning>)popAnimations
{
    return nil;
}

- (id<UIViewControllerAnimatedTransitioning>)pushInteractions
{
    return nil;
}

- (id<UIViewControllerAnimatedTransitioning>)popInteractions
{
    return nil;
}

@end
