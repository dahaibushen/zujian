//
//  UIViewController+custom.h
//  OneStoreFramework
//
//  Created by Aimy on 14-7-30.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, OTSBarButtonItem) {
    OTSBarButtonItemNone = 0,        //空的，无图片
    OTSBarButtonItemSearch,          //搜索
    OTSBarButtonItemReturnHome,      //返回首页
    OTSBarButtonItemSetting,         //设置
    OTSBarButtonItemFavorite,        //收藏
    OTSBarButtonItemShare,           //灰色分享
    OTSBarButtonItemRockNow,         //摇一摇
    OTSBarButtonItemScan,            //扫描
    OTSBarButtonItemMessageCenter,   //消息中心
    OTSBarButtonItemWhiteBack,       //白色背景框
    OTSBarButtonItemCategory,        //分类
    OTSBarButtonItemLogo,            //logo
    NaviButon_Brand_Category,        //品牌团分类选择
    OTSBarButtonItemGray,            //灰色按钮
    OTSBarButtonItemSpecialCity_return,//城市精选商详返回按钮
};

typedef NS_ENUM(NSUInteger, OTSBarButtonItemPosition) {
    OTSBarButtonItemPositionRight,
    OTSBarButtonItemPositionLeft
};

@interface UIViewController (BarButtonItem)

//设置按钮类型（图片）
- (void)setNaviButtonType:(OTSBarButtonItem)aType position:(OTSBarButtonItemPosition)position;

//设置按钮文字
- (void)setNaviButtonText:(NSString *)aText position:(OTSBarButtonItemPosition)position;

//上下布局的按钮，上面图片，下面文字
- (void)setUpdownLayoutNaviButtonType:(OTSBarButtonItem)aType
                                 text:(NSString *)aText
                                 href:(NSString *)aHref
                                items:(NSArray *)aItems
                             position:(OTSBarButtonItemPosition)position;

//自定义返回按钮，点击调用 leftBtnClicked:
- (void)setNaviBackButtonWithImageName:(NSString*)imageName;

//自定义多个左侧按钮（e.g. back & home）, 点击调用 leftBtnClicked:
- (void)setNaviBackButtonWithImageNameArray:(NSArray<NSString*>*)imageNameArray;

//左按钮点击行为，可在子类重写此方法
- (void)leftBtnClicked:(id)sender;

//右按钮点击行为，可在子类重写此方法
- (void)rightBtnClicked:(id)sender;

@end

@interface OTSDataNaviBtn : UIButton

@property(nonatomic, copy) NSString *href;
@property(nonatomic, strong) NSArray *items;

@end

@interface OTSUpdownLayoutNaviBtn : OTSDataNaviBtn

@end
