//
//  OTSPriceLabel.h
//  OneStoreFramework
//
//  Created by Aimy on 9/12/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import <OTSCore/UIFont+OTS.h>

/**
 *  显示整数，小数字体大小不一样的label
 */
@interface OTSPriceLabel : UILabel

/**
 *  功能:刷新显示
 */
- (void)updateWithPrice:(double)aPrice color:(UIColor *)aColor integerFont:(UIFont *)aIntrgerFont decimalFont:(UIFont *)aDecimalFont;

/**
 *  功能:刷新显示
 */
- (void)updateWithPriceText:(NSString *)aPriceText color:(UIColor *)aColor integerFont:(UIFont *)aIntrgerFont decimalFont:(UIFont *)aDecimalFont;

/**
 *  功能:带币种符号的刷新 保留一位小数
 */
- (void)updateWithPrice:(double)aPrice color:(UIColor *)aColor integerFont:(UIFont *)aIntrgerFont oneDecimalFont:(UIFont *)aDecimalFont signFont:(UIFont *)signFont;

/**
 *  功能:数字后边带个数量
 */
- (void)updateWithPrice:(NSString *)aPrice color:(UIColor *)aColor integerFont:(UIFont *)aIntrgerFont decimalFont:(UIFont *)aDecimalFont signFont:(UIFont *)signFont productNub:(NSString *)aproductNub;

@end
