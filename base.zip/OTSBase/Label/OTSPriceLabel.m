//
//  OTSPriceLabel.m
//  OneStoreFramework
//
//  Created by Aimy on 9/12/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//
//
#import "OTSPriceLabel.h"
#import "NSNumber+Format.h"

@implementation OTSPriceLabel

- (id)init {
    self = [super init];
    if (self) {
        self.adjustsFontSizeToFitWidth = YES;
    }

    return self;
}

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.adjustsFontSizeToFitWidth = YES;
    }

    return self;
}

- (void)updateWithPrice:(double)aPrice color:(UIColor *)aColor integerFont:(UIFont *)aIntrgerFont decimalFont:(UIFont *)aDecimalFont {
    [self updateWithPriceText:[NSNumber moneyFormat:aPrice] color:aColor integerFont:aIntrgerFont decimalFont:aDecimalFont];
}

- (void)updateWithPriceText:(NSString *)aPriceText color:(UIColor *)aColor integerFont:(UIFont *)aIntrgerFont decimalFont:(UIFont *)aDecimalFont {
    if (aPriceText.length <= 0) {
        return;
    }
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:aPriceText];
    [string addAttribute:NSForegroundColorAttributeName value:aColor range:NSMakeRange(0, string.length)];

    NSRange range = [aPriceText rangeOfString:@"."];
    if (range.location != NSNotFound) {
        [string addAttribute:NSFontAttributeName value:aIntrgerFont range:NSMakeRange(0, range.location)];
        [string addAttribute:NSFontAttributeName value:aDecimalFont range:NSMakeRange(range.location, string.length - range.location)];
    } else {
        [string addAttribute:NSFontAttributeName value:aIntrgerFont range:NSMakeRange(0, aPriceText.length)];
    }

    self.attributedText = string;
}

/**
 *  功能:带币种符号的刷新
 */
- (void)updateWithPrice:(double)aPrice color:(UIColor *)aColor integerFont:(UIFont *)aIntrgerFont oneDecimalFont:(UIFont *)aDecimalFont signFont:(UIFont *)signFont {
    NSString *aPriceText = nil;
    aPriceText = [NSNumber moneyFormat:aPrice];

    if (aPriceText.length <= 0) {
        return;
    }
    NSMutableAttributedString *string = [[NSMutableAttributedString alloc] initWithString:aPriceText];
    [string addAttribute:NSForegroundColorAttributeName value:aColor range:NSMakeRange(0, string.length)];

    NSRange range = [aPriceText rangeOfString:@"."];
    [string addAttribute:NSFontAttributeName value:signFont range:NSMakeRange(0, 1)];
    if (range.location != NSNotFound) {
        [string addAttribute:NSFontAttributeName value:aIntrgerFont range:NSMakeRange(1, range.location)];
        [string addAttribute:NSFontAttributeName value:aDecimalFont range:NSMakeRange(range.location, string.length - range.location)];
    }

    self.attributedText = string;
}

/**
 *  功能:带产品数量的刷新
 */

- (void)updateWithPrice:(NSString *)aPrice color:(UIColor *)aColor integerFont:(UIFont *)aIntrgerFont decimalFont:(UIFont *)aDecimalFont signFont:(UIFont *)signFont productNub:(NSString *)aproductNub {
    NSString *priceStr = [NSNumber moneyFormat:[aPrice doubleValue]];
    NSString *aPriceText = [NSString stringWithFormat:@"%@  X%@", priceStr, aproductNub];
    if (aPriceText.length <= 0) {
        return;
    }
    NSMutableAttributedString *string1 = [[NSMutableAttributedString alloc] initWithString:aPriceText];
    [string1 addAttribute:NSForegroundColorAttributeName value:aColor range:NSMakeRange(0, priceStr.length)];

    NSRange range = [aPriceText rangeOfString:@"."];
    if (range.location != NSNotFound) {
        [string1 addAttribute:NSFontAttributeName value:signFont range:NSMakeRange(0, 1)];
        [string1 addAttribute:NSFontAttributeName value:aIntrgerFont range:NSMakeRange(1, range.location)];
        [string1 addAttribute:NSFontAttributeName value:aDecimalFont range:NSMakeRange(range.location, string1.length - range.location - aproductNub.length)];
        [string1 addAttribute:NSFontAttributeName value:aDecimalFont range:NSMakeRange(priceStr.length, aproductNub.length + 3)];
        [string1 addAttribute:NSForegroundColorAttributeName value:[UIColor grayColor] range:NSMakeRange(priceStr.length, aproductNub.length + 3)];
    }
    self.attributedText = string1;
}


@end