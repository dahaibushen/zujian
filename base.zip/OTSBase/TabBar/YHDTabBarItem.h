//
//  YHDTabBarItem.h
//  OneStoreMain
//
//  Created by Aimy on 8/25/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "AppTabItemVO.h"
#import "OTSTabBarItem.h"

@protocol TabBarItemTapDelegate <NSObject>

@optional
/**
 *  OTSVC如果需要响应tabbarItem被多次点击的提示，请实现实现这个方法
 */
- (void)repeateClickTabBarItem:(NSNumber *)count;

@end

@interface YHDTabBarItemVO : OTSValueObject

@property(nonatomic, strong) UIImage *image;
@property(nonatomic, strong) UIImage *selectedImage;
@property(nonatomic, strong) NSString *title;
@property(nonatomic, strong) NSString *hostString;
@property(nonatomic, strong) NSString *sourceURLString; // 用于替代hostString,暂不废除hostString
@property(nonatomic, assign) BOOL showWord;
@property(nonatomic, strong) NSString *selectHexColor;
@property(nonatomic, strong) NSNumber *isBulge;

@end

@interface YHDTabBarItem : OTSTabBarItem

//如果pad需要，可以移动到OTS中
@property(nonatomic, strong) YHDTabBarItemVO *defaultVO;
@property(nonatomic, strong) NSString *hostString;
@property(nonatomic, strong) AppTabItemVO *vo;

- (void)updateImageWithItemVO:(AppTabItemVO *)aVO;

@end
