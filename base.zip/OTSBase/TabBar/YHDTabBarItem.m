//
//  YHDTabBarItem.m
//  OneStoreMain
//
//  Created by Aimy on 8/25/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "YHDTabBarItem.h"
#import "SDWebImageManager.h"
#import "NSObject+BeeNotification.h"
#import <OTSCore/OTSCore.h>

@implementation YHDTabBarItemVO

@end

@interface OTSTabBarItem ()

@end

@implementation YHDTabBarItem

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.titleLabel.textColor = hex(0x757575);
        self.imageInsets = UIEdgeInsetsMake(0, 0, 6, 0);
    }
    return self;
}

- (void)setSelected:(BOOL)selected {
    [super setSelected:selected];
    if (selected) {
        if (self.defaultVO.selectHexColor) {
            self.titleLabel.textColor = shex(self.defaultVO.selectHexColor);
        } else
            self.titleLabel.textColor = hex(0xff3c25);
    } else {
        self.titleLabel.textColor = hex(0x757575);
    }
}

- (void)setDefaultVO:(YHDTabBarItemVO *)defaultVO {
    _defaultVO = defaultVO;
    self.title = _defaultVO.title;
    self.image = _defaultVO.image;
    self.selectedImage = _defaultVO.selectedImage;
    self.hostString = _defaultVO.hostString;
    self.showWord = defaultVO.showWord;
}

- (void)updateImageWithItemVO:(AppTabItemVO *)aVO {
    self.vo = aVO;

    if (!self.vo) {
        self.title = self.defaultVO.title;
        self.image = self.defaultVO.image;
        self.selectedImage = self.defaultVO.selectedImage;
        self.hostString = self.defaultVO.hostString;
        self.showWord = YES;
    }

    if (aVO.iconOff) {
        WEAK_SELF;
        if (![aVO.iconOff hasPrefix:@"http"]) {
            self.image = [UIImage imageNamed:aVO.iconOff];
            self.showWord = [self.vo.showWord boolValue];
        } else {
            [[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:aVO.iconOff] options:0 progress:nil completed:^(UIImage *_Nullable image, NSData *_Nullable data, NSError *_Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL *_Nullable imageURL) {
                STRONG_SELF;
                if (!error && finished) {
                    self.image = image;
                    self.bugle = aVO.isBulge.boolValue;
                    self.showWord = aVO.showWord.boolValue;
                } else {
                    self.showWord = YES;
                }
            }];
        }
    }

    if (aVO.iconOn) {
        WEAK_SELF;
        if (![aVO.iconOn hasPrefix:@"http"]) {
            self.selectedImage = [UIImage imageNamed:aVO.iconOn];
            self.showWord = [self.vo.showWord boolValue];
        } else {
            [[SDWebImageManager sharedManager] loadImageWithURL:[NSURL URLWithString:aVO.iconOn] options:0 progress:nil completed:^(UIImage *_Nullable image, NSData *_Nullable data, NSError *_Nullable error, SDImageCacheType cacheType, BOOL finished, NSURL *_Nullable imageURL) {
                STRONG_SELF;
                if (!error && finished) {
                    self.selectedImage = image;
                    self.bugle = aVO.isBulge.boolValue;
                    self.showWord = aVO.showWord.boolValue;
                } else {
                    if (aVO.isBulge.boolValue) {
                        self.selectedImage = nil;
                    }
                    self.showWord = YES;
                }

            }];
        }
    }
}

- (void)setShowIndicate:(BOOL)showIndicate {
    if (self.showIndicate && !showIndicate) {
        self.vo.viewed = @1;
        [self postNotification:@"updateTabVO" withObject:self];
    }

    [super setShowIndicate:showIndicate];
}

@end
