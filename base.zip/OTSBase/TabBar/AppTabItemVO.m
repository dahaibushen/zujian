//
//  AppTabItemVO.m
//  OTSVO
//
//  Created by liuwei7 on 2017/4/5.
//  Copyright © 2017年 OTSVO. All rights reserved.
//

#import "AppTabItemVO.h"

@implementation AppTabItemVO

@end
