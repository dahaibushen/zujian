//
//  OTSTabBarItem.m
//  OneStoreFramework
//
//  Created by Aimy on 14-7-14.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSTabBarItem.h"
#import <OTSCore/UIView+create.h>
#import <OTSCore/UIColor+Convenience.h>

@interface OTSTabBarItem ()

@property(nonatomic, strong) UILabel *titleLabel;
@property(nonatomic, strong) UILabel *badgeLabel;
@property(nonatomic, strong) UIView *indicateView;

@property(nonatomic, strong) UIImageView *backgroundImageView;
@property(nonatomic, strong) NSLayoutConstraint *hConstraint;
@property(nonatomic, strong) NSLayoutConstraint *vConstraint;
@property(nonatomic, strong) NSLayoutConstraint *backgroundWidthConstraint;
@property(nonatomic, strong) NSLayoutConstraint *backgroundHeightConstraint;

@end

@implementation OTSTabBarItem

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.clipsToBounds = YES;
        self.imageInsets = UIEdgeInsetsZero;
        [self _OTSTabBarItem_setupViews];

        self.userInteractionEnabled = YES;
        self.clipsToBounds = NO;
        UITapGestureRecognizer *ges = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(onPressTabbarItem)];
        [self addGestureRecognizer:ges];
    }
    return self;
}

- (void)_OTSTabBarItem_setupViews {
    self.backgroundImageView = [[UIImageView alloc] initWithFrame:CGRectZero];
    self.backgroundImageView.backgroundColor = [UIColor clearColor];
    self.backgroundImageView.contentMode = UIViewContentModeScaleToFill;
    [self addSubview:self.backgroundImageView];

    self.backgroundImageView.translatesAutoresizingMaskIntoConstraints = NO;
    self.hConstraint = [NSLayoutConstraint constraintWithItem:self.backgroundImageView attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.f constant:0.f];
    [self addConstraint:self.hConstraint];
    self.backgroundWidthConstraint = [NSLayoutConstraint constraintWithItem:self.backgroundImageView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.f constant:24.f];
    [self addConstraint:self.backgroundWidthConstraint];

    self.vConstraint = [NSLayoutConstraint constraintWithItem:self.backgroundImageView attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterY multiplier:1.f constant:0.f];
    [self addConstraint:self.vConstraint];
    self.backgroundHeightConstraint = [NSLayoutConstraint constraintWithItem:self.backgroundImageView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.f constant:24.f];
    [self addConstraint:self.backgroundHeightConstraint];

    self.titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.titleLabel.textAlignment = NSTextAlignmentCenter;
    self.titleLabel.backgroundColor = [UIColor clearColor];
    self.titleLabel.font = [UIFont systemFontOfSize:10.f];
    self.titleLabel.textColor = [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:.6];
    [self addSubview:self.titleLabel];

    self.titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.f constant:0.f]];

    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.titleLabel attribute:NSLayoutAttributeBottom relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeBottom multiplier:1.f constant:-4.f]];

    [self addSubview:self.badgeLabel];

    self.indicateView = [UIView autolayoutView];
    self.indicateView.backgroundColor = hex(0xff3c25);
    self.indicateView.clipsToBounds = YES;
    self.indicateView.layer.cornerRadius = 4.f;
    self.indicateView.hidden = YES;
    [self addSubview:self.indicateView];

    self.badgeLabel.translatesAutoresizingMaskIntoConstraints = NO;
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.badgeLabel attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.f constant:3.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.badgeLabel attribute:NSLayoutAttributeLeft relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.f constant:5.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.badgeLabel attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationGreaterThanOrEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.f constant:14.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.badgeLabel attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.f constant:14.f]];

    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.indicateView attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.f constant:8.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.indicateView attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:nil attribute:NSLayoutAttributeNotAnAttribute multiplier:1.f constant:8.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.indicateView attribute:NSLayoutAttributeRight relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeRight multiplier:1.f constant:-14.f]];
    [self addConstraint:[NSLayoutConstraint constraintWithItem:self.indicateView attribute:NSLayoutAttributeTop relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeTop multiplier:1.f constant:6]];
}

- (void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    [self _OTSTabBarItem_resizeViews];
}

- (void)setImageInsets:(UIEdgeInsets)imageInsets {
    _imageInsets = imageInsets;
    [self _OTSTabBarItem_resizeViews];
}

- (void)_OTSTabBarItem_resizeViews {
    self.hConstraint.constant = self.imageInsets.left - self.imageInsets.right;
    self.vConstraint.constant = self.imageInsets.top - self.imageInsets.bottom;

    CGSize size = [self backgroundViewSizeWhenBugle:self.isBugle showTitle:self.showWord];
    self.backgroundWidthConstraint.constant = size.width;
    self.backgroundHeightConstraint.constant = size.height;

    if (self.isBugle) {
        CGSize noBugleSize = [self backgroundViewSizeWhenBugle:NO showTitle:self.showWord];
        if (self.showWord) {
            self.vConstraint.constant -= ((size.height - noBugleSize.height) / 2.0 - 2);
        } else {
            self.vConstraint.constant -= ((size.height - noBugleSize.height) / 2.0);
        }
    }
}

- (void)setIndicateViewBgColor:(UIColor *)indicateViewBgColor {
    if ([indicateViewBgColor isKindOfClass:[UIColor class]]) {
        _indicateViewBgColor = indicateViewBgColor;
        self.badgeLabel.backgroundColor = _indicateViewBgColor;
    } else {
        _indicateViewBgColor = nil;
        self.badgeLabel.backgroundColor = hex(0xff3c25);
    }
}

- (UILabel *)badgeLabel {
    if (!_badgeLabel) {
        _badgeLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _badgeLabel.textAlignment = NSTextAlignmentCenter;
        _badgeLabel.textColor = [UIColor whiteColor];
        _badgeLabel.backgroundColor = hex(0xff3c25);
        _badgeLabel.font = [UIFont systemFontOfSize:12.f];
        _badgeLabel.layer.backgroundColor = [UIColor whiteColor].CGColor;
        _badgeLabel.adjustsFontSizeToFitWidth = YES;
        _badgeLabel.clipsToBounds = YES;
        _badgeLabel.layer.cornerRadius = 7.f;
        _badgeLabel.hidden = YES;
    }
    return _badgeLabel;
}

- (void)setTitle:(NSString *)title {
    _title = title;
    self.titleLabel.text = _title;
}

- (void)setBadgeValue:(NSString *)badgeValue {
    _badgeValue = badgeValue;
    self.badgeLabel.text = _badgeValue;
    self.badgeLabel.hidden = !_badgeValue;

    if (_showIndicate && self.badgeLabel.hidden) {
        self.indicateView.hidden = NO;
    } else {
        self.indicateView.hidden = YES;
    }
}

- (void)setShowIndicate:(BOOL)showIndicate {
    _showIndicate = showIndicate;

    if (_showIndicate && self.badgeLabel.hidden) {
        self.indicateView.hidden = NO;
    } else {
        self.indicateView.hidden = YES;
    }
}

- (void)setImage:(UIImage *)image {
    _image = image;
    if (!self.isSelected) {
        self.backgroundImageView.image = _image;
    }
}

- (void)setSelectedImage:(UIImage *)selectedImage {
    _selectedImage = selectedImage;
    if (self.isSelected) {
        self.backgroundImageView.image = _selectedImage;
    }
}

- (void)setSelected:(BOOL)selected {
    _selected = selected;
    self.backgroundImageView.image = selected ? self.selectedImage : self.image;
}

- (void)setShowWord:(BOOL)showWord {
    _showWord = showWord;
    self.titleLabel.hidden = !showWord;
    self.imageInsets = UIEdgeInsetsMake(0, 0, showWord ? 6 : 0, 0);
    [self _OTSTabBarItem_resizeViews];
}

- (void)onPressTabbarItem {
    if ([self.delegate respondsToSelector:@selector(tabBarItemDidSelectItem:)]) {
        [self.delegate tabBarItemDidSelectItem:self];
    }
}

- (void)setBugle:(BOOL)bugle {
    _bugle = bugle;

    [self _OTSTabBarItem_resizeViews];
}

- (CGSize)backgroundViewSizeWhenBugle:(BOOL)isBugle showTitle:(BOOL)showTitle {
    if (isBugle) {
        if (showTitle) {
            return CGSizeMake(48, 48);
        } else {
            return CGSizeMake(58, 66);
        }
    } else {
        if (showTitle) {
            return CGSizeMake(24, 24);
        } else {
            return CGSizeMake(64, 48);
        }
    }
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
    BOOL inside = [super pointInside:point withEvent:event];
    if (!inside) {
        if (self.isBugle) {
            return CGRectContainsPoint(self.backgroundImageView.frame, point);
        }
    }

    return inside;
}

@end
