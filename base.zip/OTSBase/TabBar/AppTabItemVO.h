//
//  AppTabItemVO.h
//  OTSVO
//
//  Created by liuwei7 on 2017/4/5.
//  Copyright © 2017年 OTSVO. All rights reserved.
//

#import <OTSCore/OTSValueObject.h>

@interface AppTabItemVO : OTSValueObject

@property(nonatomic, strong) NSString *name;
@property(nonatomic, strong) NSNumber *redPoint;
@property(nonatomic, strong) NSString *iconOff;
@property(nonatomic, strong) NSString *iconOn;
@property(nonatomic, strong) NSString *url;
@property(nonatomic, strong) NSNumber *type;

@property(nonatomic, strong) NSNumber *viewed;
@property(nonatomic, strong) NSString *updateTime;
@property(nonatomic, strong) NSNumber *showWord; //是否显示tabbar的title

@property(nonatomic, strong) NSNumber *isBulge;  //1表示突起 0表示不突起

@end
