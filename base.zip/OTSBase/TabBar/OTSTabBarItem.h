//
//  OTSTabBarItem.h
//  OneStoreFramework
//
//  Created by Aimy on 14-7-14.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>

@class OTSTabBarItem;

@protocol OTSTabBarItemDelegate <NSObject>

- (void)tabBarItemDidSelectItem:(OTSTabBarItem *)item;

@end

@interface OTSTabBarItem : UIView
/**
 *  标题
 */
@property(nonatomic, copy) NSString *title;
/**
 *  标题label
 */
@property(nonatomic, strong, readonly) UILabel *titleLabel;
/**
 *  默认图片
 */
@property(nonatomic, strong) UIImage *image;
/**
 *  选中时候的图片
 */
@property(nonatomic, strong) UIImage *selectedImage;
/**
 *  图片的偏移
 */
@property(nonatomic) UIEdgeInsets imageInsets;
/**
 *  提示字符
 */
@property(nonatomic, copy) NSString *badgeValue;
/**
 *  提示飘红的背景颜色
 */
@property(nonatomic, copy) UIColor *indicateViewBgColor;
/**
 *  显示红点指示
 */
@property(nonatomic) BOOL showIndicate;
/**
 *  是否选中
 */
@property(nonatomic, getter = isSelected) BOOL selected;
/**
 *  是否显示标题
 */
@property(nonatomic, getter = isShowWord) BOOL showWord;

@property(nonatomic, getter=isBugle) BOOL bugle;

/**
 *  代理
 */
@property(nonatomic, weak) id <OTSTabBarItemDelegate> delegate;

@end
