//
//  OTSLoadingImageView.m
//  OTSHomePage
//
//  Created by 韩佚 on 2017/2/7.
//  Copyright © 2017年 OTSHomePage. All rights reserved.
//

#import "OTSLoadingImageView.h"
#import "FLAnimatedImage.h"
#import <OTSCore/UIImage+Size.h>
#import <OTSCore/UIFont+OTS.h>
#import "ALView+PureLayout.h"
#import <OTSCore/OTSCore.h>


@interface PlaceholderView : UIView

@property(nonatomic, strong) FLAnimatedImageView *loadView;

@property(nonatomic, strong) UILabel *descLbl;

@property(nonatomic, strong) UIImageView *backImgView;

@property(nonatomic, strong) NSLayoutConstraint *constraintV;

- (void)updateBackImage:(NSString *)imageName desc:(NSString *)text;

@end

@interface OTSLoadingImageView ()

@property(nonatomic, strong) PlaceholderView *placeholderView;

@property(nonatomic, strong) UIImageView *placeholder;

@end

@implementation OTSLoadingImageView

- (void)awakeFromNib {
    [super awakeFromNib];

    [self initUI];
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {

        [self initUI];
    }

    return self;
}

- (void)updateLoadingInfoWithBackImage:(NSString *)imageName desc:(NSString *)text {
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        [self.placeholderView updateBackImage:imageName desc:text];
    }
}

- (void)updateLoadingInfoWithBackImage:(NSString *)imageName desc:(NSString *)text type:(LoadingImageViewType)type {
    [self updateLoadingInfoWithBackImage:imageName desc:text];

    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        self.placeholderView.descLbl.font = [UIFont systemFontOfSize:16];
        self.placeholderView.constraintV.constant = 15;
        [self.placeholderView layoutIfNeeded];
    }
}

- (void)initUI {
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        [self addSubview:self.placeholderView];
        [self.placeholderView autoPinEdgesToSuperviewEdges];
    } else {
        [self addSubview:self.placeholder];

        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.placeholder attribute:NSLayoutAttributeCenterX relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterX multiplier:1.f constant:0.f]];

        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.placeholder attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationLessThanOrEqual toItem:self attribute:NSLayoutAttributeWidth multiplier:1.f constant:0.f]];

        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.placeholder attribute:NSLayoutAttributeCenterY relatedBy:NSLayoutRelationEqual toItem:self attribute:NSLayoutAttributeCenterY multiplier:1.f constant:0.f]];

        [self addConstraint:[NSLayoutConstraint constraintWithItem:self.placeholder attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationLessThanOrEqual toItem:self attribute:NSLayoutAttributeHeight multiplier:1.f constant:0.f]];
    }
}

- (void)setImage:(UIImage *)image {
    [super setImage:image];
    if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
        self.placeholderView.hidden = (self.image ? YES : NO);
    } else {
        self.placeholder.hidden = (self.image ? YES : NO);
    }
}

- (PlaceholderView *)placeholderView {
    if (!_placeholderView) {
        _placeholderView = [[PlaceholderView alloc] initWithFrame:CGRectZero];
    }
    return _placeholderView;
}

- (UIImageView *)placeholder {
    if (!_placeholder) {
        _placeholder = [[UIImageView alloc] initWithFrame:CGRectZero];
        _placeholder.translatesAutoresizingMaskIntoConstraints = NO;
        _placeholder.backgroundColor = [UIColor clearColor];
        _placeholder.image = [UIImage imageNamed:@"loadingimg"];
    }
    return _placeholder;
}

@end

@implementation PlaceholderView

static UIImage *__OTSLoadingTileImage = nil;
static FLAnimatedImage *__OTSLoadingGifImage = nil;

- (void)awakeFromNib {
    [super awakeFromNib];

    [self initUI];
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initUI];
    }

    return self;
}

- (void)initUI {
    [self addSubview:self.backImgView];
    [self addSubview:self.loadView];
    [self addSubview:self.descLbl];

    [self.backImgView autoPinEdgesToSuperviewEdges];
    self.constraintV = [self.descLbl autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.descLbl autoPinEdgeToSuperviewEdge:ALEdgeLeading withInset:15];
    [self.descLbl autoPinEdgeToSuperviewEdge:ALEdgeTrailing withInset:15];

    [self.loadView autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.descLbl withOffset:8];
    [self.loadView autoAlignAxisToSuperviewAxis:ALAxisVertical];
    [self.loadView autoSetDimensionsToSize:CGSizeMake(38, 8)];

    if (!__OTSLoadingTileImage) {
        UIImage *backgroudImage = [UIImage imageNamed:@"homeLoadingBG_1hang3-1"];
        backgroudImage = [backgroudImage shrinkImageForSize:CGSizeMake(90, 90)];
        __OTSLoadingTileImage = [backgroudImage resizableImageWithCapInsets:UIEdgeInsetsZero resizingMode:UIImageResizingModeTile];
    }

    self.backImgView.image = __OTSLoadingTileImage;
}

- (void)updateBackImage:(NSString *)imageName desc:(NSString *)text {
    if (imageName.length > 0) {
        self.backImgView.image = [UIImage imageNamed:imageName];
    } else {
        self.backImgView.image = __OTSLoadingTileImage;
    }
    if (text.length > 0) {
        self.descLbl.text = text;
    } else {
        self.descLbl.text = @"加 载 中 ...";
    }
}

#pragma mark - Lazy load

- (UIImageView *)backImgView {
    if (!_backImgView) {
        _backImgView = [[UIImageView alloc] initWithFrame:CGRectZero];
        _backImgView.contentMode = UIViewContentModeScaleToFill;
    }
    return _backImgView;
}

- (FLAnimatedImageView *)loadView {
    if (!_loadView) {
        _loadView = [[FLAnimatedImageView alloc] initWithFrame:CGRectZero];
        if (!__OTSLoadingGifImage) {
            NSString *gifPath = [[NSBundle mainBundle] pathForResource:@"loading" ofType:@"gif"];
            __OTSLoadingGifImage = [[FLAnimatedImage alloc] initWithAnimatedGIFData:[NSData dataWithContentsOfFile:gifPath]];
        }
        _loadView.animatedImage = __OTSLoadingGifImage;
    }
    return _loadView;
}

- (UILabel *)descLbl {
    if (!_descLbl) {
        _descLbl = [[UILabel alloc] initWithFrame:CGRectZero];
        _descLbl.text = @"加 载 中 ...";
        _descLbl.textAlignment = NSTextAlignmentCenter;
        _descLbl.font = [UIFont systemFontOfSizeForiPhone:12 iPad:14];
        _descLbl.textColor = hex(0x212121);
    }
    return _descLbl;
}

@end
