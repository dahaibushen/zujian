//
//  OTSLoadingImageView.h
//  OTSHomePage
//
//  Created by 韩佚 on 2017/2/7.
//  Copyright © 2017年 OTSHomePage. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OTSBlockImageView.h"

typedef NS_ENUM(NSInteger, LoadingImageViewType) {
    LoadingImageViewTypeBanner
};

@interface OTSLoadingImageView : OTSBlockImageView

- (void)updateLoadingInfoWithBackImage:(NSString *)imageName desc:(NSString *)text;

- (void)updateLoadingInfoWithBackImage:(NSString *)imageName desc:(NSString *)text type:(LoadingImageViewType)type;

@end
