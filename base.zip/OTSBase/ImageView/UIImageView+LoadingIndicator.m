//
//  UIImageView+LoadingIndicator.m
//  OneStoreFramework
//
//  Created by Vect Xi on 11/3/14.
//  Copyright (c) 2014 OneStore. All rights reserved.
//

#import "UIImageView+LoadingIndicator.h"
#import "UIImageView+WebCache.h"
#import <OTSCore/OTSCore.h>
#import <SDWebImage/UIImageView+WebCache.h>


@implementation UIImageView (LoadingIndicator)

- (void)ots_setImageWithURL:(NSURL *)url
                showLoading:(BOOL)showLoading
             indicatorStype:(UIActivityIndicatorViewStyle)style
           placeholderImage:(UIImage *)image
                    options:(SDWebImageOptions)options {
    [self ots_setImageWithURL:url
                  showLoading:showLoading
               indicatorStype:style
             placeholderImage:image
                      options:options
                     progress:nil
                    completed:nil];
}

- (void)ots_setImageWithURL:(NSURL *)url
                showLoading:(BOOL)showLoading
             indicatorStype:(UIActivityIndicatorViewStyle)style
           placeholderImage:(UIImage *)placeholder
                    options:(SDWebImageOptions)options
                   progress:(SDWebImageDownloaderProgressBlock)progressBlock
                  completed:(SDExternalCompletionBlock)completedBlock {
    if (showLoading) {
        UIActivityIndicatorView *indicator = [self getAssociatedObjectForKey:@"ots_imageLoadingActivityIndicatorView"];
        if (!indicator) {
            indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:style];
            [self setAssociatedObject:indicator forKey:@"ots_imageLoadingActivityIndicatorView" policy:OTSAssociationPolicyRetainNonatomic];
        }
        [self addSubview:indicator];
        indicator.center = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
        [indicator startAnimating];
    }

    [self sd_setImageWithURL:url
            placeholderImage:placeholder
                     options:options
                   completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                       UIActivityIndicatorView *indicator = [self getAssociatedObjectForKey:@"ots_imageLoadingActivityIndicatorView"];
                       if (indicator) {
                           [indicator stopAnimating];
                           [indicator removeFromSuperview];
                           [self setAssociatedObject:nil forKey:@"ots_imageLoadingActivityIndicatorView" policy:OTSAssociationPolicyRetainNonatomic];
                       }

                       if (completedBlock) {
                           completedBlock(image, error, cacheType, imageURL);
                       }
                   }];
}

@end
