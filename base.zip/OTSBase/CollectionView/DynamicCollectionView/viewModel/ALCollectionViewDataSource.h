//
//  ALTableDataSource.h
//  ALJetLibrary
//
//  Created by Albert Tian on 13-10-11.
//
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class ALCollectionItemViewModel;

@class ALCollectionViewSection;
/**
 *	@brief	Header
 *          sections:   {section header
 *                      section rows
 *                      section footer}
 *          Footer
 */
@interface ALCollectionViewDataSource : NSObject

@property (strong, nonatomic) NSMutableArray<__kindof ALCollectionViewSection *> *sections;

- (NSUInteger)sectionCount;
- (NSUInteger)itemCountAtSection:(NSUInteger)sectionIndex;

- (nullable __kindof ALCollectionViewSection *)sectionAtIndex:(NSUInteger)sectionIndex;
- (nullable id)headerAtSection:(NSUInteger)sectionIndex;
- (nullable id)footerAtSection:(NSUInteger)sectionIndex;
- (nullable id)itemAtIndexPath:(NSIndexPath *)indexPath;

- (NSUInteger)indexOfSection:(ALCollectionViewSection *)section;
- (nullable NSIndexSet *)indexSetOfSectionMatch:(BOOL (^)(ALCollectionViewSection *section, NSUInteger index, BOOL *stop))match;

- (NSIndexPath *)indexPathOfItem:(id)rowObject;
- (NSIndexPath *)indexPathOfItem:(id)rowObject match:(BOOL (^)(id rowObject, id anyObject))match;

- (void)enumerateItemsUsingBlock:(void (^)(id obj, NSIndexPath *indexPath, BOOL *stop))block;

- (void)addSection:(nullable ALCollectionViewSection *)section;
- (void)insertSections:(NSArray *)array atIndexes:(NSIndexSet *)indexes;

- (__kindof ALCollectionViewSection *)addSectionWithItems:(nullable NSArray *)items;
- (__kindof ALCollectionViewSection *)addSectionWithItems:(nullable NSArray *)items
                                                   header:(nullable ALCollectionItemViewModel *)header
                                                   footer:(nullable ALCollectionItemViewModel *)footer;

- (void)clearDataSource;
- (void)removeAllSections;
- (void)removeSectionAtIndex:(NSUInteger)sectionIndex;
- (void)removeSection:(ALCollectionViewSection *)section;

- (void)removeItemAtIndexPath:(NSIndexPath *)indexPath;

@end

NS_ASSUME_NONNULL_END
