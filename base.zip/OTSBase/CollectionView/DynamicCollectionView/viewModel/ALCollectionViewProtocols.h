//
//  ALCollectionViewProtocols.h
//  ALJetLibrary
//
//  Created by Albert Tian on 15-4-13.
//
//

#ifndef ALJetLibrary_ALCollectionViewProtocols_h
#define ALJetLibrary_ALCollectionViewProtocols_h

#import <UIKit/UIKit.h>

@class ALCollectionItemViewModel;

extern NSString * const ALCollectionViewActionUnitViewKey;
extern NSString * const ALCollectionViewActionCollectionViewKey;

@protocol ALCollectionViewActionProtocol <NSObject>

@required
- (void)handleActionUnitViewModel:(ALCollectionItemViewModel *)unitViewModel userInfo:(NSDictionary *)userInfo atIndexPath:(NSIndexPath *)indexPath onCompletion:(void (^)(id))completion;

@end


@protocol ALCollectionUnitViewUserActionDelegate;
@protocol ALCollectionViewUnitViewInterface <NSObject>

- (id<ALCollectionUnitViewUserActionDelegate>)userActionDelegate;
- (void)setUserActionDelegate:(id<ALCollectionUnitViewUserActionDelegate>)userActionDelegate;

- (void)updateViewModel:(ALCollectionItemViewModel *)unitViewModel
            atIndexPath:(NSIndexPath *)indexPath;
@optional

- (CGSize)sizeForViewModel:(ALCollectionItemViewModel *)unitViewModel
          inCollectionView:(UICollectionView *)collectionView
               atIndexPath:(NSIndexPath *)indexPath;

+ (CGSize)sizeForViewModel:(ALCollectionItemViewModel *)unitViewModel
          inCollectionView:(UICollectionView *)collectionView
               atIndexPath:(NSIndexPath *)indexPath;

@end

@protocol ALCollectionUnitViewUserActionDelegate <NSObject>

@required
- (void)handleAction:(NSString *)actionKey unitView:(id)unitView viewModel:(ALCollectionItemViewModel *)unitViewModel userInfo:(NSDictionary *)userInfo atIndexPath:(NSIndexPath *)indexPath onCompletion:(void (^)(id))completion;

@end


#endif
