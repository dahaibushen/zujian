//
//  ALCollectionItemViewModel+UserInfoObserver.m
//  OTSHomePage
//
//  Created by tianwangkuan on 10/9/16.
//  Copyright © 2016 OTSHomePage. All rights reserved.
//

#import "ALCollectionItemViewModel+UserInfoObserver.h"
#import "ALCollectionItemViewModel_Protect.h"
#import <ReactiveObjC/ReactiveObjC.h>

@implementation ALCollectionItemViewModel (UserInfoObserver)

- (RACSignal *)observeUserInfoForKeyPath:(NSString *)keyPath observer:(NSObject *__weak)observer
{
    return [self.userInfoMapping rac_valuesForKeyPath:keyPath observer:observer];
}

@end
