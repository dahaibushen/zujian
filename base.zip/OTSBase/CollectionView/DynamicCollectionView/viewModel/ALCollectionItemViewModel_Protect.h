//
//  ALCollectionItemViewModel_Protect.h
//  OTSHomePage
//
//  Created by tianwangkuan on 10/9/16.
//  Copyright © 2016 OTSHomePage. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ALCollectionItemViewModel.h"

@interface ALCollectionItemViewModel ()

@property (strong, nonatomic) NSMutableDictionary *userInfoMapping;

@property (strong, nonatomic) NSMutableDictionary *actionInjections;

@end

