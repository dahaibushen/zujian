//
//  ALTableSection.m
//  ALJetLibrary
//
//  Created by tianwangkuan on 7/25/16.
//
//

#import "ALCollectionViewSection.h"
#import "ALCollectionItemViewModel.h"

@interface ALCollectionViewSection ()

@property (strong, nonatomic) NSMutableArray<ALCollectionItemViewModel *> *items;

@end

@implementation ALCollectionViewSection

- (instancetype)initWithItems:(NSArray *)items header:(ALCollectionItemViewModel *)header footer:(ALCollectionItemViewModel *)footer
{
    self = [super init];
    if (self) {
        if (items) {
            _items = [items mutableCopy];
        } else {
            _items = [[NSMutableArray alloc] initWithCapacity:0];
        }
        _header = header;
        _footer = footer;
    }
    return self;
}

- (id)initWithItems:(NSArray *)items
{
    return [self initWithItems:items header:nil footer:nil];
}

+ (instancetype)sectionWithItems:(NSArray *)items header:(ALCollectionItemViewModel *)header footer:(ALCollectionItemViewModel *)footer
{
    return [[self alloc] initWithItems:items header:header footer:footer];
}
+ (instancetype)sectionWithItems:(NSArray *)items
{
    return [self sectionWithItems:items header:nil footer:nil];
}

- (NSUInteger)itemsCount
{
    return [_items count];
}

- (id)itemAtIndex:(NSUInteger)index
{
    if (index >= _items.count) {
        return nil;
    }
    return [_items objectAtIndex:index];
}

- (NSUInteger)indexOfItem:(id)aRowObject match:(BOOL (^)(id aRowObject, id anyObject))match
{
    if (match) {
        __block NSUInteger foundIndex = NSNotFound;
        [self enumerateItemsUsingBlock:^(id obj, NSUInteger rowIdx, BOOL *stop) {
            if (match(aRowObject, obj)) {
                foundIndex = rowIdx;
                if (stop) {
                    *stop = YES;
                }
            }
        }];
        return foundIndex;
    } else {
        return [self indexOfItemIdenticalTo:aRowObject];
    }
}

- (NSUInteger)indexOfItemIdenticalTo:(id)aRowObject
{
    if (_items) {
        return [_items indexOfObjectIdenticalTo:aRowObject];
    }
    return NSNotFound;
}

- (void)enumerateItemsUsingBlock:(void (^)(id obj, NSUInteger rowIdx, BOOL *stop))block {
    [_items enumerateObjectsUsingBlock:block];
}

- (void)removeAllItems
{
    [_items removeAllObjects];
}

- (void)removeItemAtIndex:(NSUInteger)index
{
    if (index < _items.count) {
        [_items removeObjectAtIndex:index];
    }
}

- (void)addItems:(NSArray *)items
{
    [_items addObjectsFromArray:items];
}

@end
