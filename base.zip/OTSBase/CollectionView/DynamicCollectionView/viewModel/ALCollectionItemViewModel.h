//
//  ALCollectionItemViewModel.h
//  ALJetLibrary
//
//  Created by tianwangkuan on 7/27/16.
//
//

#import <CoreGraphics/CoreGraphics.h>
#import <UIKit/UIKit.h>
#import "ALCollectionViewAction.h"

NS_ASSUME_NONNULL_BEGIN

@interface ALCollectionItemViewModel : NSObject

@property (nonatomic, copy, readonly) NSString *reuseIdentifier;

@property (nonatomic, assign) CGSize preferredSize;

- (instancetype)initWithReuseId:(NSString *)reuseId;

+ (instancetype)viewModelWithReuseId:(NSString *)reuseId;

- (nullable id)userInfoForKey:(nullable id)key;
- (void)setUserInfo:(nullable id)value forKey:(nullable id)key;

@end

@interface ALCollectionItemViewModel (UserInfoSubscript)

- (void)setObject:(nullable id)obj forKeyedSubscript:(nonnull id<NSCopying>)key;
- (nullable id)objectForKeyedSubscript:(nonnull id)key;

@end

@interface ALCollectionItemViewModel (Action)

- (instancetype)injectSelectAction:(nullable id<ALCollectionViewActionProtocol>)action;
- (id<ALCollectionViewActionProtocol>)selectAction;

- (instancetype)injectDeselectAction:(nullable id<ALCollectionViewActionProtocol>)action;
- (id<ALCollectionViewActionProtocol>)deselectAction;

- (instancetype)injectUserAction:(nullable id<ALCollectionViewActionProtocol>)action forKey:(NSString *)actionKey;
- (id<ALCollectionViewActionProtocol>)userActionForKey:(NSString *)actionKey;

@end


NS_ASSUME_NONNULL_END
