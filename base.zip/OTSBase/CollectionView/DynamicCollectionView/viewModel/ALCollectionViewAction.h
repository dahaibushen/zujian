//
//  ALCollectionViewActionHandler.h
//  ALJetLibrary
//
//  Created by Albert Tian on 14-1-18.
//
//

#import <Foundation/Foundation.h>
#import "ALCollectionViewCell.h"

typedef void (^ALCollectionViewActionBlockHandler)(ALCollectionItemViewModel *unitViewModel, NSDictionary *userInfo, NSIndexPath *indexPath, void (^onCompletion)(id));

@interface ALCollectionViewAction : NSObject <ALCollectionViewActionProtocol>

+ (instancetype)action;

+ (id)actionWithHandler:(ALCollectionViewActionBlockHandler)handler;

@end


@interface ALCollectionViewBlockAction : ALCollectionViewAction

+ (instancetype)actionWithHandler:(ALCollectionViewActionBlockHandler)handler;

@end

