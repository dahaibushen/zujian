//
//  ALCollectionItemViewModel+UserInfoObserver.h
//  OTSHomePage
//
//  Created by tianwangkuan on 10/9/16.
//  Copyright © 2016 OTSHomePage. All rights reserved.
//

#import "ALCollectionItemViewModel.h"

@class RACSignal;

@interface ALCollectionItemViewModel (UserInfoObserver)

- (RACSignal *)observeUserInfoForKeyPath:(NSString *)keyPath observer:(__weak NSObject *)observer;

@end

