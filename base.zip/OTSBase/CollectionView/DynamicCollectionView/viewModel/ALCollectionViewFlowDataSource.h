//
//  ALCollectionViewDataSource.h
//  ALJetLibrary
//
//  Created by Albert Tian on 14-5-16.
//
//

#import <UIKit/UIKit.h>
#import "ALCollectionViewDataSource.h"
#import "ALCollectionViewSection.h"

@class ALCollectionViewFlowSection;

@interface ALCollectionViewFlowDataSource : ALCollectionViewDataSource

- (ALCollectionViewFlowSection *)addSectionWithItems:(NSArray *)rows;
- (ALCollectionViewFlowSection *)addSectionWithItems:(NSArray *)rows
                                                      header:(ALCollectionItemViewModel *)header
                                                      footer:(ALCollectionItemViewModel *)footer;

@end

@interface ALCollectionViewFlowSection : ALCollectionViewSection

/**
 *	@brief	 attributes which could be setted by UICollectionViewFlowLayout 's delegate.
 @property (nonatomic) CGFloat minimumLineSpacing;
 @property (nonatomic) CGFloat minimumInteritemSpacing;
 @property (nonatomic) CGSize headerReferenceSize;
 @property (nonatomic) CGSize footerReferenceSize;
 @property (nonatomic) UIEdgeInsets sectionInset;
 */
@property (nonatomic, strong) NSDictionary *layoutAttributes;

- (void)setMinimumLineSpacing:(CGFloat)minimumLineSpacing;
- (NSNumber *)minimumLineSpacing;

- (void)setMinimumInteritemSpacing:(CGFloat)minimumInteritemSpacing;
- (NSNumber *)minimumInteritemSpacing;

- (void)setHeaderReferenceSize:(CGSize)headerReferenceSize;
-(NSValue *)headerReferenceSize;

- (void)setFooterReferenceSize:(CGSize)footerReferenceSize;
- (NSValue *)footerReferenceSize;

- (void)setSectionInset:(UIEdgeInsets)sectionInset;
- (NSValue *)sectionInset;

@end




