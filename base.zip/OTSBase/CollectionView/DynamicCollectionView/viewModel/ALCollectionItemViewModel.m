//
//  ALCollectionItemViewModel.m
//  ALJetLibrary
//
//  Created by tianwangkuan on 7/27/16.
//
//

#import "ALCollectionItemViewModel.h"
#import "ALCollectionItemViewModel_Protect.h"

@interface ALCollectionItemViewModel ()

@property (nonatomic, strong) NSValue *viewSize;

- (instancetype)initWithReuseId:(NSString *)reuseId;

@end

@implementation ALCollectionItemViewModel

- (instancetype)initWithReuseId:(NSString *)reuseId
{
    self = [super init];
    if (self) {
        _actionInjections = [[NSMutableDictionary alloc] init];
        _reuseIdentifier = [reuseId copy];
    }
    return self;
}

+ (instancetype)viewModelWithReuseId:(NSString *)reuseId
{
    return [[self alloc] initWithReuseId:reuseId];
}

#pragma mark UserInfo

- (NSMutableDictionary *)userInfoMapping {
    if (!_userInfoMapping) {
        _userInfoMapping = [NSMutableDictionary dictionaryWithCapacity:0];
    }
    return _userInfoMapping;
}

- (id)userInfoForKey:(id)key {
    if (!key) {
        return nil;
    }
    return [self.userInfoMapping objectForKey:key];
}
- (void)setUserInfo:(id)value forKey:(id)key {
    if (!key) {
        return;
    }
    NSMutableDictionary *mdict = [self userInfoMapping];
    if (value) {
        [mdict setObject:value forKey:key];
    } else {
        [mdict removeObjectForKey:key];
    }
}



@end


@implementation ALCollectionItemViewModel (UserInfoSubscript)

- (void)setObject:(id)obj forKeyedSubscript:(id<NSCopying>)key
{
    [self setUserInfo:obj forKey:key];
}
- (id)objectForKeyedSubscript:(id)key
{
    return [self userInfoForKey:key];
}

@end

@implementation ALCollectionItemViewModel (Action)

- (instancetype)injectSelectAction:(id<ALCollectionViewActionProtocol>)action
{
    self.actionInjections[@"select"] = action;
    return self;
}
- (id<ALCollectionViewActionProtocol>)selectAction
{
    return self.actionInjections[@"select"];
}

- (instancetype)injectDeselectAction:(id<ALCollectionViewActionProtocol>)action
{
    self.actionInjections[@"deselect"] = action;
    return self;
}
- (id<ALCollectionViewActionProtocol>)deselectAction
{
    return self.actionInjections[@"deselect"];
}

- (instancetype)injectUserAction:(id<ALCollectionViewActionProtocol>)action forKey:(NSString *)actionKey
{
    if (!actionKey) {
        return self;
    }
    NSString *userActionKey = [@"user." stringByAppendingString:actionKey];
    self.actionInjections[userActionKey] = action;
    return self;
}
- (id<ALCollectionViewActionProtocol>)userActionForKey:(NSString *)actionKey
{
    if (!actionKey) {
        return nil;
    }
    NSString *userActionKey = [@"user." stringByAppendingString:actionKey];
    return self.actionInjections[userActionKey];
}

@end


