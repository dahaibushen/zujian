//
//  ALCollectionCellViewModel.h
//  OTSHomePage
//
//  Created by tianwangkuan on 10/9/16.
//  Copyright © 2016 OTSHomePage. All rights reserved.
//

#import "ALCollectionItemViewModel.h"

@interface ALCollectionCellViewModel : ALCollectionItemViewModel

/**
 *  default YES
 */
@property (nonatomic, assign) BOOL selectionAllowed;

/**
 *  default NO
 */
@property (nonatomic, assign) BOOL deselectionAllowed;

@end


@interface ALCollectionSupplementaryViewModel : ALCollectionItemViewModel

@property (nonatomic, copy, readonly) NSString *viewKind;

+ (instancetype)viewModelWithReuseId:(NSString *)reuseId viewKind:(NSString *)viewKind;

+ (instancetype)headerViewModelWithReuseId:(NSString *)reuseId;
+ (instancetype)footerViewModelWithReuseId:(NSString *)reuseId;

@end

