//
//  ALCollectionViewActionHandler.m
//  ALJetLibrary
//
//  Created by Albert Tian on 14-1-18.
//
//

#import "ALCollectionViewAction.h"
#import "ALCollectionItemViewModel.h"

@implementation ALCollectionViewAction

+ (instancetype)action
{
    ALCollectionViewAction *h = [[self alloc] init];
    return h;
}

- (void)handleActionUnitViewModel:(ALCollectionItemViewModel *)unitViewModel userInfo:(NSDictionary *)userInfo atIndexPath:(NSIndexPath *)indexPath onCompletion:(void (^)(id))completion
{
    NSAssert(false, @"subclass implement required");
}

+ (id)actionWithHandler:(ALCollectionViewActionBlockHandler)handler
{
    return [ALCollectionViewBlockAction actionWithHandler:handler];
}

@end

@interface ALCollectionViewBlockAction ()

@property (nonatomic, copy) ALCollectionViewActionBlockHandler handler;

@end
@implementation ALCollectionViewBlockAction

+ (instancetype)actionWithHandler:(ALCollectionViewActionBlockHandler)handler
{
    ALCollectionViewBlockAction *action = [self action];
    action.handler = handler;
    return action;
}

- (void)handleActionUnitViewModel:(ALCollectionItemViewModel *)unitViewModel userInfo:(NSDictionary *)userInfo atIndexPath:(NSIndexPath *)indexPath onCompletion:(void (^)(id))completion
{
    if (self.handler) {
        self.handler(unitViewModel, userInfo, indexPath, completion);
    }
}

@end

