//
//  ALTableSection.h
//  ALJetLibrary
//
//  Created by tianwangkuan on 7/25/16.
//
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@class ALCollectionItemViewModel;

@interface ALCollectionViewSection : NSObject

@property (strong, nullable, nonatomic) ALCollectionItemViewModel *header;
@property (strong, nullable, nonatomic) ALCollectionItemViewModel *footer;

- (instancetype)initWithItems:(nullable NSArray *)items header:(nullable ALCollectionItemViewModel *)header footer:(nullable ALCollectionItemViewModel *)footer;
- (id)initWithItems:(nullable NSArray *)items;

+ (instancetype)sectionWithItems:(nullable NSArray *)items header:(nullable ALCollectionItemViewModel *)header footer:(nullable ALCollectionItemViewModel *)footer;
+ (instancetype)sectionWithItems:(nullable NSArray *)items;

- (NSUInteger)itemsCount;
- (nullable id)itemAtIndex:(NSUInteger)index;

- (NSUInteger)indexOfItemIdenticalTo:(id)aRowObject;
- (NSUInteger)indexOfItem:(id)aRowObject match:(BOOL (^)(id aRowObject, id anyObject))match;

- (void)enumerateItemsUsingBlock:(void (^)(id obj, NSUInteger rowIdx, BOOL *stop))block;

- (void)removeAllItems;
- (void)removeItemAtIndex:(NSUInteger)index;

- (void)addItems:(NSArray *)items;

@end

NS_ASSUME_NONNULL_END
