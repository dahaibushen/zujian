//
//  ALTableDataSource.m
//  ALJetLibrary
//
//  Created by Albert Tian on 13-10-11.
//
//

#import <UIKit/UIKit.h>
#import "ALCollectionViewDataSource.h"
#import "ALCollectionViewSection.h"
#import <OTSCore/OTSCore.h>

@implementation ALCollectionViewDataSource

- (id)init
{
    self = [super init];
    if (self) {
        _sections = [[NSMutableArray alloc] initWithCapacity:0];
    }
    return self;
}

- (NSUInteger)sectionCount
{
    return [_sections count];
}

- (NSUInteger)itemCountAtSection:(NSUInteger)sectionIndex
{
    ALCollectionViewSection *section = [self sectionAtIndex:sectionIndex];
    return [section itemsCount];
}

- (ALCollectionViewSection *)sectionAtIndex:(NSUInteger)sectionIndex
{
    if (sectionIndex >= _sections.count) {
        return nil;
    }
    return [_sections objectAtIndex:sectionIndex];
}

- (id)headerAtSection:(NSUInteger)sectionIndex
{
    ALCollectionViewSection *section = [self sectionAtIndex:sectionIndex];
    return section.header;
}

- (id)footerAtSection:(NSUInteger)sectionIndex
{
    ALCollectionViewSection *section = [self sectionAtIndex:sectionIndex];
    return section.footer;
}

- (id)itemAtIndexPath:(NSIndexPath *)indexPath
{
    id obj = nil;
    if (indexPath) {
        ALCollectionViewSection *section = [self sectionAtIndex:indexPath.section];
        obj = [section itemAtIndex:indexPath.row];
    }
    return obj;
}

- (NSUInteger)indexOfSection:(ALCollectionViewSection *)section
{
    return [_sections indexOfObject:section];
}

- (NSIndexSet *)indexSetOfSectionMatch:(BOOL (^)(ALCollectionViewSection *section, NSUInteger index, BOOL *stop))match
{
    if (!match) {
        return nil;
    }
    NSMutableIndexSet *midxset = [NSMutableIndexSet indexSet];
    BOOL shouldStop = NO;
    for (NSInteger idx=0; idx<_sections.count; ++idx) {
        ALCollectionViewSection *section = [_sections objectAtIndex:idx];
        if (match(section, idx, &shouldStop)) {
            [midxset addIndex:idx];
        }
        if (shouldStop) {
            break;
        }
    }
    if (midxset.count > 0) {
        return midxset;
    }
    return nil;
}

- (NSIndexPath *)indexPathOfItem:(id)rowObject
{
    __block NSIndexPath *indexpathFound = nil;
    [_sections enumerateObjectsUsingBlock:^(ALCollectionViewSection *section, NSUInteger sectionIdx, BOOL *sectionstop) {
        NSUInteger rowIdxFound = [section indexOfItemIdenticalTo:rowObject];
        if (rowIdxFound != NSNotFound) {
            NSIndexPath *indexpath = [NSIndexPath indexPathForRow:rowIdxFound inSection:sectionIdx];
            indexpathFound = indexpath;
        }
    }];
    return indexpathFound;
}

- (NSIndexPath *)indexPathOfItem:(id)rowObject match:(BOOL (^)(id rowObject, id anyObject))match
{
    __block NSIndexPath *indexpathFound = nil;
    [_sections enumerateObjectsUsingBlock:^(ALCollectionViewSection *section, NSUInteger sectionIdx, BOOL *sectionstop) {
        NSUInteger rowIdxFound = [section indexOfItem:rowObject match:match];
        if (rowIdxFound != NSNotFound) {
            NSIndexPath *indexpath = [NSIndexPath indexPathForRow:rowIdxFound inSection:sectionIdx];
            indexpathFound = indexpath;
        }
    }];
    return indexpathFound;
}

- (void)enumerateItemsUsingBlock:(void (^)(id obj, NSIndexPath *idxpath, BOOL *stop))block {
    __block BOOL shouldStop = NO;
    [_sections enumerateObjectsUsingBlock:^(ALCollectionViewSection *section, NSUInteger sectionIdx, BOOL *sectionstop) {
        
        [section enumerateItemsUsingBlock:^(id obj, NSUInteger rowIdx, BOOL *rowstop) {
            NSIndexPath *indexpath = [NSIndexPath indexPathForRow:rowIdx inSection:sectionIdx];
            if (block) {
                block(obj, indexpath, &shouldStop);
            }
            if (rowstop) {
                *rowstop = shouldStop;
            }
        }];
        
        if (sectionstop) {
            *sectionstop = shouldStop;
        }
    }];
}

- (void)addSection:(ALCollectionViewSection *)section
{
    if (section) {
        [_sections addObject:section];
    }
}

- (void)insertSections:(NSArray *)array atIndexes:(NSIndexSet *)indexes
{
    if (array.count > 0) {
        [_sections safeInsertObjects:array atIndexes:indexes];
    }
}

- (ALCollectionViewSection *)addSectionWithItems:(NSArray *)items header:(ALCollectionItemViewModel *)header footer:(ALCollectionItemViewModel *)footer
{
    ALCollectionViewSection *section = [[ALCollectionViewSection alloc] initWithItems:items header:header footer:footer];
    [self addSection:section];
    return section;
}

- (ALCollectionViewSection *)addSectionWithItems:(NSArray *)items
{
    return [self addSectionWithItems:items header:nil footer:nil];
}

- (void)clearDataSource {
    [_sections removeAllObjects];
}

- (void)removeAllSections
{
    [_sections removeAllObjects];
}

- (void)removeSectionAtIndex:(NSUInteger)sectionIndex
{
    if (sectionIndex >= _sections.count) {
        return;
    }
    [_sections removeObjectAtIndex:sectionIndex];
}

- (void)removeSection:(ALCollectionViewSection *)section
{
    [_sections removeObject:section];
}

- (void)removeItemAtIndexPath:(NSIndexPath *)indexPath
{
    ALCollectionViewSection *section = [self sectionAtIndex:indexPath.section];
    [section removeItemAtIndex:indexPath.row];
}


@end

