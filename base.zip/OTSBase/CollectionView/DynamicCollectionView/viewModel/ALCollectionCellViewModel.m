//
//  ALCollectionCellViewModel.m
//  OTSHomePage
//
//  Created by tianwangkuan on 10/9/16.
//  Copyright © 2016 OTSHomePage. All rights reserved.
//

#import "ALCollectionCellViewModel.h"

@implementation ALCollectionCellViewModel

- (instancetype)initWithReuseId:(NSString *)reuseId
{
    self = [super initWithReuseId:reuseId];
    if (self) {
        _selectionAllowed = YES;
        _deselectionAllowed = NO;
    }
    return self;
}

@end

@implementation ALCollectionSupplementaryViewModel

- (instancetype)initWithReuseId:(NSString *)reuseId viewKind:(NSString *)viewKind
{
    self = [super initWithReuseId:reuseId];
    if (self) {
        _viewKind = [viewKind copy];
    }
    return self;
}
- (instancetype)initWithReuseId:(NSString *)reuseId
{
    self = [super initWithReuseId:reuseId];
    if (self) {
        _viewKind = UICollectionElementKindSectionHeader;
    }
    return self;
}

+ (instancetype)viewModelWithReuseId:(NSString *)reuseId viewKind:(NSString *)viewKind
{
    return [[self alloc] initWithReuseId:reuseId viewKind:viewKind];
}

+ (instancetype)headerViewModelWithReuseId:(NSString *)reuseId
{
    return [self viewModelWithReuseId:reuseId viewKind:UICollectionElementKindSectionHeader];
}
+ (instancetype)footerViewModelWithReuseId:(NSString *)reuseId
{
    return [self viewModelWithReuseId:reuseId viewKind:UICollectionElementKindSectionFooter];
}

@end


