//
//  ALCollectionViewDataSource.m
//  ALJetLibrary
//
//  Created by Albert Tian on 14-5-16.
//
//

#import "ALCollectionViewFlowDataSource.h"

@implementation ALCollectionViewFlowDataSource

- (ALCollectionViewFlowSection *)addSectionWithItems:(NSArray *)rows
{
    return [self addSectionWithItems:rows header:nil footer:nil];
}

- (ALCollectionViewFlowSection *)addSectionWithItems:(NSArray *)rows header:(ALCollectionItemViewModel *)header footer:(ALCollectionItemViewModel *)footer
{
    ALCollectionViewFlowSection *section = [[ALCollectionViewFlowSection alloc] initWithItems:rows header:header footer:footer];
    [self addSection:section];
    return section;
}

@end

@implementation ALCollectionViewFlowSection {
    NSMutableDictionary  *_layoutAttributes;
}

- (instancetype)initWithItems:(NSArray *)items header:(ALCollectionItemViewModel *)header footer:(ALCollectionItemViewModel *)footer
{
    self = [super initWithItems:items header:header footer:footer];
    if (self) {
        _layoutAttributes = [[NSMutableDictionary alloc] initWithCapacity:0];
    }
    return self;
}


- (void)setMinimumLineSpacing:(CGFloat)minimumLineSpacing
{
    [_layoutAttributes setValue:@(minimumLineSpacing) forKey:@"minimumLineSpacing"];
}

- (NSNumber *)minimumLineSpacing
{
    return [_layoutAttributes valueForKey:@"minimumLineSpacing"];
}

- (void)setMinimumInteritemSpacing:(CGFloat)minimumInteritemSpacing
{
    [_layoutAttributes setValue:@(minimumInteritemSpacing) forKey:@"minimumInteritemSpacing"];
}

- (NSNumber *)minimumInteritemSpacing
{
    return [_layoutAttributes valueForKey:@"minimumInteritemSpacing"];
}

- (void)setHeaderReferenceSize:(CGSize)headerReferenceSize
{
    [_layoutAttributes setValue:[NSValue valueWithCGSize:headerReferenceSize]
                         forKey:@"headerReferenceSize"];
}

-(NSValue *)headerReferenceSize
{
    return [_layoutAttributes valueForKey:@"headerReferenceSize"];
}

- (void)setFooterReferenceSize:(CGSize)footerReferenceSize
{
    [_layoutAttributes setValue:[NSValue valueWithCGSize:footerReferenceSize]
                         forKey:@"footerReferenceSize"];
}

- (NSValue *)footerReferenceSize
{
    return [_layoutAttributes valueForKey:@"footerReferenceSize"];
}

- (void)setSectionInset:(UIEdgeInsets)sectionInset
{
    [_layoutAttributes setValue:[NSValue valueWithUIEdgeInsets:sectionInset]
                         forKey:@"sectionInset"];
}

- (NSValue *)sectionInset
{
    return [_layoutAttributes valueForKey:@"sectionInset"];
}

@end



