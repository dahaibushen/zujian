//
//  OTSStickyCollectionViewFlowLayout.m
//  OTSCommon
//
//  Created by tianwangkuan on 30/11/2016.
//  Copyright © 2016 yhd.com All rights reserved.
//

#import "OTSStickyCollectionViewFlowLayout.h"
#import "OTSStickyCollectionViewFlowLayout_Subclass.h"
#import <OTSCore/OTSCore.h>

static const NSInteger kDefaultStickyHeaderZIndex = 1024;
static const NSInteger kDefaultSectionDecorationZIndex = -512;
static const NSInteger kDefaultCellDecorationZIndex = -200;

@interface OTSStickyCollectionViewFlowLayout ()

@property (strong, nonatomic) NSMutableDictionary <NSIndexPath *, UICollectionViewLayoutAttributes *>*headerLayoutAttributesMap;

@end

@implementation OTSStickyCollectionViewFlowLayout

- (instancetype)init
{
    self = [super init];
    if (self) {
        _stickyHeaderEnabled = YES;
        _cellDecorationEnabled = NO;
        _sectionDecorationEnabled = NO;
    }
    return self;
}

- (NSDictionary<NSNumber *, NSValue *> *)allSectionFrames
{
    return [self.sectionFrameMapping copy];
}

- (void)setStickyHeaderEnabled:(BOOL)stickyHeaderEnabled
{
    if (stickyHeaderEnabled != _stickyHeaderEnabled) {
        _stickyHeaderEnabled = stickyHeaderEnabled;
        [self invalidateLayout];
    }
}

- (void)setCellDecorationEnabled:(BOOL)cellDecorationEnabled
{
    if (cellDecorationEnabled != _cellDecorationEnabled) {
        _cellDecorationEnabled = cellDecorationEnabled;
        [self invalidateLayout];
    }
}

- (void)setSectionDecorationEnabled:(BOOL)sectionDecorationEnabled
{
    if (sectionDecorationEnabled != _sectionDecorationEnabled) {
        _sectionDecorationEnabled = sectionDecorationEnabled;
        [self invalidateLayout];
    }
}

/**
 section装饰，cell装饰，sticking header。支持竖直滑动。
 */
- (void)prepareLayout
{
    self.scrollDirection = UICollectionViewScrollDirectionVertical;
    if ([self respondsToSelector:@selector(setSectionHeadersPinToVisibleBounds:)]) {
        self.sectionHeadersPinToVisibleBounds = NO;
        self.sectionFootersPinToVisibleBounds = NO;
    }

    self.sectionFrameMapping = [NSMutableDictionary dictionary];
    self.sectionDecorationAttributesMap = [NSMutableDictionary dictionary];
    self.cellDecorationAttributesMap = [NSMutableDictionary dictionary];
    self.stickyHeaderSections = [NSMutableIndexSet indexSet];
    self.headerLayoutAttributesMap = [NSMutableDictionary dictionary];
    
    [super prepareLayout];

    for (int section = 0; section < [self.collectionView numberOfSections]; section++) {
        
        [self calculateFrameOfSection:section];
        
        if (self.stickyHeaderEnabled) {
            [self setupStickHeaderForSection:section];
        }
        NSIndexPath *headerIndexPath = [NSIndexPath indexPathForItem:0 inSection:section];
        UICollectionViewLayoutAttributes *header = [super layoutAttributesForSupplementaryViewOfKind:UICollectionElementKindSectionHeader atIndexPath:headerIndexPath];
        if (header && header.size.width > 0 && header.size.height > 0) {
            if ([self.stickyHeaderSections containsIndex:section]) {
                [self modifyHeaderAttributesForSticking:header contentOffset:self.collectionView.contentOffset];
            }
            self.headerLayoutAttributesMap[headerIndexPath] = header;
        }
        
        
        if (self.sectionDecorationEnabled) {
            [self setupDecorationViewForSection:section];
        }
        if (self.cellDecorationEnabled) {
            for (int itemIndex = 0 ; itemIndex < [self.collectionView numberOfItemsInSection:section]; itemIndex++) {
                NSIndexPath *indexPath = [NSIndexPath indexPathForItem:itemIndex inSection:section];
                UICollectionViewLayoutAttributes *attributes = [self layoutAttributesForItemAtIndexPath:indexPath];
                if (attributes) {
                    [self setupCellDecorationView:attributes atIndexPath:indexPath];
                }
            }
        }
    }
    
}

- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect {
    NSArray *attributes = [super layoutAttributesForElementsInRect:rect];
    
    NSMutableArray *allAttributes = [NSMutableArray arrayWithArray:attributes];
    
    for (NSInteger index=0; index<allAttributes.count; ++index) {
        UICollectionViewLayoutAttributes *header = allAttributes[index];
        if (header.representedElementCategory == UICollectionElementCategorySupplementaryView &&
            [header.representedElementKind isEqualToString:UICollectionElementKindSectionHeader]) {
            UICollectionViewLayoutAttributes *replaceHeader = self.headerLayoutAttributesMap[header.indexPath];
            if (replaceHeader) {
                [allAttributes replaceObjectAtIndex:index withObject:replaceHeader];
            }
        }
    }
    [self modifyStickHeaderForAllAttibutes:allAttributes inRect:rect];
    
    [self.sectionDecorationAttributesMap enumerateKeysAndObjectsUsingBlock:^(NSNumber * _Nonnull key, UICollectionViewLayoutAttributes * _Nonnull obj, BOOL * _Nonnull stop) {
        if (![obj isKindOfClass:[NSNull class]] &&
            CGRectIntersectsRect(rect, obj.frame)) {
            [allAttributes addObject:obj];
        }
    }];
    
    [self.cellDecorationAttributesMap enumerateKeysAndObjectsUsingBlock:^(NSIndexPath * _Nonnull key, UICollectionViewLayoutAttributes * _Nonnull obj, BOOL * _Nonnull stop) {
        if (![obj isKindOfClass:[NSNull class]] &&
            CGRectIntersectsRect(rect, obj.frame)) {
            [allAttributes addObject:obj];
        }
    }];
    
    return allAttributes;
}

- (UICollectionViewLayoutAttributes *)layoutAttributesForSupplementaryViewOfKind:(NSString *)elementKind atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewLayoutAttributes *attributes = nil;
    if ([elementKind isEqualToString:UICollectionElementKindSectionHeader]) {
        attributes = self.headerLayoutAttributesMap[indexPath];
        if (!attributes) {
            attributes = [super layoutAttributesForSupplementaryViewOfKind:elementKind atIndexPath:indexPath];
        }
    } else {
        attributes = [super layoutAttributesForSupplementaryViewOfKind:elementKind atIndexPath:indexPath];
    }
    return attributes;
}

+ (CGRect)joinRect:(CGRect)rect1 :(CGRect)rect2
{
    CGRect enlargeBounds = rect2;
    if (CGRectGetMinX(rect1) < CGRectGetMinX(enlargeBounds)){
        enlargeBounds.origin.x = CGRectGetMinX(rect1);
    }
    if (CGRectGetMinY(rect1) < CGRectGetMinY(enlargeBounds)) {
        enlargeBounds.origin.y = CGRectGetMinY(rect1);
    }
    if (CGRectGetMaxX(rect1) > CGRectGetMaxX(enlargeBounds)) {
        enlargeBounds.size.width = CGRectGetMaxX(rect1) - CGRectGetMinX(enlargeBounds);
    }
    if (CGRectGetMaxY(rect1) > CGRectGetMaxY(enlargeBounds)) {
        enlargeBounds.size.height = CGRectGetMaxY(rect1) - CGRectGetMinY(enlargeBounds);
    }
    return enlargeBounds;
}

- (BOOL)shouldInvalidateLayoutForBoundsChange:(CGRect)newBound
{
    CGRect oldBounds = self.collectionView.bounds;
    BOOL invalid = [super shouldInvalidateLayoutForBoundsChange:newBound];
    if (invalid) {
        return invalid;
    }
    if(!CGSizeEqualToSize(newBound.size, oldBounds.size)) {
        return YES;
    }
    if (self.stickyHeaderEnabled && self.stickyHeaderSections.count > 0) {
        return YES;
    }
    return NO;
}

- (UICollectionViewLayoutInvalidationContext *)invalidationContextForBoundsChange:(CGRect)newBounds
{
    UICollectionViewFlowLayoutInvalidationContext *context = (UICollectionViewFlowLayoutInvalidationContext *)[super invalidationContextForBoundsChange:newBounds];
    CGRect oldBounds = self.collectionView.bounds;
    BOOL all;
    all = !CGSizeEqualToSize(newBounds.size, oldBounds.size);
    if (all) {
        context.invalidateFlowLayoutDelegateMetrics = all;
    }
    
    if (self.stickyHeaderEnabled) {
        NSMutableArray<NSIndexPath *> *headers = [NSMutableArray array];
        CGRect enlargeBounds = [self.class joinRect:oldBounds :newBounds];
        [self.stickyHeaderSections enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL * _Nonnull stop) {
            NSValue *lastSectionFrameV = self.sectionFrameMapping[@(idx)];
            if (lastSectionFrameV && ![lastSectionFrameV isKindOfClass:NSNull.class]) {
                CGRect lastSectionFrame = lastSectionFrameV.CGRectValue;
                if (CGRectIntersectsRect(enlargeBounds, lastSectionFrame)) {
                    NSIndexPath *headerIndexPath = [NSIndexPath indexPathForItem:0 inSection:idx];
                    UICollectionViewLayoutAttributes *header = self.headerLayoutAttributesMap[headerIndexPath];
                    if (header) {
                        header = [header copy];
                        [self modifyHeaderAttributesForSticking:header contentOffset:newBounds.origin];
                        self.headerLayoutAttributesMap[headerIndexPath] = header;
                        [headers addObject:headerIndexPath];
                    }
                }
            }
        }];
        if (headers.count) {
            context.invalidateFlowLayoutAttributes = YES;
            // [context invalidateSupplementaryElementsOfKind:UICollectionElementKindSectionHeader atIndexPaths:headers];
        }
    }
    return context;
}

- (NSValue *)frameOfSection:(NSInteger)section
{
    NSValue *sectionFrame = self.sectionFrameMapping[@(section)];
    if (sectionFrame) {
        if ([sectionFrame isKindOfClass:NSNull.class]) {
            return nil;
        }
    }
    return sectionFrame;
}

#pragma mark - Private

- (id<OTSStickyCollectionViewFlowLayoutDelegate>)layoutDelegate
{
    id<OTSStickyCollectionViewFlowLayoutDelegate> delegate = (id)self.collectionView.delegate;
    return delegate;
}

- (NSValue *)calculateFrameOfSection:(NSInteger)section
{
    NSUInteger sectionCount = [self.collectionView numberOfSections];
    if (section < 0 || section >= sectionCount) {
        return nil;
    }
    NSValue *sectionFrame = [self frameOfSection:section];
    if (sectionFrame) {
        return sectionFrame;
    }
    
    NSInteger itemCount = [self.collectionView numberOfItemsInSection:section];
    NSIndexPath *sectionIndexPath = [NSIndexPath indexPathForItem:0 inSection:section];
    
    UICollectionViewLayoutAttributes *header = [self layoutAttributesForSupplementaryViewOfKind:UICollectionElementKindSectionHeader atIndexPath:sectionIndexPath];
    UICollectionViewLayoutAttributes *footer = [self layoutAttributesForSupplementaryViewOfKind:UICollectionElementKindSectionFooter atIndexPath:sectionIndexPath];
    UICollectionViewLayoutAttributes *topItem = nil, *bottomItem = nil;
    if (itemCount > 0) {
        for (NSInteger itemIndex = 0; itemIndex < itemCount; ++itemIndex) {
            UICollectionViewLayoutAttributes *item = [self layoutAttributesForItemAtIndexPath:[NSIndexPath indexPathForItem:itemIndex inSection:section]];
            if (!topItem) {
                topItem = item;
                bottomItem = item;
            }
            if (CGRectGetMinY(item.frame) < CGRectGetMinY(topItem.frame)) {
                topItem = item;
            }
            if (CGRectGetMaxY(item.frame) > CGRectGetMaxY(bottomItem.frame)) {
                bottomItem = item;
            }
        }
    }
    
    // 算出section frame.
    // 覆盖下面几种情况
    // 0 : header
    // 1 : footer
    // 2 : header + footer
    // 3 : header + cell + footer
    // 4 : cell
    // 5 : header + cell
    // 6 : cell + footer
    // 7 : all empty
    // 当sectionHeadersPinToVisibleBounds激活时，如果section没有cell，
    // 怎么推测出正确的起点？我们只能通过查找上下文的section来完成了.
    //
    CGRect frame = CGRectZero;
    UIEdgeInsets sectionInset = self.sectionInset;
    id<UICollectionViewDelegateFlowLayout> delegate = (id)self.collectionView.delegate;
    if ([delegate respondsToSelector:@selector(collectionView:layout:insetForSectionAtIndex:)]) {
        sectionInset = [delegate collectionView:self.collectionView layout:self insetForSectionAtIndex:section];
    }
    frame.size.width = self.collectionView.bounds.size.width;
    frame.origin.x = 0;
    BOOL (^sizeLargerThanZero)(CGSize) = ^BOOL(CGSize size) {
        return (size.width > 0 && size.height > 0);
    };
    
    // 计算section的top
    if (topItem) {
        frame.origin.y = topItem.frame.origin.y - sectionInset.top;
        // header可能是移动的
        if (header && sizeLargerThanZero(header.frame.size)) {
            frame.origin.y -= header.size.height;
        }
    } else {
        if (section == 0) {
            frame.origin.y = 0;
        } else {
            NSValue *upperSectionFrame = nil;
            for (NSInteger index = section-1; index >= 0; --index) {
                upperSectionFrame = [self calculateFrameOfSection:index];
                if (upperSectionFrame) {
                    break;
                }
            }
            if (upperSectionFrame) {
                frame.origin.y = CGRectGetMaxY(upperSectionFrame.CGRectValue);
            } else {
                OTSLog(@"!Warning! something wrong when calculate frame for section %ld", (long)section);
                if (header && sizeLargerThanZero(header.frame.size)) {
                    frame.origin.y = header.frame.origin.y;
                }else if (footer && sizeLargerThanZero(footer.frame.size)) {
                    frame.origin.y = footer.frame.origin.y - sectionInset.top - sectionInset.bottom;
                }
            }
        }
    }
    
    // 计算section的height
    frame.size.height = sectionInset.top + sectionInset.bottom;
    if (bottomItem) {
        frame.size.height += (CGRectGetMaxY(bottomItem.frame) - CGRectGetMinY(topItem.frame));
    }
    if (header && sizeLargerThanZero(header.frame.size)) {
        frame.size.height += CGRectGetHeight(header.frame);
    }
    if (footer && sizeLargerThanZero(footer.frame.size)) {
        frame.size.height += (footer.size.height);
    }
    
    
    if (frame.size.width <= 0 && frame.size.height <= 0) {
        OTSLog(@"!Warning! zero frame(%@) when calculate frame for section %ld", [NSValue valueWithCGRect:frame] ,(long)section);
    }
    NSValue *frameValue = [NSValue valueWithCGRect:frame];
    self.sectionFrameMapping[@(section)] = frameValue;
    return frameValue;
}

#pragma mark section decoration

- (void)setupDecorationViewForSection:(NSInteger)section
{
    NSValue *sectionFrame = [self frameOfSection:section];
    if (sectionFrame) {
        CGRect frame = sectionFrame.CGRectValue;
        if (frame.size.width > 0 && frame.size.height > 0) {
            UICollectionViewLayoutAttributes *attribute = [self createDecorationLayoutAttributeForSection:section frame:frame];
            if (!attribute) {
                self.sectionDecorationAttributesMap[@(section)] = (id)NSNull.null;
            } else {
                attribute.frame = frame;
                if (attribute.zIndex == 0) {
                    attribute.zIndex = kDefaultSectionDecorationZIndex;
                }
                self.sectionDecorationAttributesMap[@(section)] = attribute;
            }
        }
    }
}

- (UICollectionViewLayoutAttributes *)layoutAttributesForDecorationViewOfKind:(NSString *)elementKind atIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath) {
        if (indexPath.item == -1) {
            id attr = self.sectionDecorationAttributesMap[@(indexPath.section)];
            if (attr == NSNull.null) {
                UICollectionViewLayoutAttributes *defaultAttri = [UICollectionViewLayoutAttributes layoutAttributesForDecorationViewOfKind:elementKind withIndexPath:indexPath];
                defaultAttri.frame = CGRectZero;
                return defaultAttri;
            } if (attr) {
                return attr;
            }
        }
        
        id attr = self.cellDecorationAttributesMap[indexPath];
        if (attr == NSNull.null) {
            UICollectionViewLayoutAttributes *defaultAttri = [UICollectionViewLayoutAttributes layoutAttributesForDecorationViewOfKind:elementKind withIndexPath:indexPath];
            defaultAttri.frame = CGRectZero;
            return defaultAttri;
        } else if (attr) {
            return attr;
        }
        
    }
    return nil;
}

- (UICollectionViewLayoutAttributes *)createDecorationLayoutAttributeForSection:(NSInteger)sectionIndex frame:(CGRect)frame
{
    if ([self.layoutDelegate respondsToSelector:@selector(collectionView:layout:decorationLayoutAttributesForSection:sectionFrame:)]) {
        UICollectionViewLayoutAttributes *attributes = [self.layoutDelegate collectionView:self.collectionView layout:self decorationLayoutAttributesForSection:sectionIndex sectionFrame:frame];
        if (attributes) {
            NSAssert(attributes.representedElementCategory == UICollectionElementCategoryDecorationView,
                     @"%@, must create decoration layout attributes.",
                     NSStringFromSelector(@selector(collectionView:layout:decorationLayoutAttributesForSection:sectionFrame:)));
        }
        return attributes;
    }
    return nil;
}

#pragma mark cell decoration

- (void)setupCellDecorationView:(UICollectionViewLayoutAttributes *)cellLayoutAttributes atIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewLayoutAttributes *attribute = [self createCellDecorationLayoutAttribute:cellLayoutAttributes atIndexPath:indexPath];
    if (!attribute) {
        self.cellDecorationAttributesMap[indexPath] = (id)NSNull.null;
    } else {
        if (attribute.zIndex == 0) {
            attribute.zIndex = cellLayoutAttributes.zIndex + kDefaultCellDecorationZIndex;
        }
        self.cellDecorationAttributesMap[indexPath] = attribute;
    }
}

- (UICollectionViewLayoutAttributes *)createCellDecorationLayoutAttribute:(UICollectionViewLayoutAttributes *)cellLayoutAttributes atIndexPath:(NSIndexPath *)indexPath
{
    BOOL delegateResponds = [self.layoutDelegate respondsToSelector:@selector(collectionView:layout:decorationLayoutAttributesForCell:atIndexPath:)];
    
    if (delegateResponds) {
        UICollectionViewLayoutAttributes *attributes = [self.layoutDelegate collectionView:self.collectionView layout:self decorationLayoutAttributesForCell:cellLayoutAttributes atIndexPath:indexPath];
        if (attributes) {
            NSAssert(attributes.representedElementCategory == UICollectionElementCategoryDecorationView,
                     @"%@, must create decoration layout attributes.",
                     NSStringFromSelector(@selector(collectionView:layout:decorationLayoutAttributesForCell:atIndexPath:)));
        }
        return attributes;
    }
    return nil;
}

#pragma mark sticky header

- (void)setupStickHeaderForSection:(NSUInteger)section
{
    BOOL stick = [self shouldStickHeaderToTopInSection:section];
    if (stick) {
        [self.stickyHeaderSections addIndex:section];
    }
}

- (BOOL)shouldStickHeaderToTopInSection:(NSUInteger)section
{
    BOOL shouldStickToTop = YES;
    if ([[self layoutDelegate] respondsToSelector:@selector(collectionView:layout:shouldStickHeaderToTopInSection:)]) {
        shouldStickToTop = [self.layoutDelegate collectionView:self.collectionView layout:self shouldStickHeaderToTopInSection:section];
    }
    return shouldStickToTop;
}

- (void)modifyStickHeaderForAllAttibutes:(NSMutableArray *)allAttributes inRect:(CGRect)rect
{
    NSMutableIndexSet *visibleSectionsWithoutHeader = [NSMutableIndexSet indexSet];
    for (UICollectionViewLayoutAttributes *itemAttributes in allAttributes) {
        NSInteger sectionIndex = itemAttributes.indexPath.section;
        if (![visibleSectionsWithoutHeader containsIndex:sectionIndex]) {
            [visibleSectionsWithoutHeader addIndex:sectionIndex];
        }
    }
    for (UICollectionViewLayoutAttributes *itemAttributes in allAttributes) {
        if (itemAttributes.representedElementKind == UICollectionElementKindSectionHeader) {
            NSInteger sectionIndex = itemAttributes.indexPath.section;
            if ([visibleSectionsWithoutHeader containsIndex:sectionIndex]) {
                [visibleSectionsWithoutHeader removeIndex:sectionIndex];
            }
        }
    }
    [visibleSectionsWithoutHeader enumerateIndexesUsingBlock:^(NSUInteger idx, BOOL * _Nonnull stop) {
        if ([self.stickyHeaderSections containsIndex:idx]) {
            NSIndexPath *indexPath = [NSIndexPath indexPathForItem:0 inSection:idx];
            UICollectionViewLayoutAttributes *headerAttributes = [self layoutAttributesForSupplementaryViewOfKind:UICollectionElementKindSectionHeader atIndexPath:indexPath];
            if (headerAttributes.frame.size.width > 0 && headerAttributes.frame.size.height > 0) {
                [allAttributes addObject:headerAttributes];
            }
        }
    }];
}

- (void)modifyHeaderAttributesForSticking:(UICollectionViewLayoutAttributes *)headerAttributes contentOffset:(CGPoint)contentOffset
{
    NSInteger sectionIndex = headerAttributes.indexPath.section;
    NSValue *sectionFrameValue = [self frameOfSection:sectionIndex];
    if (sectionFrameValue) {
        CGRect sectionFrame = sectionFrameValue.CGRectValue;
        UICollectionViewLayoutAttributes *footerAttributes = [self layoutAttributesForSupplementaryViewOfKind:UICollectionElementKindSectionFooter atIndexPath:headerAttributes.indexPath];
        CGFloat minY = CGRectGetMinY(sectionFrame);
        CGFloat maxY = CGRectGetMaxY(sectionFrame) - headerAttributes.frame.size.height;
        if (footerAttributes && footerAttributes.frame.size.height > 0) {
            maxY -= footerAttributes.frame.size.height ;
        }
        CGFloat offset = contentOffset.y + self.collectionView.contentInset.top;
        CGRect headerFrame = headerAttributes.frame;
        headerFrame.origin.y = offset > minY ? offset : minY;
        headerFrame.origin.y = headerFrame.origin.y < maxY ? headerFrame.origin.y : maxY;
        headerAttributes.frame = headerFrame;
        headerAttributes.zIndex = kDefaultStickyHeaderZIndex;
    }
}



@end
