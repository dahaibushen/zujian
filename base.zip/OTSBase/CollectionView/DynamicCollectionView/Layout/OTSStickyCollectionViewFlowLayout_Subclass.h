//
//  OTSStickyCollectionViewFlowLayout_Subclass.h
//  OTSCommon
//
//  Created by tianwangkuan on 30/11/2016.
//  Copyright © 2016 yhd.com All rights reserved.
//

#ifndef OTSStickyCollectionViewFlowLayout_Subclass_h
#define OTSStickyCollectionViewFlowLayout_Subclass_h

#import "OTSStickyCollectionViewFlowLayout.h"

@interface OTSStickyCollectionViewFlowLayout ()

@property (strong, nonatomic) NSMutableDictionary <NSNumber *, NSValue *> *sectionFrameMapping;

@property (strong, nonatomic) NSMutableDictionary <NSNumber *, UICollectionViewLayoutAttributes *> *sectionDecorationAttributesMap;

@property (strong, nonatomic) NSMutableDictionary <NSIndexPath *, UICollectionViewLayoutAttributes *> *cellDecorationAttributesMap;

@property (strong, nonatomic) NSMutableIndexSet *stickyHeaderSections;

@end

#endif /* OTSStickyCollectionViewFlowLayout_Subclass_h */
