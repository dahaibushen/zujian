//
//  OTSStickyCollectionViewFlowLayout.h
//  OTSCommon
//
//  Created by tianwangkuan on 30/11/2016.
//  Copyright © 2016 yhd.com All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol OTSStickyCollectionViewFlowLayoutDelegate <UICollectionViewDelegateFlowLayout>

@optional

//
- (UICollectionViewLayoutAttributes *)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout decorationLayoutAttributesForSection:(NSInteger)section sectionFrame:(CGRect)frame;

- (UICollectionViewLayoutAttributes *)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout decorationLayoutAttributesForCell:(UICollectionViewLayoutAttributes *)cellLayoutAttributes atIndexPath:(NSIndexPath *)indexPath;

- (BOOL)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout shouldStickHeaderToTopInSection:(NSInteger)section;

@end

@interface OTSStickyCollectionViewFlowLayout : UICollectionViewFlowLayout

- (NSValue *)frameOfSection:(NSInteger)section;
- (NSDictionary<NSNumber *, NSValue *> *)allSectionFrames;

@property (assign, nonatomic) BOOL stickyHeaderEnabled;      // default YES
@property (assign, nonatomic) BOOL cellDecorationEnabled;      // default NO
@property (assign, nonatomic) BOOL sectionDecorationEnabled;   // default NO

@end
