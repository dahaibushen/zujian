//
//  ALCollectionViewDelegate.m
//  ALJetLibrary
//
//  Created by Albert Tian on 14-1-19.
//
//

#import "ALCollectionViewDelegate.h"
#import "ALCollectionItemViewModel.h"
#import "ALCollectionCellViewModel.h"
#import "ALCollectionViewSection.h"

@interface ALCollectionViewDelegate ()

@property (nonatomic, weak) id forwardingTarget;

@end

@implementation ALCollectionViewDelegate

- (instancetype)initWithCollectionView:(UICollectionView *)collectionView
                  dataSource:(ALCollectionViewDataSource *)dataSource
{
    self = [super init];
    if (self) {
        _collectionView = collectionView;
        _dataSource = dataSource;
    }
    return self;
}

- (void)connect
{
    self.collectionView.dataSource = self;
    self.collectionView.delegate = self;
}

- (void)dealloc
{
    if (self.collectionView.delegate == self) {
        self.collectionView.delegate = nil;
    }
    if (self.collectionView.dataSource == self) {
        self.collectionView.dataSource = nil;
    }
}

#pragma mark forward

- (instancetype)forwardTo:(id)forwardingTarget
{
    self.forwardingTarget = forwardingTarget;
    return self;
}
- (BOOL)respondsToSelector:(SEL)aSelector
{
    BOOL response = [super respondsToSelector:aSelector];
    if (!response) {
        response = [self.forwardingTarget respondsToSelector:aSelector];
    }
    return response;
}
- (id)forwardingTargetForSelector:(SEL)aSelector
{
    __strong id forwardingTarget = self.forwardingTarget;
    if (forwardingTarget && [forwardingTarget respondsToSelector:aSelector]) {
        return forwardingTarget;
    }
    return [super forwardingTargetForSelector:aSelector];
}

#pragma mark action

- (void)handleAction:(NSString *)actionKey unitView:(id)unitView viewModel:(ALCollectionItemViewModel *)unitViewModel userInfo:(NSDictionary *)userInfo atIndexPath:(NSIndexPath *)indexPath onCompletion:(void (^)(id))completion
{
    NSDictionary *packedUserInfo = [self packViewInfoForUserInfo:userInfo unitView:unitView collectionView:self.collectionView];
    id<ALCollectionViewActionProtocol> action = [unitViewModel userActionForKey:actionKey];
    [action handleActionUnitViewModel:unitViewModel userInfo:packedUserInfo atIndexPath:indexPath onCompletion:completion];
}

- (NSDictionary *)packViewInfoForUserInfo:(NSDictionary *)userInfo unitView:(UICollectionReusableView *)unitView collectionView:(UICollectionView *)collectionView
{
    NSMutableDictionary *viewInfo = [NSMutableDictionary dictionaryWithDictionary:userInfo ? userInfo : @{}];
    viewInfo[@"view.unitView"] = unitView;
    viewInfo[@"view.collectionView"] = collectionView;
    return viewInfo;
}

@end

@implementation  ALCollectionViewDelegate (DataSource)

- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return [self.dataSource sectionCount];
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.dataSource itemCountAtSection:section];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ALCollectionCellViewModel *cellViewModel = [self.dataSource itemAtIndexPath:indexPath];
    UICollectionViewCell<ALCollectionViewUnitViewInterface> *cell = [collectionView dequeueReusableCellWithReuseIdentifier:cellViewModel.reuseIdentifier forIndexPath:indexPath];
    NSAssert(cell != nil, @"cell should not be nil, reuseId=%@", cellViewModel.reuseIdentifier);
    NSAssert(([cell isKindOfClass:UICollectionViewCell.class] &&
              [cell conformsToProtocol:@protocol(ALCollectionViewUnitViewInterface)]), @"cell=%@", cell);
    [cell setUserActionDelegate:self];
    [cell updateViewModel:cellViewModel atIndexPath:indexPath];
    return cell;
}

- (UICollectionReusableView *)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath
{
    ALCollectionSupplementaryViewModel *viewModel = nil;
    ALCollectionViewSection *section = [self.dataSource sectionAtIndex:indexPath.section];
    if ([kind isEqualToString:UICollectionElementKindSectionHeader]) {
        viewModel = (ALCollectionSupplementaryViewModel *)section.header;
    } else if ([kind isEqualToString:UICollectionElementKindSectionFooter]) {
        viewModel = (ALCollectionSupplementaryViewModel *)section.footer;
    }
    NSAssert([viewModel isKindOfClass:ALCollectionSupplementaryViewModel.class], @"unitViewModel=%@", viewModel);
    
    UICollectionReusableView<ALCollectionViewUnitViewInterface> *supplementaryView = nil;
    supplementaryView = [collectionView dequeueReusableSupplementaryViewOfKind:viewModel.viewKind withReuseIdentifier:viewModel.reuseIdentifier forIndexPath:indexPath];
    NSAssert(supplementaryView != nil, @"supplementaryView should not be nil, reuseId=%@", viewModel.reuseIdentifier);
    NSAssert(([supplementaryView isKindOfClass:UICollectionReusableView.class] &&
              [supplementaryView conformsToProtocol:@protocol(ALCollectionViewUnitViewInterface)]), @"supplementaryView=%@", supplementaryView);
    supplementaryView.userActionDelegate = self;
    [supplementaryView updateViewModel:viewModel atIndexPath:indexPath];
    return supplementaryView;
}

@end

@implementation ALCollectionViewDelegate (Delegate)

- (BOOL)collectionView:(UICollectionView *)collectionView shouldHighlightItemAtIndexPath:(NSIndexPath *)indexPath
{
    ALCollectionCellViewModel *viewModel = [self.dataSource itemAtIndexPath:indexPath];
    if ([viewModel isKindOfClass:ALCollectionCellViewModel.class]) {
        return viewModel.selectionAllowed;
    }
    return YES;
}

- (BOOL)collectionView:(UICollectionView *)collectionView shouldSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    ALCollectionCellViewModel *viewModel = [self.dataSource itemAtIndexPath:indexPath];
    if ([viewModel isKindOfClass:ALCollectionCellViewModel.class]) {
        return viewModel.selectionAllowed;
    }
    return YES;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    ALCollectionItemViewModel *viewModel = [self.dataSource itemAtIndexPath:indexPath];
    id<ALCollectionViewActionProtocol> action = [viewModel selectAction];
    NSDictionary *packedUserInfo = [self packViewInfoForUserInfo:nil unitView:cell collectionView:self.collectionView];
    [action handleActionUnitViewModel:viewModel userInfo:packedUserInfo atIndexPath:indexPath onCompletion:^(id keepSelection) {
        if (!keepSelection || ![keepSelection boolValue]) {
            [collectionView deselectItemAtIndexPath:indexPath animated:YES];
        }
    }];
}

- (BOOL)collectionView:(UICollectionView *)collectionView shouldDeselectItemAtIndexPath:(NSIndexPath *)indexPath
{
    ALCollectionCellViewModel *viewModel = [self.dataSource itemAtIndexPath:indexPath];
    if ([viewModel isKindOfClass:ALCollectionCellViewModel.class]) {
        return viewModel.deselectionAllowed;
    }
    return YES;
}

- (void)collectionView:(UICollectionView *)collectionView didDeselectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell = [collectionView cellForItemAtIndexPath:indexPath];
    ALCollectionItemViewModel *viewModel = [self.dataSource itemAtIndexPath:indexPath];
    id<ALCollectionViewActionProtocol> action = [viewModel deselectAction];
    NSDictionary *packedUserInfo = [self packViewInfoForUserInfo:nil unitView:cell collectionView:self.collectionView];
    [action handleActionUnitViewModel:viewModel userInfo:packedUserInfo atIndexPath:indexPath onCompletion:nil];
}

@end

