//
//  ALCollectionViewVariantFlowLayoutDelegate.m
//  ALJetLibrary
//
//  Created by tianwangkuan on 7/29/16.
//
//

#import "ALCollectionViewVariantFlowLayoutDelegate.h"
#import "ALCollectionItemViewModel.h"
#import "ALCollectionCellViewModel.h"
#import "ALCollectionViewSection.h"

@interface ALCollectionViewVariantFlowLayoutDelegate ()

@property (strong, nonatomic) NSCache *templateViewCache;

@end

@implementation ALCollectionViewVariantFlowLayoutDelegate

- (NSCache *)templateViewCache {
    if (!_templateViewCache) {
        _templateViewCache = [[NSCache alloc] init];
    }
    return _templateViewCache;
}

+ (NSString *)keyForViewKind:(NSString *)viewKind reuseId:(NSString *)reuseId
{
    if (viewKind && reuseId) {
        return [NSString stringWithFormat:@"%@/%@", viewKind, reuseId];
    }
    return nil;
}

+ (Class)cellClassForKey:(NSString *)key collectionView:(UICollectionView *)collectionView
{
    if (!key || !collectionView) {
        return nil;
    }
    NSDictionary *classDict = [collectionView valueForKey:@"_cellClassDict"];
    Class cellClass = classDict[key];
    return cellClass;
}
+ (UINib *)cellNibForKey:(NSString *)key collectionView:(UICollectionView *)collectionView
{
    if (!key || !collectionView) {
        return nil;
    }
    NSDictionary *nibDict = [collectionView valueForKey:@"_cellNibDict"];
    UINib *nib = nibDict[key];
    return nib;
}

+ (Class)viewClassForKey:(NSString *)key collectionView:(UICollectionView *)collectionView
{
    if (!key || !collectionView) {
        return nil;
    }
    NSDictionary *classDict = [collectionView valueForKey:@"_supplementaryViewClassDict"];
    Class cellClass = classDict[key];
    return cellClass;
}
+ (UINib *)viewNibForKey:(NSString *)key collectionView:(UICollectionView *)collectionView
{
    if (!key || !collectionView) {
        return nil;
    }
    NSDictionary *nibDict = [collectionView valueForKey:@"_supplementaryViewNibDict"];
    UINib *nib = nibDict[key];
    return nib;
}

- (UICollectionViewCell *)createTemplateCellForReuseId:(NSString *)reuseId collectionView:(UICollectionView *)collectionView
{
    if (!reuseId || !collectionView) {
        return nil;
    }
    UICollectionViewCell *cell = nil;
    Class cellClass = [self.class cellClassForKey:reuseId collectionView:collectionView];
    if (cellClass) {
        cell = [[cellClass alloc] initWithFrame:CGRectZero];
    } else {
        UINib *nib = [self.class cellNibForKey:reuseId collectionView:collectionView];
//        UINib *nib = nibDict[reuseId];
        if (nib) {
            cell = [nib instantiateWithOwner:nil options:nil].firstObject;
        }
    }
    return cell;
}

- (UICollectionReusableView *)createTemplateSupplementaryViewForReuseId:(NSString *)reuseId viewKind:(NSString *)viewKind collectionView:(UICollectionView *)collectionView
{
    if (!reuseId || !viewKind || !collectionView) {
        return nil;
    }
    UICollectionViewCell *cell = nil;
    NSString *key = [self.class keyForViewKind:viewKind reuseId:reuseId];
    Class cellClass = [self.class viewClassForKey:key collectionView:collectionView];
    if (cellClass) {
        cell = [[cellClass alloc] initWithFrame:CGRectZero];
    } else {
        UINib *nib = [self.class viewNibForKey:key collectionView:collectionView];
        if (nib) {
            cell = [nib instantiateWithOwner:nil options:nil].firstObject;
        }
    }
    return cell;
}

- (UICollectionViewCell *)templateCellForReuseId:(NSString *)reuseId collectionView:(UICollectionView *)collectionView
{
    if (!reuseId) {
        return nil;
    }
    UICollectionViewCell *cell = [self.templateViewCache objectForKey:reuseId];
    if (!cell) {
        cell = [self createTemplateCellForReuseId:reuseId collectionView:collectionView];
        if (cell) {
            [self.templateViewCache setObject:cell forKey:reuseId cost:1];
        }
    }
    return cell;
}

- (UICollectionReusableView *)templateSupplementaryViewForReuseId:(NSString *)reuseId viewKinkd:(NSString *)viewKind collectionView:(UICollectionView *)collectionView
{
    if (!reuseId || !viewKind) {
        return nil;
    }
    NSString *key = [viewKind stringByAppendingFormat:@"/%@", reuseId];
    UICollectionReusableView *view = [self.templateViewCache objectForKey:key];
    if (!view) {
        view = [self createTemplateSupplementaryViewForReuseId:reuseId viewKind:viewKind collectionView:collectionView];
        if (view) {
            [self.templateViewCache setObject:view forKey:key cost:1];
        }
    }
    return view;
}

- (NSValue *)cellClassSizeForViewModel:(ALCollectionCellViewModel *)unitViewModel
                        collectionView:(UICollectionView *)collectionView
                           atIndexPath:(NSIndexPath *)indexPath
{
    NSString *reuseId = unitViewModel.reuseIdentifier;
    if (!reuseId || !collectionView) {
        return nil;
    }
    Class<ALCollectionViewUnitViewInterface> cellClass = [self.class cellClassForKey:reuseId collectionView:collectionView];
    if (!cellClass) {
        UICollectionViewCell *cell = [self.templateViewCache objectForKey:reuseId];
        if (!cell) {
            UINib *nib = [self.class cellNibForKey:reuseId collectionView:collectionView];
            if (nib) {
                cell = [nib instantiateWithOwner:nil options:nil].firstObject;
                if (cell) {
                    [self.templateViewCache setObject:cell forKey:reuseId cost:1];
                }
            }
        }
        cellClass = [cell class];
    }
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wobjc-method-access"
    if (cellClass &&
        [cellClass conformsToProtocol:@protocol(ALCollectionViewUnitViewInterface)] &&
        [cellClass respondsToSelector:@selector(sizeForViewModel:inCollectionView:atIndexPath:)]) {
#pragma clang diagnostic pop
        CGSize size = [cellClass sizeForViewModel:unitViewModel inCollectionView:collectionView atIndexPath:indexPath];
        return [NSValue valueWithCGSize:size];
    }
    return nil;
}

- (NSValue *)cellInstanceSizeForViewModel:(ALCollectionCellViewModel *)unitViewModel
                           collectionView:(UICollectionView *)collectionView
                              atIndexPath:(NSIndexPath *)indexPath
{
    NSString *reuseId = unitViewModel.reuseIdentifier;
    UICollectionViewCell *cell = [self templateCellForReuseId:reuseId collectionView:collectionView];
    if ([cell conformsToProtocol:@protocol(ALCollectionViewUnitViewInterface)] &&
        [cell respondsToSelector:@selector(sizeForViewModel:inCollectionView:atIndexPath:)]) {
        id<ALCollectionViewUnitViewInterface> cachedUnitView = (id<ALCollectionViewUnitViewInterface>)cell;
        CGSize size = [cachedUnitView sizeForViewModel:unitViewModel inCollectionView:collectionView atIndexPath:indexPath];
        return [NSValue valueWithCGSize:size];
    }
    return nil;
}


- (NSValue *)classSizeForSupplementaryViewModel:(ALCollectionSupplementaryViewModel *)unitViewModel
                                 collectionView:(UICollectionView *)collectionView
                                    atIndexPath:(NSIndexPath *)indexPath
{
    NSString *reuseId = unitViewModel.reuseIdentifier;
    NSString *kind = unitViewModel.viewKind;
    if (!reuseId || !collectionView) {
        return nil;
    }
    NSString *key = [self.class keyForViewKind:kind reuseId:reuseId];
    Class<ALCollectionViewUnitViewInterface, NSObject> cellClass = [self.class viewClassForKey:key collectionView:collectionView];
    if (!cellClass) {
        UICollectionViewCell *cell = [self.templateViewCache objectForKey:reuseId];
        if (!cell) {
            UINib *nib = [self.class viewNibForKey:key collectionView:collectionView];
            if (nib) {
                cell = [nib instantiateWithOwner:nil options:nil].firstObject;
                if (cell) {
                    [self.templateViewCache setObject:cell forKey:key cost:1];
                }
            }
        }
        cellClass = [cell class];
    }
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wobjc-method-access"
    if (cellClass &&
        [cellClass conformsToProtocol:@protocol(ALCollectionViewUnitViewInterface)] &&
        [cellClass respondsToSelector:@selector(sizeForViewModel:inCollectionView:atIndexPath:)]) {
#pragma clang diagnostic pop
        CGSize size = [cellClass sizeForViewModel:unitViewModel inCollectionView:collectionView atIndexPath:indexPath];
        return [NSValue valueWithCGSize:size];
    }

    return nil;
}

- (NSValue *)instanceSizeForSupplementaryViewModel:(ALCollectionSupplementaryViewModel *)unitViewModel
                                    collectionView:(UICollectionView *)collectionView
                                       atIndexPath:(NSIndexPath *)indexPath
{
    NSString *reuseId = unitViewModel.reuseIdentifier;
    NSString *kind = unitViewModel.viewKind;
    UICollectionReusableView *view = [self templateSupplementaryViewForReuseId:reuseId viewKinkd:kind collectionView:collectionView];
    
    if ([view conformsToProtocol:@protocol(ALCollectionViewUnitViewInterface)] &&
        [view respondsToSelector:@selector(sizeForViewModel:inCollectionView:atIndexPath:)]) {
        id<ALCollectionViewUnitViewInterface> cachedUnitView = (id<ALCollectionViewUnitViewInterface>)view;
        CGSize size = [cachedUnitView sizeForViewModel:unitViewModel inCollectionView:collectionView atIndexPath:indexPath];
        return [NSValue valueWithCGSize:size];
    }
    return nil;
}

#pragma mark UICollectionViewDelegateFlowLayout

////////////////////// UICollectionViewDelegateFlowLayout /////////////////////
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewFlowLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    ALCollectionCellViewModel *unitViewModel =  [self.dataSource itemAtIndexPath:indexPath];
    
    NSValue *itemSize = [self cellClassSizeForViewModel:unitViewModel collectionView:collectionView atIndexPath:indexPath];
    if (itemSize) {
        return itemSize.CGSizeValue;
    }
    
    itemSize = [self cellInstanceSizeForViewModel:unitViewModel collectionView:collectionView atIndexPath:indexPath];
    if (itemSize) {
        return itemSize.CGSizeValue;
    }
    
    CGSize vsize = collectionViewLayout.itemSize;
    return vsize;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewFlowLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)sectionIndex
{
    CGSize vsize = [super collectionView:collectionView layout:collectionViewLayout referenceSizeForHeaderInSection:sectionIndex];
    ALCollectionSupplementaryViewModel *unitViewModel = nil;
    ALCollectionViewSection *section = [[self dataSource] sectionAtIndex:sectionIndex];
    unitViewModel = (ALCollectionSupplementaryViewModel *)section.header;
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:0 inSection:sectionIndex];
    if (unitViewModel) {
        NSValue *itemSize = [self classSizeForSupplementaryViewModel:unitViewModel collectionView:collectionView atIndexPath:indexPath];
        if (itemSize) {
            return itemSize.CGSizeValue;
        }
        
        itemSize = [self instanceSizeForSupplementaryViewModel:unitViewModel collectionView:collectionView atIndexPath:indexPath];
        if (itemSize) {
            return itemSize.CGSizeValue;
        }
    }
    return vsize;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewFlowLayout *)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)sectionIndex
{
    CGSize vsize = [super collectionView:collectionView layout:collectionViewLayout referenceSizeForFooterInSection:sectionIndex];
    ALCollectionSupplementaryViewModel *unitViewModel = nil;
    ALCollectionViewSection *section = [[self dataSource] sectionAtIndex:sectionIndex];
    unitViewModel = (ALCollectionSupplementaryViewModel *)section.footer;
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:0 inSection:sectionIndex];
    if (unitViewModel) {
        NSValue *itemSize = [self classSizeForSupplementaryViewModel:unitViewModel collectionView:collectionView atIndexPath:indexPath];
        if (itemSize) {
            return itemSize.CGSizeValue;
        }
        
        itemSize = [self instanceSizeForSupplementaryViewModel:unitViewModel collectionView:collectionView atIndexPath:indexPath];
        if (itemSize) {
            return itemSize.CGSizeValue;
        }
    }
    return vsize;
}

@end

