//
//  ALCollectionViewDelegate.h
//  ALJetLibrary
//
//  Created by Albert Tian on 14-1-19.
//
//

#import <Foundation/Foundation.h>
#import "ALCollectionViewCell.h"
#import "ALCollectionViewDataSource.h"

/**
 *	@brief	implement UICollectionViewDelegateFlowLayout, fixed cell size.
 */
@interface ALCollectionViewDelegate : NSObject <ALCollectionUnitViewUserActionDelegate>

@property (nonatomic, weak) UICollectionView *collectionView;
@property (nonatomic, strong) ALCollectionViewDataSource *dataSource;

- (instancetype)initWithCollectionView:(UICollectionView *)collectionView
                            dataSource:(ALCollectionViewDataSource *)dataSource;

- (void)connect;

/**
 *  把没有处理的代理方法转发给target。
 *  如果需要转发scrollViewDidScroll:，必须要在调用connect之前设置forwardTo:
 *
 *  @param forwardingTarget
 *
 *  @return self
 */
- (instancetype)forwardTo:(id)forwardingTarget;

@end

@interface ALCollectionViewDelegate (DataSource) <UICollectionViewDataSource>

@end

@interface ALCollectionViewDelegate (Delegate) <UICollectionViewDelegate>

@end

