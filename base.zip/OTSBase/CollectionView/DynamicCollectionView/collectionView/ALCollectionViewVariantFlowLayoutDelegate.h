//
//  ALCollectionViewVariantFlowLayoutDelegate.h
//  ALJetLibrary
//
//  Created by tianwangkuan on 7/29/16.
//
//

#import "ALCollectionViewFlowLayoutDelegate.h"

/**
 *	@brief	implement UICollectionViewDelegateFlowLayout: varied cell size, header
 *          size, footer size.
 *          query cell header footer size from view instance.
 */
@interface ALCollectionViewVariantFlowLayoutDelegate : ALCollectionViewFlowLayoutDelegate

@end

