//
//  ALCollectionViews.m
//  ALJetLibrary
//
//  Created by Albert Tian on 15-4-13.
//
//

#import "ALCollectionViewCell.h"
#import "ALCollectionItemViewModel.h"

@implementation UICollectionView (ALFlowLayoutHelper)

- (UIEdgeInsets)al_sectionInsetAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self.delegate respondsToSelector:@selector(collectionView:layout:insetForSectionAtIndex:)]) {
        return [(id<UICollectionViewDelegateFlowLayout>)self.delegate collectionView:self
                                                                              layout:self.collectionViewLayout
                                                              insetForSectionAtIndex:indexPath.section];
    }
    if ([self.collectionViewLayout respondsToSelector:@selector(sectionInset)]) {
        return [(UICollectionViewFlowLayout *)self.collectionViewLayout sectionInset];
    }
    return UIEdgeInsetsZero;
}

- (CGFloat)al_sectionWidthAtIndexPath:(NSIndexPath *)indexPath
{
    UIEdgeInsets insets = [self al_sectionInsetAtIndexPath:indexPath];
    CGFloat width = self.bounds.size.width - insets.left - insets.right;
    return width;
}

@end


@implementation ALCollectionViewCell

- (void)prepareForReuse
{
    [super prepareForReuse];
    self.viewModel = nil;
    self.indexPathCached = nil;
}

- (void)updateViewModel:(ALCollectionItemViewModel *)unitViewModel atIndexPath:(NSIndexPath *)indexPath
{
    self.viewModel = unitViewModel;
    self.indexPathCached = indexPath;
}

- (void)sendAction:(NSString *)actionKey userInfo:(NSDictionary *)userInfo
{
    [self sendAction:actionKey userInfo:userInfo onCompletion:nil];
}
- (void)sendAction:(NSString *)actionKey userInfo:(NSDictionary *)userInfo onCompletion:(void (^)(id))completion
{
    if (self.userActionDelegate) {
        [self.userActionDelegate handleAction:actionKey unitView:self viewModel:self.viewModel userInfo:userInfo atIndexPath:self.indexPathCached onCompletion:completion];
    }
}

@end

@implementation ALCollectionReusableView

- (void)prepareForReuse
{
    [super prepareForReuse];
    self.viewModel = nil;
    self.indexPathCached = nil;
}

- (void)updateViewModel:(ALCollectionItemViewModel *)unitViewModel atIndexPath:(NSIndexPath *)indexPath
{
    self.viewModel = unitViewModel;
    self.indexPathCached = indexPath;
}

- (void)sendAction:(NSString *)actionKey userInfo:(NSDictionary *)userInfo
{
    [self sendAction:actionKey userInfo:userInfo onCompletion:nil];
}
- (void)sendAction:(NSString *)actionKey userInfo:(NSDictionary *)userInfo onCompletion:(void (^)(id))completion
{
    if (self.userActionDelegate) {
        [self.userActionDelegate handleAction:actionKey unitView:self viewModel:self.viewModel userInfo:userInfo atIndexPath:self.indexPathCached onCompletion:completion];
    }
}

@end

