//
//  ALCollectionViews.h
//  ALJetLibrary
//
//  Created by Albert Tian on 15-4-13.
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "ALCollectionViewProtocols.h"

@class ALCollectionItemViewModel;

@interface UICollectionView (ALFlowLayoutHelper)

- (CGFloat)al_sectionWidthAtIndexPath:(NSIndexPath *)indexPath;

- (UIEdgeInsets)al_sectionInsetAtIndexPath:(NSIndexPath *)indexPath;

@end

@interface ALCollectionViewCell : UICollectionViewCell <ALCollectionViewUnitViewInterface>

@property (nonatomic, strong) ALCollectionItemViewModel *viewModel;
@property (nonatomic, weak) id<ALCollectionUnitViewUserActionDelegate> userActionDelegate;

// cached values, reset when prepareForReuse.
@property (nonatomic, strong) NSIndexPath *indexPathCached;

- (void)updateViewModel:(ALCollectionItemViewModel *)unitViewModel
            atIndexPath:(NSIndexPath *)indexPath;

- (void)sendAction:(NSString *)actionKey userInfo:(NSDictionary *)userInfo;
- (void)sendAction:(NSString *)actionKey userInfo:(NSDictionary *)userInfo onCompletion:(void (^)(id))completion;

@end

@interface ALCollectionReusableView : UICollectionReusableView <ALCollectionViewUnitViewInterface>

@property (nonatomic, strong) ALCollectionItemViewModel *viewModel;
@property (nonatomic, weak) id<ALCollectionUnitViewUserActionDelegate> userActionDelegate;

// cached values, reset when prepareForReuse.
@property (nonatomic, strong) NSIndexPath *indexPathCached;

- (void)updateViewModel:(ALCollectionItemViewModel *)unitViewModel
            atIndexPath:(NSIndexPath *)indexPath;

- (void)sendAction:(NSString *)actionKey userInfo:(NSDictionary *)userInfo;
- (void)sendAction:(NSString *)actionKey userInfo:(NSDictionary *)userInfo onCompletion:(void (^)(id))completion;

@end


