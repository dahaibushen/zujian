//
//  ALCollectionViewFlowLayoutDelegate.h
//  ALJetLibrary
//
//  Created by Albert Tian on 14-7-2.
//
//

#import "ALCollectionViewDelegate.h"

/**
 *	@brief	implement UICollectionViewDelegateFlowLayout:
 *          varied section size, line spacing, item spacing, header size, footer size
 *          specifyed from ALCollectionViewFlowLayoutedSection.
 *          if size is not setted, the default size of UICollectionViewFlowLayout is used.
 */
@interface ALCollectionViewFlowLayoutDelegate : ALCollectionViewDelegate <UICollectionViewDelegateFlowLayout>

@end

