//
//  ALCollectionViewFlowLayoutDelegate.m
//  ALJetLibrary
//
//  Created by Albert Tian on 14-7-2.
//
//

#import "ALCollectionViewFlowLayoutDelegate.h"
#import "ALCollectionViewFlowDataSource.h"

@implementation ALCollectionViewFlowLayoutDelegate

- (ALCollectionViewFlowSection *)flowLayoutedSectionAtSectionIndex:(NSInteger)sectionIndex
{
    id section = [self.dataSource sectionAtIndex:sectionIndex];
    if ([section isKindOfClass:ALCollectionViewFlowSection.class]) {
        return (ALCollectionViewFlowSection *)section;
    }
    return nil;
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    ALCollectionViewFlowSection *unitSection = [self flowLayoutedSectionAtSectionIndex:section];
    if (unitSection) {
        NSValue *insets = [unitSection sectionInset];
        if (insets) {
            return insets.UIEdgeInsetsValue;
        }
    }
    UICollectionViewFlowLayout *flowLayout = (UICollectionViewFlowLayout *)collectionViewLayout;
    return flowLayout.sectionInset;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section
{
    ALCollectionViewFlowSection *unitSection = [self flowLayoutedSectionAtSectionIndex:section];
    if (unitSection) {
        NSNumber *spacing = [unitSection minimumInteritemSpacing];
        if (spacing != nil) {
            return spacing.floatValue;
        }
    }
    UICollectionViewFlowLayout *flowLayout = (UICollectionViewFlowLayout *)collectionViewLayout;
    return flowLayout.minimumInteritemSpacing;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section
{
    ALCollectionViewFlowSection *unitSection = [self flowLayoutedSectionAtSectionIndex:section];
    if (unitSection) {
        NSNumber *spacing = [unitSection minimumLineSpacing];
        if (spacing != nil) {
            return spacing.floatValue;
        }
    }
    UICollectionViewFlowLayout *flowLayout = (UICollectionViewFlowLayout *)collectionViewLayout;
    return flowLayout.minimumLineSpacing;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section
{
    ALCollectionViewFlowSection *unitSection = [self flowLayoutedSectionAtSectionIndex:section];
    if (unitSection) {
        NSValue *size = [unitSection footerReferenceSize];
        if (size) {
            return size.CGSizeValue;
        }
    }
    UICollectionViewFlowLayout *flowLayout = (UICollectionViewFlowLayout *)collectionViewLayout;
    return flowLayout.headerReferenceSize;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section
{
    ALCollectionViewFlowSection *unitSection = [self flowLayoutedSectionAtSectionIndex:section];
    if (unitSection) {
        NSValue *size = [unitSection headerReferenceSize];
        if (size) {
            return size.CGSizeValue;
        }
    }
    UICollectionViewFlowLayout *flowLayout = (UICollectionViewFlowLayout *)collectionViewLayout;
    return flowLayout.footerReferenceSize;
}

@end

