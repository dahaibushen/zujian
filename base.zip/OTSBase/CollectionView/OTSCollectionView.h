//
//  OTSCollectionView.h
//  OneStoreFramework
//
//  Created by Aimy on 14-7-2.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OTSCollectionView : UICollectionView

@end
