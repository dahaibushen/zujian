//
//  OTSCollectionViewLeftAlignedLayout.h
//  OneStoreBase
//
//  Created by superair on 16/5/9.
//  Copyright © 2016年 OneStoreBase. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OTSCollectionViewLeftAlignedLayout :UICollectionViewFlowLayout

@end
