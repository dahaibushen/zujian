//
//  NSNumber+Format.m
//  OneStoreFramework
//
//  Created by airspuer on 14-9-22.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "NSNumber+Format.h"
#import <OTSCore/NSString+plus.h>
#import <OTSCore/OTSCore.h>

@implementation NSNumber (Format)

- (NSString *)moneyFormatString {
    NSString *priceString = [NSString stringWithFormat:@"¥%.2f", self.floatValue];
    NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
    if ([endChar isEqualToString:@"0"]) {
        priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
    }
    return priceString;
}

- (NSString *)moneyFormatStringWithoutZero {
    NSString *priceString = [NSString stringWithFormat:@"¥%.2f", self.floatValue];
    NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
    if ([endChar isEqualToString:@"0"]) {
        priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
        endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
        if ([endChar isEqualToString:@"0"]) {
            priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 2)];
        }
    }
    return priceString;
}

+ (NSString *)moneyFormat:(double)aValue {
    NSString *priceString = [NSString stringWithFormat:@"¥%.2f", aValue];
    NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
    if ([endChar isEqualToString:@"0"]) {
        priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
    }
    return priceString;
}

+ (NSString *)valueFormat:(double)aValue {
    NSString *priceString = [NSString stringWithFormat:@"%.2f", aValue];
    NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
    if ([endChar isEqualToString:@"0"]) {
        priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
        NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
        if ([endChar isEqualToString:@"0"]) {
            priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
            NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
            if ([endChar isEqualToString:@"."]) {
                priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
            }
        }
    }
    return priceString;
}


+ (NSString *)weightFormat:(double)aValue {
    NSString *priceString = [NSString stringWithFormat:@"%.3f", aValue];
    NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
    if ([endChar isEqualToString:@"0"]) {
        priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
        NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
        if ([endChar isEqualToString:@"0"]) {
            priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
            NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
            if ([endChar isEqualToString:@"0"]) {
                priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
                NSString *endChar = [priceString safeSubstringWithRange:NSMakeRange(priceString.length - 1, 1)];
                if ([endChar isEqualToString:@"."]) {
                    priceString = [priceString safeSubstringWithRange:NSMakeRange(0, priceString.length - 1)];
                }
            }
        }
    }
    return priceString;
}

+ (NSAttributedString *)attStringWithTailStr:(NSString *)aTailStr
                                       price:(CGFloat)aPrice
                                       point:(NSInteger)aPoint
                                    joinChar:(NSString *)aChar
                             priceAttributes:(NSDictionary *)aAttributes
                             pointAttributes:(NSDictionary *)bAttributes
                              charAttributes:(NSDictionary *)cAttributes
                       reducePriceAttributes:(NSDictionary *)dAttributes {
    if (aPoint <= 0) {
        NSString *compStr = [NSNumber moneyFormat:aPrice];

        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@%@", compStr, aTailStr]];
        [attributedString setAttributes:aAttributes range:NSMakeRange(0, compStr.length)];
        [attributedString setAttributes:dAttributes range:NSMakeRange(compStr.length, aTailStr.length)];
        return attributedString;
    } else if (aPrice <= 0.0) {
        NSString *compStr = [NSString stringWithFormat:@"%zd 积分", aPoint];

        return [compStr attributedStringWithHeadAttributes:bAttributes tailAttributes:cAttributes tailLength:3];
    } else {
        NSString *compStr = [NSString stringWithFormat:@"%@%@%zd 积分", [NSNumber moneyFormat:aPrice], aChar, aPoint];

        NSRange addRange = [compStr safeRangeOfString:aChar];//连接符range
        NSRange pointRange = [compStr safeRangeOfString:@" 积分"];//积分range

        NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:compStr];
        [attributedString setAttributes:aAttributes range:NSMakeRange(0, addRange.location)];
        [attributedString setAttributes:cAttributes range:addRange];
        [attributedString setAttributes:bAttributes range:NSMakeRange(addRange.location + addRange.length, pointRange.location - addRange.location - addRange.length)];
        [attributedString setAttributes:cAttributes range:pointRange];
        return attributedString;
    }
}

@end
