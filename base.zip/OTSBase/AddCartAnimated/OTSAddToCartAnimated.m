//
//  OTSAddToCartAnimated.m
//  OneStoreFramework
//
//  Created by airspuer on 14-10-20.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSAddToCartAnimated.h"
#import <OTSCore/OTSCore.h>

@implementation OTSAddToCartAnimated

/**
 *	商品加入购物车的动画效果
 *
 *	@param aProductImageView:商品图片
 *	@param aTargetView       :商品图片所在的目标视图。动画以这个视图为基准
 */
+ (void)animateWithProductImageView:(UIImageView *)aProductImageView targetView:(UIView *)aTargetView
{
	[self animateWithProductImageView:aProductImageView targetView:aTargetView aniamteType:OTSAddToCartAnimatedRightBottomType];
}

/**
 *  商品加入购物车的动画效果.根据OTSAddToCartAnimatedType的不同，动画的结束位置不同
 *
 *	@param aProductImageView:商品图片
 *	@param aTargetView       :商品图片所在的目标视图。动画以这个视图为基准
 *	@param aType:动画类型
 */
+ (void)animateWithProductImageView:(UIImageView *)aProductImageView
						 targetView:(UIView *)aTargetView
						aniamteType:(OTSAddToCartAnimatedType )aType
{
	if (!aProductImageView || !aTargetView) {
		return;
	}
    
    UIImageView *copyImageView = [[UIImageView alloc] initWithImage:aProductImageView.image];
    [aTargetView addSubview:copyImageView];
    [aTargetView bringSubviewToFront:copyImageView];
    
    CGPoint imageViewCenter = [aProductImageView convertPoint:aProductImageView.center toView:aTargetView];
    copyImageView.width = aProductImageView.width / 2.0f;
    copyImageView.height = aProductImageView.height / 2.0f;
    copyImageView.center = imageViewCenter;
    
    [UIView animateWithDuration:0.5 animations:^{
        copyImageView.width /= 2.0f;
        copyImageView.height /= 2.0f;
        switch (aType) {
            case OTSAddToCartAnimatedLeftTopType:
                copyImageView.left = 10;
                copyImageView.top = 0;
                break;
            case OTSAddToCartAnimatedRightTopType:
                copyImageView.right = aTargetView.width - 10;
                copyImageView.top = 0;
                break;
            case OTSAddToCartAnimatedLeftBottomType:
                copyImageView.left = 10;
                copyImageView.bottom = aTargetView.height;
                break;
            case OTSAddToCartAnimatedRightBottomType:
                copyImageView.right = aTargetView.width - 20;
                copyImageView.bottom = aTargetView.height - 20;
                break;
            case OTSAddToCartAnimatedTabbarRightBottomType:
                copyImageView.right = aTargetView.width - 20;
                copyImageView.bottom = aTargetView.height - 69;
                break;
            case OTSAddToCartAnimatedNavigationbarRightTopType:
                copyImageView.right = aTargetView.width - 45;
                copyImageView.bottom = 50;
                break;
            case OTSAddToCartAnimatedTabbarCartType:
                copyImageView.right = aTargetView.width * 0.8-10;
                copyImageView.bottom = aTargetView.height - 20;
                break;
            default:
                break;
        }
    } completion:^(BOOL finished) {
        [copyImageView removeFromSuperview];
    }];
}

@end
