//
//  OTSAddToCartAnimated.h
//  OneStoreFramework
//
//  Created by airspuer on 14-10-20.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>
/**
 *	动画类型，动画的结束位置
 */
typedef NS_ENUM(NSInteger, OTSAddToCartAnimatedType) {
	OTSAddToCartAnimatedLeftTopType = 1,//左上角
	OTSAddToCartAnimatedRightTopType = 2,//右上角
	OTSAddToCartAnimatedLeftBottomType = 3,//左下角
	OTSAddToCartAnimatedRightBottomType = 4,//右下角
    OTSAddToCartAnimatedTabbarRightBottomType = 5,//有tabbar的右下角,比如剁手价
    OTSAddToCartAnimatedNavigationbarRightTopType = 6,//navigationBar上,比如1号抢购
    OTSAddToCartAnimatedTabbarCartType = 7,//tabbar上的购物车
};

@interface OTSAddToCartAnimated : NSObject

/**
 *	商品加入购物车的动画效果.默认的结束位置是右下角
 *
 *	@param aProductImageView :商品图片
 *	@param aTargetView       :商品图片所在的目标视图。动画以这个视图为基准
 */
+ (void)animateWithProductImageView:(UIImageView *)aProductImageView targetView:(UIView *)aTargetView;

/**
 *  商品加入购物车的动画效果.根据OTSAddToCartAnimatedType的不同，动画的结束位置不同
 *
 *	@param aProductImageView :商品图片
 *	@param aTargetView       :商品图片所在的目标视图。动画以这个视图为基准
 *	@param aType             :动画类型
 */
+ (void)animateWithProductImageView:(UIImageView *)aProductImageView
						 targetView:(UIView *)aTargetView
						aniamteType:(OTSAddToCartAnimatedType )aType;

@end
