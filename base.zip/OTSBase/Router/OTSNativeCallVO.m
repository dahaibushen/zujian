//
//  OTSNativeCallVO.m
//  OTSBase
//
//  Created by liuwei7 on 2017/8/16.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "OTSNativeCallVO.h"

@implementation OTSNativeCallVO

@end
