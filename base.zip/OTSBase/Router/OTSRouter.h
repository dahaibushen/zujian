//
//  OTSRouter.h
//  OneStoreFramework
//
//  Created by Aimy on 14-6-23.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OTSNativeCallVO.h"
#import "YHDAppDelegate.h"


FOUNDATION_EXTERN NSString const *OTSRouterCallbackKey;
FOUNDATION_EXTERN NSString const *OTSRouterParamKey;

FOUNDATION_EXTERN NSString const *OTSRouterFromHostKey;
FOUNDATION_EXTERN NSString const *OTSRouterFromSchemeKey;

@class OTSRouteVO;

@interface OTSRouter : NSObject

+ (instancetype)sharedInstance;

@property(nonatomic, readonly, strong) YHDAppDelegate *appDelegate;//[UIApplication sharedApplication].delegate
@property(nonatomic, readonly, strong) UITabBarController *rootTBC;
@property(nonatomic, readonly, strong) UINavigationController *currentNC;

@property(nonatomic, readonly, strong) NSString *routeScheme;
@property(nonatomic, readonly, strong) NSString *nativeCallScheme;

- (NSDictionary *)routerMappingInfo;

- (NSDictionary *)nativeCallMappingInfo;

@end

@interface OTSRouter (registery)

- (void)registerRouterVO:(OTSRouteVO *)aVO withKey:(NSString *)key;

- (void)registerNativeCallVO:(OTSNativeCallVO *)aVO withKey:(NSString *)key;

@end

#pragma mark - route

@interface OTSRouter (route)

#pragma mark - route with key

- (void)routeWithKey:(NSString *)key;

- (void)routeWithKey:(NSString *)key params:(NSDictionary *)params;

- (void)routeWithKey:(NSString *)key params:(NSDictionary *)params callback:(OTSNativeCallVOBlock)callback;

#pragma mark - route with URL string

- (void)routeWithURLString:(NSString *)aURLString;

- (void)routeWithURLString:(NSString *)aURLString params:(NSDictionary *)params;

- (void)routeWithURLString:(NSString *)aURLString callback:(OTSNativeCallVOBlock)callback;

- (void)routeWithURLString:(NSString *)aURLString params:(NSDictionary *)params callback:(OTSNativeCallVOBlock)callback;

#pragma mark - route with URL

- (void)routeWithURL:(NSURL *)aURL;

- (void)routeWithURL:(NSURL *)aURL callback:(OTSNativeCallVOBlock)callback;

@end

#pragma mark - Convenience Route

@interface OTSRouter (Convenience)

- (void)routeToLogin;// 调起登录
- (void)routeToHomePage;// 进入首页
- (void)routeBack;

@end

#pragma mark - native call

@interface OTSRouter (NativeCall)

- (void)nativeCallWithKey:(NSString *)key;

- (void)nativeCallWithKey:(NSString *)key params:(id)params;

- (void)nativeCallWithKey:(NSString *)key params:(id)params callback:(OTSNativeCallVOBlock)callback;

@end

@interface OTSRouter (URL)

- (NSString *)urlStringForRouteKey:(NSString *)key andParams:(NSDictionary *)params;

- (NSDictionary *)getBodyParamsFromJsonString:(NSString *)aJsonString;

@end
