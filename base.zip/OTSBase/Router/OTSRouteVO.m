//
//  OTSRouteVO.m
//  OTSBase
//
//  Created by liuwei7 on 2017/8/16.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "OTSRouteVO.h"
#import "UIViewController+router.h"

@implementation OTSRouteVO

- (instancetype)init {
    if (self = [super init]) {
        self.createdType = OTSRouteObjectCreateByCode;
        self.platformType = OTSRoutePlatformTypeUniversal;
        self.animated = YES;
    }

    return self;
}

- (UIViewController *)generateVCWithExtraData:(NSDictionary *)extraData {
    if (!self.className) {
        return nil;
    }

    Class class = NSClassFromString(self.className);
    if (!class) {
        return nil;
    }

    UIViewController *vc = nil;
    if (self.createdType == OTSRouteObjectCreateByCode) {
        vc = [[class alloc] initWithNibName:nil bundle:nil];
    } else if (self.createdType == OTSRouteObjectCreateByXib) {
        vc = [[class alloc] initWithNibName:self.className bundle:[NSBundle mainBundle]];
    }

    NSDictionary *theExtraData = extraData ?: @{};
    vc.extraData = theExtraData;

    return vc;
}

@end
