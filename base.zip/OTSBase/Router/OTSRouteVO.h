//
//  OTSRouteVO.h
//  OTSBase
//
//  Created by liuwei7 on 2017/8/16.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, OTSRouteObjectCreateType) {
    OTSRouteObjectCreateByCode = 0,//编码方式创建，默认
    OTSRouteObjectCreateByXib = 1//xib方式创建
};

typedef NS_ENUM(NSUInteger, OTSRoutePlatformType) {
    OTSRoutePlatformTypePhone = 0,//只支持iPhone
    OTSRoutePlatformTypePad = 1,//只支持iPad
    OTSRoutePlatformTypeUniversal = 2,//任何平台都支持，默认
};

@interface OTSRouteVO : NSObject

@property (nonatomic, copy) NSString *key;

@property(nonatomic, copy) NSString *className;//创建的类名

@property(assign, nonatomic) OTSRouteObjectCreateType createdType;//创建的方式

@property(assign, nonatomic) OTSRoutePlatformType platformType;//支持的 platform

@property(assign, nonatomic) BOOL needLogin;//是否需要登录

@property (nonatomic, assign, getter=isTab) BOOL tab;
@property (nonatomic, assign) NSUInteger index;

/*
 ** 页面切换时是否做动画，默认为 YES
 ** 也可以从URL的qury string中传入，或 router 的 params 参数传入，这两种方式会覆盖VO中的值
 ** @sample
 ** [[OTSRouter sharedInstance] routeWithKey:@"sample" params:@{@"isAnimated":@(NO)}];
 ** 或
 ** [[OTSRouter sharedInstance] routeWithURLString:@"yhd://sample?isAnimated=0"];
*/
@property (nonatomic, getter=isAnimated, assign) NSInteger animated;

- (UIViewController *)generateVCWithExtraData:(NSDictionary *)extraData;

@end
