# Router 文档
Router 是App的核心功能

## Router 职责
Router主要主要有两个职责：
- 跳转页面
    - Native 页面，scheme 为 yhd
    - H5 页面，scheme 为 http(s)
- 执行功能

## Router 设计
### Router 注册
### Router 跳转
