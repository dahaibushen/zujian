//
//  OTSRouter.m
//  OneStoreFramework
//
//  Created by Aimy on 14-6-23.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSRouter.h"
#import "UIViewController+base.h"
#import <OTSCore/OTSCore.h>
#import "OTSRouteVO.h"

NSString const *OTSRouterCallbackKey = @"routercallback";
NSString const *OTSRouterParamKey = @"body";

NSString const *OTSRouterFromHostKey = @"OTSRouterFromHostKey";
NSString const *OTSRouterFromSchemeKey = @"OTSRouterFromSchemeKey";

@interface OTSRouter ()

@property(atomic, strong) NSMutableDictionary *routeMapping;
@property(atomic, strong) NSMutableDictionary *nativeCallMapping;

@property(nonatomic, strong) NSString *routeScheme;
@property(nonatomic, strong) NSString *nativeCallScheme;

@end

@interface OTSRouter (Internal)

- (void)p_routeWithRouteVO:(OTSRouteVO *)aVO params:(NSDictionary *)aParams;

- (void)p_dismissAllPC;

@end

@implementation OTSRouter

- (NSDictionary *)routerMappingInfo {
    return [self.routeMapping copy];
}

- (NSDictionary *)nativeCallMappingInfo {
    return [self.nativeCallMapping copy];
}

+ (instancetype)sharedInstance {
    static OTSRouter *router = nil;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        router = [OTSRouter new];
    });

    return router;
}

- (instancetype)init {
    if (self = [super init]) {
        self.routeMapping = [NSMutableDictionary dictionary];
        self.nativeCallMapping = [NSMutableDictionary dictionary];
        self.routeScheme = @"yhd";
        self.nativeCallScheme = @"yhdiosfun";
    }

    return self;
}

- (YHDAppDelegate *)appDelegate {
    return (YHDAppDelegate *) [UIApplication sharedApplication].delegate;
}

- (UITabBarController *)rootTBC {
    return (UITabBarController *) self.appDelegate.window.rootViewController;
}

- (UINavigationController *)currentNC {
    return self.rootTBC.selectedViewController;
}

@end

#pragma mark - registery

@implementation OTSRouter (registery)

- (void)registerRouterVO:(OTSRouteVO *)aVO withKey:(NSString *)key {
    NSParameterAssert(aVO);
    NSParameterAssert(key);
    if (aVO && key && !self.routeMapping[key]) {
        aVO.key = key;
        self.routeMapping[key] = aVO;
    }
}

- (void)registerNativeCallVO:(OTSNativeCallVO *)aVO withKey:(NSString *)key {
    NSParameterAssert(aVO);
    NSParameterAssert(key);
    if (aVO && key && !self.nativeCallMapping[key]) {
        self.nativeCallMapping[key] = aVO;
    }
}

@end

#pragma mark - route

@implementation OTSRouter (route)

#pragma mark route with host

- (void)routeWithKey:(NSString *)key {
    NSParameterAssert(key);
    [self routeWithKey:key params:nil callback:nil];
}

- (void)routeWithKey:(NSString *)key params:(NSDictionary *)params {
    NSParameterAssert(key);
    [self routeWithKey:key params:params callback:nil];
}

- (void)routeWithKey:(NSString *)key params:(NSDictionary *)params callback:(OTSNativeCallVOBlock)callback {
    NSParameterAssert(key);
    NSMutableDictionary *mParams = params.mutableCopy ?: @{}.mutableCopy;
    mParams[OTSRouterFromHostKey] = key;
    mParams[OTSRouterFromSchemeKey] = self.routeScheme;
    if (callback) {
        mParams[OTSRouterCallbackKey] = callback;
    }

    OTSRouteVO *vo = self.routeMapping[key];
    [self p_routeWithRouteVO:vo params:[NSDictionary dictionaryWithDictionary:mParams]];
}

#pragma mark - Router with URL string

- (void)routeWithURLString:(NSString *)aURLString {
    NSParameterAssert(aURLString);
    [self routeWithURLString:aURLString callback:nil];
}

- (void)routeWithURLString:(NSString *)aURLString callback:(OTSNativeCallVOBlock)callback {
    NSParameterAssert(aURLString);
    [self routeWithURLString:aURLString params:nil callback:callback];
}

- (void)routeWithURLString:(NSString *)aURLString params:(NSDictionary *)params {
    NSParameterAssert(aURLString);
    [self routeWithURLString:aURLString params:params callback:nil];
}

- (void)routeWithURLString:(NSString *)aURLString params:(NSDictionary *)params callback:(OTSNativeCallVOBlock)callback {
    NSParameterAssert(aURLString);
    NSURL *url = [NSURL URLWithString:aURLString];
    if (!url) {
        url = [NSURL URLWithString:[aURLString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    }
    [self routerWithURL:url params:params callback:callback];
}

#pragma mark Router with URL

- (void)routeWithURL:(NSURL *)aURL {
    NSParameterAssert(aURL);
    [self routeWithURL:aURL callback:nil];
}

- (void)routeWithURL:(NSURL *)aURL callback:(OTSNativeCallVOBlock)callback {
    NSParameterAssert(aURL);
    [self routerWithURL:aURL params:nil callback:callback];
}

- (void)routerWithURL:(NSURL *)aURL params:(NSDictionary *)params callback:(OTSNativeCallVOBlock)callback {
    NSParameterAssert(aURL);
    if (!aURL) {
        return;
    }
    
    NSString *host = aURL.host;
    NSString *scheme = aURL.scheme;
    NSString *query = aURL.query;
    
    NSMutableDictionary *mParams = ((NSDictionary *)([self getBodyParamsFromJsonString:query][OTSRouterParamKey])).mutableCopy ?: @{}.mutableCopy;
    if (params) {
        [mParams addEntriesFromDictionary:params];
    }
    
//    NSURLComponents *urlComponents = [[NSURLComponents alloc] initWithURL:aURL resolvingAgainstBaseURL:NO];
//
//    NSString *scheme = urlComponents.scheme;
//    NSString *host = urlComponents.host;
//    
//    NSMutableDictionary *mParams = params ? params.mutableCopy : @{}.mutableCopy;
//    for (NSURLQueryItem *item  in urlComponents.queryItems) {
//        if (item.name && item.value) {
//            if ([item.name.lowercaseString isEqualToString:@"body"]) {
//                NSDictionary *bodyParams = [OTSJSONUtil dictFromString:item.value];
//                if (bodyParams) {
//                    [mParams addEntriesFromDictionary:bodyParams];
//                }
//            } else {
//                [mParams setObject:item.value forKey:item.name];
//            }
//        }
//    }

    mParams[OTSRouterFromHostKey] = host;
    mParams[OTSRouterFromSchemeKey] = scheme;
    if (callback) {
        mParams[OTSRouterCallbackKey] = callback;
    }

    NSDictionary *iParams = [NSDictionary dictionaryWithDictionary:mParams];

    if ([scheme isEqualToString:self.nativeCallScheme]) {
        [self nativeCallWithKey:host params:iParams callback:callback];
    } else if ([scheme isEqualToString:@"http"] || [scheme isEqualToString:@"https"] || (host && [scheme isEqualToString:self.routeScheme])) {
        OTSRouteVO *routeVO = nil;

        if ([scheme isEqualToString:@"http"] || [scheme isEqualToString:@"https"]) {
            routeVO = self.routeMapping[@"web"];
            
            NSMutableDictionary *mParam = iParams ? [NSMutableDictionary dictionaryWithDictionary:iParams] : [NSMutableDictionary dictionary];
            [mParam setObject:aURL.absoluteString forKey:@"url"];
            iParams = mParam.copy;
        } else if (host && [scheme isEqualToString:self.routeScheme]) {
            routeVO = [self.routeMapping objectForCaseInsensitiveKey:host];
        }

        [self p_routeWithRouteVO:routeVO params:[NSDictionary dictionaryWithDictionary:iParams]];
    } else {
        OTSLog(@"Invalid route URL.");
    }
}

@end

#pragma mark - Convenience

@implementation OTSRouter (Convenience)

- (void)routeToLogin {
    [self routeWithKey:@"login"];
}

- (void)routeToHomePage {
    [self p_dismissAllPC];
    [self.currentNC popToRootViewControllerAnimated:NO];
    if (self.rootTBC.selectedIndex != 0) {
        [self.rootTBC setSelectedIndex:0];
    }
}

- (void)routeBack {
    [self.currentNC popViewControllerAnimated:YES];
}

@end

#pragma mark - NativeCall

@implementation OTSRouter (NativeCall)

- (void)nativeCallWithKey:(NSString *)key {
    NSParameterAssert(key);
    [self nativeCallWithKey:key params:nil callback:nil];
}

- (void)nativeCallWithKey:(NSString *)key params:(NSDictionary *)params {
    NSParameterAssert(key);
    [self nativeCallWithKey:key params:params callback:nil];
}

- (void)nativeCallWithKey:(NSString *)key params:(id)params callback:(OTSNativeCallVOBlock)callback {
    NSParameterAssert(key);
    if (callback) {
        [params addEntriesFromDictionary:@{@"callback": callback}];
    }
    OTSNativeCallVO *nativeCall = self.nativeCallMapping[key];
    if (nativeCall && nativeCall.block) {
        nativeCall.block(params);
    }
}

@end

#pragma mark - Internal

@implementation OTSRouter (Internal)

- (BOOL)p_needLoginFirst
{
    //去除下层（OTSBase）对上层（OTSService）的强依赖，使用反射来调用是否需要登录的接口
    id OTSAccountService = NSClassFromString(@"OTSAccountService");
    id API = nil;
    OTSSuppressPerformSelectorLeakWarning(
        API = [OTSAccountService performSelector:NSSelectorFromString(@"API")];
    );

    NSMethodSignature *signature = [[API class] instanceMethodSignatureForSelector:NSSelectorFromString(@"needLoginFirst")];
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    invocation.target = API;
    invocation.selector = NSSelectorFromString(@"needLoginFirst");
    [invocation invoke];
    BOOL needLoginFirst = NO;
    if (signature.methodReturnLength) {
        [invocation getReturnValue:&needLoginFirst];
    }
    
    return needLoginFirst;
}

/**
 *  功能:route到OTSRouteVO对应的vc
 */
- (void)p_routeWithRouteVO:(OTSRouteVO *)aVO params:(NSDictionary *)params {
    NSParameterAssert(aVO);
    
    if (aVO.isTab && !params[@"push"]) {
        [self p_switchTabAtIndex:aVO.index parameter:params];
        return;
    }
    
    //需要登录，则去登录
    if (aVO.needLogin && [self p_needLoginFirst]) {
        [self routeWithKey:@"login" params:params];
        return;
    }

    UIViewController *vc = [aVO generateVCWithExtraData:params];
    if (!vc || [vc isKindOfClass:[UINavigationController class]]) {
        return;
    }

    //Present PC情况处理
    if ([vc isPc]) {
        if ([[self.appDelegate.modalWindow.rootViewController.childViewControllers lastObject] isKindOfClass:[vc class]] && !vc.isPresented) {
            return;
        } else {
            if (![vc shouldShareScreen]) {
                [self p_dismissAllPC];
            }
            [vc addToRootVC];

            // hard code：之所以延迟0.1秒，是因为需要上面p_dismissAllPC执行完毕之后再present
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t) (0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^(void) {
                [vc presentViewControllerAnimated:YES completion:nil];
            });
            return;
        }
    }

    //隐藏PC
    [self p_dismissAllPC];
    
    if ([params.allKeys containsObject:@"isAnimated"]) {
        id animatedValue = params[@"isAnimated"];
        if ([animatedValue isKindOfClass:NSString.class]) {
            NSString *animatedString = [(NSString *)animatedValue lowercaseString];
            aVO.animated = [@[@"yes", @"true", @"1"] containsObject:animatedString];
        } else if ([animatedValue isKindOfClass:NSNumber.class]){
            aVO.animated = [(NSNumber *)animatedValue boolValue];
        }
    }

    [self.currentNC pushViewController:vc animated:aVO.isAnimated];
}

- (void)p_switchTabAtIndex:(NSUInteger)index parameter:(NSDictionary *)parameter {
    [self p_dismissAllPC];
    [self.currentNC popToRootViewControllerAnimated:NO];
    
    if (self.rootTBC.selectedIndex != index) {
        self.rootTBC.selectedIndex = index;
    }
}

/**
 *  功能:关闭所有pc
 */
- (void)p_dismissAllPC {
    for (UIViewController *childVC in self.appDelegate.modalWindow.rootViewController.childViewControllers) {
        if ([childVC isPc]) {
            [childVC dismissViewControllerAnimated:NO completion:nil];
        }
    }
}

@end

@implementation OTSRouter (URL)

- (NSString *)urlStringForRouteKey:(NSString *)key andParams:(NSDictionary *)params {
    NSParameterAssert(key);

    NSString *urlString = [NSString stringWithFormat:@"%@://%@", self.routeScheme, key];

    NSString *json = [OTSJSONUtil stringFromDict:params];
    if (!json) {
        return urlString;
    }

    NSString *jsonString = [urlString stringByAppendingFormat:@"?%@=%@", OTSRouterParamKey, json];
    jsonString = [jsonString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    return jsonString;
}

- (NSDictionary *)getBodyParamsFromJsonString:(NSString *)aJsonString {
    //urldecode
    NSString *jsonString = [aJsonString stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    NSMutableDictionary *dict = [NSMutableDictionary dictionary];

    NSArray *subStrings = [jsonString componentsSeparatedByString:@"="];
    if ([OTSRouterParamKey isEqualToString:subStrings[0]]) {
        if (subStrings[1]) {
            NSRange endCharRange = [jsonString rangeOfString:@"}" options:NSBackwardsSearch];
            if (endCharRange.location != NSNotFound) {
                jsonString = [jsonString substringToIndex:endCharRange.location + 1];
            }
            NSRange range = [jsonString rangeOfString:@"="];
            //除去body＝剩下纯json格式string
            NSString *jsonStr = [jsonString substringFromIndex:range.location + 1];

            if ([[jsonStr safeSubstringFromIndex:(jsonStr.length - 1)] isEqualToString:@"\""]) { // 去掉末尾"号
                jsonStr = [jsonStr substringToIndex:(jsonStr.length - 1)];
            }

            NSDictionary *resultDict = [OTSJSONUtil dictFromString:jsonStr];
            dict[OTSRouterParamKey] = resultDict;
        }
    }

    [dict.copy enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
        if ([obj isKindOfClass:[NSNumber class]]) {
            dict[key] = [obj stringValue];
        }
    }];

    if (!dict[OTSRouterParamKey] || [dict[OTSRouterParamKey] isEqual:[NSNull null]]) {
        dict[OTSRouterParamKey] = @{};
    }
    return dict;
}

@end
