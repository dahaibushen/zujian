//
//  OTSNativeCallVO.h
//  OTSBase
//
//  Created by liuwei7 on 2017/8/16.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef id (^OTSNativeCallVOBlock)(id param);

@interface OTSNativeCallVO : NSObject

@property(nonatomic, copy) OTSNativeCallVOBlock block;

@end

