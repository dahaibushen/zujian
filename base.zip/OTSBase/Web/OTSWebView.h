//
//  OTSWebView.h
//  OneStoreFramework
//
//  Created by Aimy on 14-6-23.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <OTSCore/YHDWebView.h>

@interface OTSWebView : YHDWebView

/**
 * 种 .yhd.com 域的 Cookies
 */
+ (void)setCookieName:(NSString *)aName value:(NSString *)aValue;

/**
 *  添加默认的cookies
 * 种 .yhd.com 域的 Cookies
 */
+ (void)setupDefaultCookies;

@end
