//
//  OTSWebView.m
//  OneStoreFramework
//
//  Created by Aimy on 14-6-23.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSWebView.h"

#import <OTSCore/NSString+plus.h>
#import "OTSGlobalValue.h"
#import "OTSClientInfo.h"
#import <OTSCore/OTSCore.h>
#import "OTSOperationManager.h"

@implementation OTSWebView

#pragma mark - cookies
+ (void)setCookieName:(NSString *)aName value:(NSString *)aValue {
    [self setCookie:@".yhd.com" name:aName value:aValue];
}

+ (void)setupDefaultCookies {
    /**
     *  token
     */
    [OTSWebView setCookieName:@"usertoken" value:[OTSGlobalValue sharedInstance].token];
    NSDictionary *headerInfo = [OTSOperationManager getGlobalHeaderInfo];
    [headerInfo enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        [OTSWebView setCookieName:key value:obj];
    }];
    /**
     *  sessionid
     */
    [OTSWebView setCookieName:@"sessionid" value:[OTSGlobalValue sharedInstance].sessionId];
    /**
     *  clientinfo
     */
    [OTSWebView setCookieName:@"clientinfo" value:[OTSJSONUtil stringFromDict:[[OTSClientInfo sharedInstance] toDictionary]].urlEncodingAllCharacter];
    /**
     *  frameworkver
     */
    [OTSWebView setCookieName:@"frameworkver" value:@"1.0"];
    /**
     *  platform
     */
    [OTSWebView setCookieName:@"platform" value:@"ios"];
    /**
     *  ut
     */
    [OTSWebView setCookieName:@"ut" value:[OTSGlobalValue sharedInstance].token];
    /**
     *  guid
     */
    [OTSWebView setCookieName:@"guid" value:[OTSClientInfo sharedInstance].deviceCode];
}

- (void)dealloc {
    self.delegate = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)setDelegate:(id <UIWebViewDelegate>)delegate {
    [super setDelegate:delegate];

    if (delegate == nil) {
        return;
    }

    WEAK_SELF;
    [((NSObject*)delegate) willDeallocate].then(^id(id value) {
        STRONG_SELF;
        self.delegate = nil;
        return nil;
    });
}

@end
