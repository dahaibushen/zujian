//
//  OTSContainerController.m
//  OneStorePad
//
//  Created by Aimy on 3/23/15.
//  Copyright (c) 2015 OneStore. All rights reserved.
//

#import "OTSContainerController.h"
#import "OTSRouter.h"

@implementation OTSContainerController

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Overrides

- (BOOL)shouldAutomaticallyForwardAppearanceMethods NS_AVAILABLE_IOS(6_0) {
    return NO;
}

- (BOOL)shouldAutomaticallyForwardRotationMethods NS_AVAILABLE_IOS(6_0) {
    return NO;
}

- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    [super willRotateToInterfaceOrientation:toInterfaceOrientation duration:duration];

    NSArray *viewControllers = [self childViewControllersWithRotationCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController willRotateToInterfaceOrientation:toInterfaceOrientation duration:duration];

    }
}

- (void)willAnimateRotationToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration {
    [super willAnimateRotationToInterfaceOrientation:toInterfaceOrientation duration:duration];

    NSArray *viewControllers = [self childViewControllersWithRotationCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController willAnimateRotationToInterfaceOrientation:toInterfaceOrientation duration:duration];
    }
}

- (void)didRotateFromInterfaceOrientation:(UIInterfaceOrientation)fromInterfaceOrientation {
    [super didRotateFromInterfaceOrientation:fromInterfaceOrientation];

    NSArray *viewControllers = [self childViewControllersWithRotationCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController didRotateFromInterfaceOrientation:fromInterfaceOrientation];
    }
}

- (void)viewWillTransitionToSize:(CGSize)size withTransitionCoordinator:(id <UIViewControllerTransitionCoordinator>)coordinator//for ios8 up
{
    [super viewWillTransitionToSize:size withTransitionCoordinator:coordinator];

    NSArray *viewControllers = [self childViewControllersWithRotationCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController viewWillTransitionToSize:size withTransitionCoordinator:coordinator];
    }
}

- (void)willTransitionToTraitCollection:(UITraitCollection *)newCollection withTransitionCoordinator:(id <UIViewControllerTransitionCoordinator>)coordinator//for ios8 up
{
    [super willTransitionToTraitCollection:newCollection withTransitionCoordinator:coordinator];

    NSArray *viewControllers = [self childViewControllersWithRotationCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController willTransitionToTraitCollection:newCollection withTransitionCoordinator:coordinator];
    }
}

#pragma mark - 下面两个方法是在需要的情况下给基类覆盖用的，不是所有的容器都需要将相关方法传递给所有的childViewControllers

- (NSArray *)childViewControllersWithAppearanceCallbackAutoForward {
    return self.childViewControllers;
}

- (NSArray *)childViewControllersWithRotationCallbackAutoForward {
    return self.childViewControllers;
}

#pragma mark - add

- (void)addToRootVC {
    [self addToContainerVC:[OTSRouter sharedInstance].appDelegate.modalWindow.rootViewController];
}

- (void)addToContainerVC:(UIViewController *)aContainerVC {
    if (self.parentViewController) {
        [self willMoveToParentViewController:nil];
        [self.view removeFromSuperview];
        [self removeFromParentViewController];
    }

    [aContainerVC addChildViewController:self];
    self.view.frame = self.parentViewController.view.bounds;
    [aContainerVC.view addSubview:self.view];

    [aContainerVC.view updateConstraintsIfNeeded];//强制更新约束
    [aContainerVC.view layoutIfNeeded];//强制刷新界面
}

#pragma mark - overwrite

- (void)addChildViewController:(UIViewController *)childController {
    if (!childController) {
        return;
    }

    [super addChildViewController:childController];
    childController.containerVC = self;
}

#pragma mark - child view controllers life cycle methods

- (void)callChildVCsViewWillAppear:(BOOL)animated {
    NSArray *viewControllers = [self childViewControllersWithAppearanceCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController beginAppearanceTransition:YES animated:animated];
    }
}

- (void)callChildVCsViewDidAppear:(BOOL)animated {
    NSArray *viewControllers = [self childViewControllersWithAppearanceCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController endAppearanceTransition];
    }
}

- (void)callChildVCsViewWillDisappear:(BOOL)animated {
    NSArray *viewControllers = [self childViewControllersWithAppearanceCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController beginAppearanceTransition:NO animated:animated];
    }
}

- (void)callChildVCsViewDidDisappear:(BOOL)animated {
    NSArray *viewControllers = [self childViewControllersWithAppearanceCallbackAutoForward];
    for (UIViewController *viewController in viewControllers) {
        [viewController endAppearanceTransition];
    }
}

@end
