//
//  YHDVC.h
//  OTSBase
//
//  Created by liuwei7 on 2017/8/21.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OTSOperationManager.h"

// OTSVC 和 OTSPC 的共有基类

@interface YHDVC : UIViewController

@property(nonatomic, strong) OTSOperationManager *operationManager;


- (void)cancelAllOperations;

@end
