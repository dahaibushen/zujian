//
//  OTSVC.h
//  OneStoreFramework
//
//  Created by Aimy on 14-6-24.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "YHDVC.h"
#import "UIViewController+animation.h"
#import "UIViewController+loading.h"
#import "UIViewController+router.h"
#import "UIViewController+BarButtonItem.h"
#import "OTSOperationManager.h"

#import "HCIModel.h"

@interface OTSVC : YHDVC

@property(nonatomic) BOOL showGlobalMessageTip;//显示全局消息提醒

@property(nonatomic, copy) UIColor *titleColor;//title颜色
@property(nonatomic, copy) NSDictionary *titleTextAttributes;//富文本title，如果设置了则title，titlecolor失效

@property(nonatomic, getter=isNavigationBarHidden) BOOL navigationBarHidden;//是否显示Navigation bar
@property(nonatomic, getter=isToolbarHidden) BOOL toolbarHidden;//是否显示导航栏的toolbar

@property(nonatomic, strong) HCIModel *hciModel;//存放人机识别参数

#pragma mark - BI Property

@property(nonatomic, strong) NSString *pageID;//页面ID
@property(nonatomic, strong) NSMutableDictionary *pageParam;//页面参数
@property(nonatomic, strong) NSString *prePageID;//页面ID
@property(nonatomic, strong) NSMutableDictionary *prePageParam;//页面参数

#pragma mark - Common

- (void)handleServerErrorNotification:(NSNotification *)aNotification;

@end

