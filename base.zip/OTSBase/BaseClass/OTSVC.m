//
//  OTSVC.m
//  OneStoreFramework
//
//  Created by Aimy on 14-6-24.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSVC.h"
#import "OTSReachability.h"
#import "OTSContainerController.h"
#import "OTSGlobalDefine.h"
#import "OTSNC.h"
#import "YHDNotConnectView.h"
#import "YHDServerBusyView.h"
#import "YHDVersionUpdateView.h"
#import "YHDNilView.h"
#import <OTSCore/UIColor+Convenience.h>

@interface OTSVC () <YHDGifViewDelegate>

@end

@implementation OTSVC

+(void)load
{
    OTSNativeCallVO *vo = [[OTSNativeCallVO alloc] init];
    vo.block = ^id(id param) {
        [[OTSRouter sharedInstance] routeBack];
        return nil;
    };
    [[OTSRouter sharedInstance] registerNativeCallVO:vo withKey:@"back"];
    
    vo = [[OTSNativeCallVO alloc] init];
    vo.block = ^id(id param) {
        [[OTSRouter sharedInstance] routeToHomePage];
        return nil;
    };
    [[OTSRouter sharedInstance] registerNativeCallVO:vo withKey:@"home"];
}

- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        [self p_setup];
    }

    return self;
}

- (void)p_setup {
    self.navigationBarHidden = NO;
    self.toolbarHidden = YES;
    self.showGlobalMessageTip = YES;
    self.titleColor = [UIColor colorWithRed:33.0 / 255.0 green:33.0 / 255.0 blue:33.0 / 255.0 alpha:1.0];

    //服务器错误处理
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleServerErrorNotification:) name:OTSNetworkErrorNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleServerErrorNotification:) name:OTSHideNetworkErrorNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(handleServerErrorNotification:) name:OTS_SHOW_VERSION_UPDATE object:self.operationManager];
}

#pragma mark- LifeCyle

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];

    [self.navigationController setToolbarHidden:self.toolbarHidden animated:YES];
    [self.navigationController setNavigationBarHidden:self.navigationBarHidden animated:YES];

    self.navigationController.navigationBar.titleTextAttributes = self.titleTextAttributes ?: @{NSForegroundColorAttributeName: self.titleColor ?: [UIColor lightGrayColor], NSFontAttributeName: [UIFont systemFontOfSize:18.0f]};

    [self updateGlobalMessage];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.navigationController setNavigationBarHidden:NO animated:YES];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    if (!self.view.backgroundColor || [self.view.backgroundColor isEqual:[UIColor clearColor]]) {
        self.view.backgroundColor = [UIColor whiteColor];
    }
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - hciModel

- (HCIModel *)hciModel {
    if (!_hciModel) {
        _hciModel = [[HCIModel alloc] init];
    }

    return _hciModel;
}

#pragma mark - title color

- (void)setTitleColor:(UIColor *)titleColor {
    _titleColor = titleColor;
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: self.titleColor, NSFontAttributeName: [UIFont systemFontOfSize:18.0f]};
}

#pragma mark - navigation

- (void)setNavigationBarHidden:(BOOL)navigationBarHidden {
    _navigationBarHidden = navigationBarHidden;
    if (self.isViewLoaded) {
        [((OTSNC *) self.navigationController) setNavigationBarHidden:_navigationBarHidden animated:YES];
    }
}

- (void)setToolbarHidden:(BOOL)toolbarHidden {
    _toolbarHidden = toolbarHidden;
    if (self.isViewLoaded) {
        [((OTSNC *) self.navigationController) setToolbarHidden:_toolbarHidden animated:YES];
    }
}

#pragma mark - Notification

- (void)handleServerErrorNotification:(NSNotification *)aNotification {
    if ([aNotification.name isEqualToString:OTSNetworkErrorNotification]) {
        if (aNotification.object == self.operationManager) {
            dispatch_async(dispatch_get_main_queue(), ^{
                if ([OTSReachability sharedInstance].currentNetStatus == kConnectToNull) {
                    //显示无网络错误界面
                    [[YHDNotConnectView sharedInstance] showInVC:self delegate:self];
                } else {
                    //缓存出错接口
                    [[YHDServerBusyView sharedInstance] cacheErrorOperationManager:self.operationManager];
                    
                    //显示接口超时错误界面
                    [[YHDServerBusyView sharedInstance] showInVC:self delegate:self];
                }
            });
        }
    } else if ([aNotification.name isEqualToString:OTSHideNetworkErrorNotification]) {
        //隐藏无网络错误界面
        dispatch_async(dispatch_get_main_queue(), ^{
            [[YHDNotConnectView sharedInstance] hide];
        });
    } else if ([aNotification.name isEqualToString:OTS_SHOW_VERSION_UPDATE]) {
        //显示需要版本更新界面
        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            NSString *rtnMsg = aNotification.userInfo[@"rtn_msg"];
            NSString *rtnTip = aNotification.userInfo[@"rtn_tip"];

            [self showVersionUpdateWithFrame:CGRectZero bgColor:rgb(250, 250, 250) tip:rtnTip url:rtnMsg];
        } else {

        }
    }
}

#pragma mark - LoadingView

- (CGRect)frameForLoadingView {
    return CGRectZero;
}

#pragma mark - Error View

- (CGRect)frameForServerBusyView {
    return CGRectZero;
}

- (CGRect)frameForNotConnectView {
    return CGRectZero;
}

- (CGRect)frameForNilView {
    return CGRectZero;
}

#pragma mark - YHDGifViewDelegate

/**
 *  功能:gif view的frame
 */
- (CGRect)frameForYHDGifView:(YHDGifView *)aView {
    if ([aView isKindOfClass:[YHDServerBusyView class]]) {
        return [self frameForServerBusyView];
    } else if ([aView isKindOfClass:[YHDNotConnectView class]]) {
        return [self frameForNotConnectView];
    } else if ([aView isKindOfClass:[YHDNilView class]]) {
        return [self frameForNilView];
    } else if ([aView isKindOfClass:[YHDVersionUpdateView class]]) {
        return [self frameForVersionUpdateView];
    }

    return CGRectZero;
}

/**
 * 功能:点击左按钮返回之前页面
 */
- (void)gifView:(YHDGifView *)aView backBtnClicked:(id)sender {
    [self leftBtnClicked:sender];
}

/**
 *  功能:点击底部按钮
 */
- (void)gifView:(YHDGifView *)aView bottomBtnClicked:(id)sender {
    if ([aView isKindOfClass:[YHDVersionUpdateView class]]) {
        YHDVersionUpdateView *versionUpdateView = (YHDVersionUpdateView *) aView;
        NSString *updateUrl = versionUpdateView.updateUrl;

        //浏览器打开链接
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:updateUrl]];
    } else if ([aView isKindOfClass:[YHDServerBusyView class]]) {
        [[YHDServerBusyView sharedInstance] hide];
    }
}

#pragma mark - Version Update

- (void)showVersionUpdateWithFrame:(CGRect)aFrame bgColor:(UIColor *)aColor tip:(NSString *)aTip url:(NSString *)aUrl {
    [[YHDVersionUpdateView sharedInstance] updateWithTip:aTip url:aUrl];
    if (aColor != nil) {
        [YHDVersionUpdateView sharedInstance].backgroundColor = aColor;
    }

    [[YHDVersionUpdateView sharedInstance] showInVC:self delegate:self];
}

- (CGRect)frameForVersionUpdateView {
    return CGRectZero;
}

#pragma -mark 更新全局消息显示

- (void)updateGlobalMessage {
    [[NSNotificationCenter defaultCenter] postNotificationName:OTS_GLOBAL_CAN_SHOW_MESSAGE object:@(self.showGlobalMessageTip)];
}

- (void)removeFromParentViewController {
    [super removeFromParentViewController];
    self.containerVC = nil;
}

#pragma mark - 替换栈中 VC

#pragma mark BIProperty

- (NSString *)pageID {
    return NSStringFromClass([self class]);
}

- (NSMutableDictionary *)pageParam {
    return @{}.mutableCopy;
}

- (NSString *)prePageID {
    if (self.extraData[@"prePageID"]) {
        return self.extraData[@"prePageID"];
    } else return nil;
    
}

- (NSMutableDictionary *)prePageParam {
    if (self.extraData[@"prePageParam"]) {
        return self.extraData[@"prePageParam"];
    } else return nil;
}


@end
