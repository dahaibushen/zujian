//
//  UIViewController+router.m
//  OneStoreBase
//
//  Created by huangjiming on 11/9/15.
//  Copyright © 2015 OneStoreBase. All rights reserved.
//

#import "UIViewController+router.h"
#import <OTSCore/OTSCore.h>

@implementation UIViewController (router)

#pragma mark - Property

- (void)setExtraData:(NSDictionary *)extraData {
    [self setAssociatedObject:extraData forKey:@"extraData" policy:OTSAssociationPolicyRetainNonatomic];
}

- (NSDictionary *)extraData {
    return [self getAssociatedObjectForKey:@"extraData"];
}

@end
