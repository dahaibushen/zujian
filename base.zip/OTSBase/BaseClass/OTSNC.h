//
//  OTSNC.h
//  OneStoreFramework
//
//  Created by Aimy on 14-6-24.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "YHDTabBarItem.h"

@interface OTSNC : UINavigationController <TabBarItemTapDelegate>

//进度动画
@property(nonatomic, strong) UIPercentDrivenInteractiveTransition *interactivePopTransition;

@end
