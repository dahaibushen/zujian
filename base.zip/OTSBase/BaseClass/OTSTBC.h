//
//  OTSTBC.h
//  OneStoreFramework
//
//  Created by Aimy on 14-6-23.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSOperationManager.h"

@interface OTSTBC : UITabBarController <UITabBarControllerDelegate>

@end
