//
//  YHDAppDelegate.h
//  OTSBase
//
//  Created by liuwei7 on 2017/8/16.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YHDAppDelegate : UIResponder <UIApplicationDelegate>

@property(nonatomic, strong) UIWindow *window;//key window

@property(nonatomic, strong) UIWindow *modalWindow;//modal window(above key window)

@property(nonatomic, strong) UIWindow *topWindow;//top window(above alert window)

@end
