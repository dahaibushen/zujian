//
//  YHDAppDelegate.m
//  OTSBase
//
//  Created by liuwei7 on 2017/8/16.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "YHDAppDelegate.h"

@implementation YHDAppDelegate

#pragma mark - Getter & Setter

- (UIWindow *)window {
    if (!_window) {
        _window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        _window.backgroundColor = [UIColor whiteColor];
        _window.rootViewController = [UIViewController new];
    }
    return _window;
}

- (UIWindow *)modalWindow {
    if (!_modalWindow) {
        _modalWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        _modalWindow.backgroundColor = [UIColor clearColor];
        _modalWindow.windowLevel = UIWindowLevelNormal + 1;
        _modalWindow.rootViewController = [UIViewController new];
        [_modalWindow makeKeyAndVisible];
        _modalWindow.hidden = YES;
    }
    return _modalWindow;
}

- (UIWindow *)topWindow {
    if (!_topWindow) {
        _topWindow = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
        _topWindow.backgroundColor = [UIColor clearColor];
        _topWindow.windowLevel = UIWindowLevelAlert + 1;
        _topWindow.rootViewController = [UIViewController new];
        [_topWindow makeKeyAndVisible];
        _topWindow.hidden = YES;
    }
    return _topWindow;
}

@end
