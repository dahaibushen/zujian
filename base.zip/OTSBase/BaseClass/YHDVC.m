//
//  YHDVC.m
//  OTSBase
//
//  Created by liuwei7 on 2017/8/21.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "YHDVC.h"
#import "OTSNetworkManager.h"

@implementation YHDVC

#pragma mark - Orientations
- (BOOL)shouldAutorotate {
    return NO;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait;
}

#pragma mark -
- (OTSOperationManager *)operationManager {
    if (!_operationManager) {
        _operationManager = [[OTSNetworkManager sharedInstance] generateOperationMangerWithOwner:self];
    }

    return _operationManager;
}

- (void)cancelAllOperations {
    [self.operationManager cancelAllOperations];
}

@end
