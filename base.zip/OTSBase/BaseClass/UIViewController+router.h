//
//  UIViewController+router.h
//  OneStoreBase
//
//  Created by huangjiming on 11/9/15.
//  Copyright © 2015 OneStoreBase. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "OTSRouter.h"

@class OTSRouteVO;

@interface UIViewController (router)

/**
 *  OTS创建的时候的参数,如果不为nil，则标识是从router创建的,其中会传递OTSRouterCallbackKey的block用来回调
 */
@property(nonatomic, strong) NSDictionary *extraData;//for init


@end
