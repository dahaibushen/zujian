//
//  OTSNC.m
//  OneStoreFramework
//
//  Created by Aimy on 14-6-24.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSNC.h"
#import "OTSVC.h"
#import <OTSCore/OTSCore.h>

@interface OTSNC () <UINavigationControllerDelegate>


@end

@implementation OTSNC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.delegate = self;
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - Orientations

- (BOOL)shouldAutorotate {
    return [self.topViewController shouldAutorotate];
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return [self.topViewController supportedInterfaceOrientations];
}

#pragma mark - presentation

- (UIModalPresentationStyle)modalPresentationStyle {
    return [self.topViewController modalPresentationStyle];
}

- (UIModalTransitionStyle)modalTransitionStyle {
    return [self.topViewController modalTransitionStyle];
}

- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated {
    if (self.viewControllers.count) {
        viewController.hidesBottomBarWhenPushed = YES;
    }

    BOOL isTopVC = self.viewControllers.count <= 1;
    UIViewController *currentTopVC = self.topViewController;
    currentTopVC.hidesBottomBarWhenPushed = YES;
    [super pushViewController:viewController animated:animated];
    if (isTopVC) {
        currentTopVC.hidesBottomBarWhenPushed = NO;
    }

    if (self.viewControllers.count > 1) {
        UIViewController *previousVC = [self.viewControllers safeObjectAtIndex:self.viewControllers.count - 2];
        UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
        previousVC.navigationItem.backBarButtonItem = backItem;
    }
    if ([viewController isKindOfClass:[OTSVC class]]&& [currentTopVC isKindOfClass:[OTSVC class]]) {

        NSString *prePageID = ((OTSVC *)currentTopVC).pageID ? ((OTSVC *)currentTopVC).pageID : NSStringFromClass([currentTopVC class]) ;
        NSDictionary *prePageParam = ((OTSVC *)currentTopVC).pageParam;
        
        NSMutableDictionary *extraDic = [NSMutableDictionary dictionaryWithDictionary:[viewController valueForKey:@"extraData"]];
        extraDic[@"prePageID"] = prePageID;
        extraDic[@"prePageParam"] = prePageParam;
        [viewController setValue:extraDic.copy forKey:@"extraData"];
        
    }
}

- (UIViewController *)popViewControllerAnimated:(BOOL)animated {
    /**
     *  nc--->tbc--->nc
     *  nc--->nc----nc
     *  这两种结构的处理
     */
    if (self.viewControllers.count == 1) {
        if (self.tabBarController && self.tabBarController.navigationController) {
            return [self.tabBarController.navigationController popViewControllerAnimated:YES];
        }
        if (self.navigationController && self.navigationController.navigationController) {
            return [self.navigationController.navigationController popViewControllerAnimated:YES];
        }
    }
    //正常结构的处理
    return [super popViewControllerAnimated:animated];
}

#pragma mark - TabBarItemTapDelegate

- (void)repeateClickTabBarItem:(NSNumber *)count {
    if ([self.topViewController respondsToSelector:@selector(repeateClickTabBarItem:)]) {
        [self.topViewController performSelector:@selector(repeateClickTabBarItem:) withObject:count];
    }
}

- (id <UIViewControllerAnimatedTransitioning>)navigationController:(UINavigationController *)navigationController animationControllerForOperation:(UINavigationControllerOperation)operation fromViewController:(UIViewController *)fromVC toViewController:(UIViewController *)toVC {
    if (operation == UINavigationControllerOperationPush) {
        if (self.interactivePopTransition) {
            return [toVC pushInteractions];
        } else {
            return [toVC pushAnimations];
        }
    } else if (operation == UINavigationControllerOperationPop) {
        if (self.interactivePopTransition) {
            return [fromVC popInteractions];
        } else {
            return [fromVC popAnimations];
        }
    }

    return nil;
}

- (id <UIViewControllerInteractiveTransitioning>)navigationController:(UINavigationController *)navigationController interactionControllerForAnimationController:(id <UIViewControllerAnimatedTransitioning>)animationController {
    return self.interactivePopTransition;
}

- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    // 修复pop animated=NO时 layout错误。
    if (!animated && navigationController.tabBarController) {
        [navigationController.tabBarController.view setNeedsLayout];
    }
}

@end
