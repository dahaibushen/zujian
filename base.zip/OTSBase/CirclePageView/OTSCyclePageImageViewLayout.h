//
//  OTSCyclePageViewLayout.h
//  OneStorePublicFramework
//
//  Created by Aimy on 15/2/16.
//  Copyright (c) 2015年 yhd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OTSCyclePageImageViewLayout : UICollectionViewFlowLayout

@end
