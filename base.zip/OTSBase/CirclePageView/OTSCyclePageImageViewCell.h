//
//  OTSCyclePageViewCell.h
//  OneStorePublicFramework
//
//  Created by Aimy on 15/2/16.
//  Copyright (c) 2015年 yhd. All rights reserved.
//

#import "OTSCollectionViewCell.h"
#import "OTSLoadingImageView.h"

@interface OTSCyclePageImageViewCell : OTSCollectionViewCell

@property (nonatomic, readonly) OTSLoadingImageView *imageView;
@property (nonatomic) CGFloat cutOffRatio;

- (void)updateWithImageUrlString:(NSString *)aUrlString homepage:(BOOL)homepage customaryUrl:(BOOL)customaryUrl loadingText:(NSString *)text andClickBlock:(OTSBlockImageViewClickBlock)aBlock;


@end
