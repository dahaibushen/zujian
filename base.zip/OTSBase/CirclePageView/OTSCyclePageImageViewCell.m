//
//  OTSCyclePageViewCell.m
//  OneStorePublicFramework
//
//  Created by Aimy on 15/2/16.
//  Copyright (c) 2015年 yhd. All rights reserved.
//

#import "OTSCyclePageImageViewCell.h"
#import "OTSConvertImageString.h"
#import <OTSCore/OTSConstraintHelper.h>

#import <OTSCore/UIView+create.h>
#import "OTSPlaceholderImageView.h"
#import "UIImageView+WebCache.h"
#import <OTSCore/OTSCore.h>

@interface OTSCyclePageImageViewCell ()

@property (nonatomic, strong) OTSLoadingImageView *imageView;
@property (nonatomic, strong) OTSPlaceholderImageView *normalImgView;

@end

@implementation OTSCyclePageImageViewCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.imageView = [OTSLoadingImageView autolayoutView];
        [self.imageView setContentMode:UIViewContentModeScaleAspectFill];
        [self.contentView addSubview:self.imageView];
        [OTSConstraintHelper setView:self.imageView fullAsSuperview:self.contentView];
     
        self.normalImgView = [OTSPlaceholderImageView autolayoutView];
        [self.normalImgView setContentMode:UIViewContentModeScaleAspectFill];
        [self.contentView addSubview:self.normalImgView];
        [OTSConstraintHelper setView:self.normalImgView fullAsSuperview:self.contentView];
        self.normalImgView.hidden = YES;
        
    }
    return self;
}

- (void)updateWithImageUrlString:(NSString *)aUrlString homepage:(BOOL)homepage customaryUrl:(BOOL)customaryUrl loadingText:(NSString *)text andClickBlock:(OTSBlockImageViewClickBlock)aBlock {
    if (homepage) {
        self.imageView.hidden = NO;
        self.normalImgView.hidden = YES;
        
        [self.imageView setBlock:^(OTSBlockImageView *sender) {
            aBlock(sender);
        }];
        
        [self.imageView updateLoadingInfoWithBackImage:@"homeLoadingBG_BannerBG" desc:text type:LoadingImageViewTypeBanner];
        
        if (aUrlString) {
            if (self.contentView.bounds.size.width && self.contentView.bounds.size.height) {
                NSString *tempString = [OTSConvertImageString getJDPictureURLWithWidth:self.contentView.bounds.size.width height:self.contentView.bounds.size.height path:aUrlString];
                WEAK_SELF;
                [self.imageView sd_setImageWithURL:[NSURL URLWithString:tempString] placeholderImage:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    STRONG_SELF;
                    if (error) {
                        [self.imageView sd_setImageWithURL:[NSURL URLWithString:aUrlString]];
                    }
                }];
            } else {
                self.imageView.image = nil;
            }
        }
    } else {
        self.imageView.hidden = YES;
        self.normalImgView.hidden = NO;
        if (self.cutOffRatio&&self.cutOffRatio>0) {
            self.normalImgView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
            self.normalImgView.clipsToBounds = YES;
            self.normalImgView.layer.contentsRect = CGRectMake(0, 0, 1,self.cutOffRatio);
        }else{
            self.normalImgView.autoresizingMask = UIViewAutoresizingNone;
            self.normalImgView.clipsToBounds = NO;
            self.normalImgView.layer.contentsRect = CGRectMake(0, 0,1,1);
        }
        [self.normalImgView setBlock:^(OTSBlockImageView *sender) {
            aBlock(sender);
        }];
        
        if (aUrlString) {
            if (self.contentView.bounds.size.width && self.contentView.bounds.size.height) {
                NSString *tempString;
                if (customaryUrl) {
                    //直接使用接口url 不拼接宽高
                    tempString = aUrlString;
                }else{
                    tempString = [OTSConvertImageString getJDPictureURLWithWidth:self.contentView.bounds.size.width height:self.contentView.bounds.size.height path:aUrlString];
                }
                WEAK_SELF;
                [self.normalImgView sd_setImageWithURL:[NSURL URLWithString:tempString] placeholderImage:nil completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
                    STRONG_SELF;
                    if (error) {
                        [self.normalImgView sd_setImageWithURL:[NSURL URLWithString:aUrlString]];
                    }
                }];
            } else {
                self.normalImgView.image = nil;
            }
        }
        
    }
    
    #ifdef OTSAutomationTest
    NSString* imageViewAccessibilityInfo=[NSString stringWithFormat:@"%@",@"轮播图图片"];
    [self.imageView setAccessibilityInfo:imageViewAccessibilityInfo];//首页轮播图
    #endif
}

@end
