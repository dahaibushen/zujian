//
//  OTSGlobalValue.m
//  OneStoreFramework
//
//  Created by huang jiming on 14-7-31.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSGlobalValue.h"
#import <OTSCore/OTSCore.h>
#import "OTSUserDefault.h"
#import "OTSClientInfo.h"
#import "OTSGlobalDefine.h"

NSString *const KeyChainSignatureKey = @"keychain.signatureKey";

@interface OTSGlobalValue()

@property (nonatomic, copy) NSString *signatureKey;                  //解密后的签名密钥

@end

@implementation OTSGlobalValue

@synthesize signatureKey = _signatureKey,
            serverTime = _serverTime,
            sessionId = _sessionId;


DEF_SINGLETON(OTSGlobalValue)

- (instancetype)init
{
    if (self = [super init]) {

        NSNumber *isActive = [OTSKeychain getKeychainValueForType:OTS_KEYCHAIN_ISACTIVE];
        if (!isActive.boolValue) {
            [OTSKeychain setKeychainValue:@(YES) forType:OTS_KEYCHAIN_ISACTIVE];
        }
        
        //是否新版本第一次启动
        NSString *lastRunVersion = [OTSUserDefault getValueForKey:OTS_DEF_KEY_LAST_RUN_VERSION];
        NSString *currentVersion = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"];
        if (!lastRunVersion || ![lastRunVersion isEqualToString:currentVersion]) {
            [OTSUserDefault setValue:currentVersion forKey:OTS_DEF_KEY_LAST_RUN_VERSION];
        }
        
        //获取session id，用于购物车接口端本地缓存
        _sessionId = [OTSUserDefault getValueForKey:OTS_DEF_KEY_SESSION_ID];
        
    }
    return self;
}

- (NSString *)signatureKey
{
    if (_signatureKey == nil) {
        _signatureKey = [OTSKeychain getKeychainValueForType:KeyChainSignatureKey];
    }
    return _signatureKey;
}

- (void)setSignatureKey:(NSString *)signatureKey
{
    _signatureKey = [signatureKey copy];
    [OTSKeychain setKeychainValue:signatureKey forType:KeyChainSignatureKey];
}

- (NSDate *)serverTime{
    //根据本地时间与服务器时间的差异 算出的当前服务器的时间  **不要乱改，其他地方有用到
    _serverTime = [NSDate dateWithTimeIntervalSinceNow:self.dTime];
    return _serverTime;
}
- (NSString*)deviceToken
{
    if (_deviceToken==nil) {
        _deviceToken=[OTSKeychain getKeychainValueForType:OTS_KEYCHAIN_DEVICETOKEN];
    }
    return _deviceToken;
}
/**
 *  功能:方法重写，保证返回不为nil
 */
- (NSString *)sessionId
{
    if (_sessionId == nil) {
        return @"";
    } else {
        return _sessionId;
    }
}

-(void)setSessionId:(NSString *)sessionId
{
    if (![_sessionId isEqualToString:sessionId]) {
        _sessionId = sessionId;
       [OTSUserDefault setValue:_sessionId forKey:OTS_DEF_KEY_SESSION_ID];
    }
}

- (NSString *)serverTimestamp
{
    return [NSString stringWithFormat:@"%0.0lf", [[NSDate date] timeIntervalSince1970] + _dTime];
}

@end
