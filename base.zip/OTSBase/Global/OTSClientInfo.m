//
//  OTSClientInfo.m
//  OneStoreFramework
//
//  Created by Aimy on 14-6-23.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import "OTSClientInfo.h"
#import <AdSupport/AdSupport.h>
#import <OTSCore/OTSCore.h>
#import "OTSGlobalValue.h"
#import "OTSUserDefault.h"
#import "OTSGlobalDefine.h"

#import <UIDeviceIdentifier/UIDeviceHardware.h>

#define phoneTrackid @"8366231"
#define padTrackid @"10442025702"

@implementation OTSClientInfo
DEF_SINGLETON(OTSClientInfo)

- (id)init {
    self = [super init];
    if (self) {
        _clientAppVersion = [NSString stringWithFormat:@"%@",[[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"]];
        _clientVersion = [[UIDevice currentDevice] systemVersion];
        _deviceCode = [NSString stringWithString:[[UIDevice currentDevice] uniqueDeviceIdentifier]];
        _iaddr = @1;
        _nettype = @"";

        if (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone) {
            _unionKey = phoneTrackid;
            _clientSystem = @"iPhone";
            _traderName = @"iosSystem";            
        }else {
            _unionKey = padTrackid;
            _clientSystem = @"iPad";
            _traderName = @"iPadSystem";
        }
}
    
    return self;
}

- (NSString *)deviceToken
{
    if ([OTSGlobalValue sharedInstance].deviceToken!=nil) {
        return [OTSGlobalValue sharedInstance].deviceToken;
    }
    return _deviceToken;
}

- (NSString *)idfa{
    static NSString *uuid = nil;
    
    if (!uuid) {
       uuid = [ASIdentifierManager sharedManager].advertisingIdentifier.UUIDString;
    }
    
    if (uuid) {
        return uuid;
    } else {
        return _idfa;
    }
}

- (void)setLongitude:(NSNumber *)longitude
{
    _longitude = longitude;
}

- (void)setLatitude:(NSNumber *)latitude
{
    _latitude = latitude;
}

- (NSNumber *)pointWallChannelId
{
    return [OTSKeychain getKeychainValueForType:OTS_DEF_KEY_IS_DO_POINTWALL_ACTIVE_CHANNEL_ID];
}

- (NSString *)unionKey
{
    if (self.pointWallChannelId.integerValue > 0) {
        return self.pointWallChannelId.stringValue;
    }
    return _unionKey;
}

-(void)setPointWallChannelId:(NSNumber *)pointWallChannelId
{
    [OTSKeychain setKeychainValue:pointWallChannelId forType:OTS_DEF_KEY_IS_DO_POINTWALL_ACTIVE_CHANNEL_ID];
}

- (NSNumber *)abtest
{
    return [OTSUserDefault getValueForKey:OTS_DEF_KEY_ABTEST];
}

- (void)setAbtest:(NSNumber *)abtest
{
    [OTSUserDefault setValue:abtest forKey:OTS_DEF_KEY_ABTEST];
}

- (NSString*) phoneType
{
    return [UIDeviceHardware platformString];
}

#pragma 判断是 是否越狱

- (NSString *)isRoot
{
    if (!_isRoot) {
        _isRoot = [UIDevice isJailBreak] ? @"1" : @"0";
    }
    
    return _isRoot;
}

@end
