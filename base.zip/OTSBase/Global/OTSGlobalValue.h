//
//  OTSGlobalValue.h
//  OneStoreFramework
//
//  Created by huang jiming on 14-7-31.
//  Copyright (c) 2014年 OneStore. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface OTSGlobalValue : NSObject

+ (OTSGlobalValue *)sharedInstance;

@property (nonatomic, copy) NSString *pin;                                  //链接JD的pin
@property (nonatomic, assign) NSTimeInterval dTime;                         //服务器时间-客户端时间
@property (nonatomic, copy) NSDate         *serverTime;                     //根据差值算出的服务器时间
@property (nonatomic, copy) NSString       *token;                          //token
@property (nonatomic, copy) NSString       *sessionId;                      //sessionid，相当于cookie的id
@property (nonatomic, copy) NSNumber       *messageCount;                   //未读消息数量
@property (nonatomic, copy) NSNumber       *chatMessageCount;               // 不包括系统消息的未读聊天数量
@property (nonatomic, copy) NSString       *deviceToken;                    //推送的Devicetoken
@property (nonatomic, copy) NSString       *ip;                    //推送的Devicetoken

@property (nonatomic, assign) BOOL h5entrance;

- (NSString *)serverTimestamp;

@end
