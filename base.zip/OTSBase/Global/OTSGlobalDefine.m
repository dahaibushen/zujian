//
//  OTSGlobalDefine.m
//  OTSBase
//
//  Created by liuwei7 on 2017/9/20.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "OTSGlobalDefine.h"

#pragma mark - UserDefaults
NSString *const OTS_DEF_KEY_SESSION_ID                = @"OTS_DEF_KEY_SESSION_ID";//session id
NSString *const OTS_DEF_KEY_LAST_RUN_VERSION          = @"OTS_DEF_KEY_LAST_RUN_VERSION";//for first lunch
NSString *const UserDefaultAutoLogin = @"userdefault.passport.autoLogin";//登录
NSString *const OTS_DEF_KEY_ABTEST                    = @"OTS_DEF_KEY_ABTEST";//ABTest的key
NSString *const OTS_IMPORTSCHANNEL_MAP_YINDAO_SWITCH   =  @"OTS_IMPORTSCHANNEL_MAP_YINDAO_SWITCH";//全球进口频道国家馆引导开关

#pragma mark - KeyChain
NSString *const OTS_KEYCHAIN_ISACTIVE   = @"OTS_KEYCHAIN_ISACTIVE";
NSString *const OTS_KEYCHAIN_DEVICETOKEN = @"OTS_KEYCHAIN_DEVICETOKEN";
NSString *const OTS_DEF_KEY_IS_DO_POINTWALL_ACTIVE_CHANNEL_ID = @"OTS_DEF_KEY_IS_DO_POINTWALL_ACTIVE_CHANNEL_ID";
NSString *const KeyChainUserToken = @"keychain.passport.token";
