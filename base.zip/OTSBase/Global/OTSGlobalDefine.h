//
//  OTSGlobalDefine.h
//  OTSBase
//
//  Created by liuwei7 on 2017/9/20.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#ifndef OTS_GLOBAL_DEFINE
#define OTS_GLOBAL_DEFINE

#import <Foundation/Foundation.h>

#pragma mark - UserDefaults

FOUNDATION_EXPORT NSString *const OTS_DEF_KEY_SESSION_ID;                //session id
FOUNDATION_EXPORT NSString *const OTS_DEF_KEY_LAST_RUN_VERSION;          //for first lunch
FOUNDATION_EXPORT NSString *const UserDefaultAutoLogin;
FOUNDATION_EXPORT NSString *const OTS_DEF_KEY_ABTEST;                    //ABTest的key
FOUNDATION_EXPORT NSString *const OTS_IMPORTSCHANNEL_MAP_YINDAO_SWITCH;////全球进口频道国家馆引导开关

#pragma mark - KeyChains

FOUNDATION_EXPORT NSString *const OTS_KEYCHAIN_ISACTIVE;
FOUNDATION_EXPORT NSString *const KeyChainUserToken;
FOUNDATION_EXPORT NSString *const KeyChainSignatureKey;
FOUNDATION_EXPORT NSString *const OTS_KEYCHAIN_DEVICETOKEN;//设备推送token
FOUNDATION_EXPORT NSString *const OTS_DEF_KEY_IS_DO_POINTWALL_ACTIVE;   //是否激活过积分墙
FOUNDATION_EXPORT NSString *const OTS_DEF_KEY_IS_DO_POINTWALL_ACTIVE_CHANNEL_ID;   //下载渠道id

#pragma mark - Notifications

//地址变更通知
#define OTS_ADDRESS_CHANGED                 @"OTS_ADDRESS_CHANGED"

//刮刮卡
#define OTS_SCRATCH_BEGIN                   @"OTS_SCRATCH_BEGIN"//刮刮卡开始刮
//我的1号店
#define OTS_REFESH_MY_YHD_BROWSE_HISTORY @"OTS_REFESH_MY_YHD_BROWSE_HISTORY"//刷新我的收藏中购物足迹

//客服中心
#define OTS_RECEIVE_MSG                     @"OTS_RECEIVE_MSG"//收到消息

//首页
#define OTS_DAY_SIGN_IN                     @"OTS_DAY_SIGN_IN"//首页每日签到更新通知
#define OTS_FIRST_DAY_SIGN_IN              @"OTS_FIRST_DAY_SIGN_IN"//第一次登陆悬浮窗显示

//cart
#define OTS_UPDATE_SHOPPING_CART            @"OTS_UPDATE_SHOPPING_CART"//刷新购物车

//结算
#define OTS_CHECK_ORDER_UPDATE              @"OTS_CHECK_ORDER_UPDATE"//刷新结算

//route
#define OTS_ROUTE_TO_URL                    @"OTS_ROUTE_TO_URL"//route到指定的url

#define OTS_SHOW_VERSION_UPDATE             @"OTS_SHOW_VERSION_UPDATE"//显示版本更新空态界面

//消息
#define OTS_GLOBAL_CAN_SHOW_MESSAGE    @"OTS_GLOBAL_CAN_SHOW_MESSAGE"        //是否可以展示全局消息展示

#define OTS_CALLCENTER_UPDATE_MESSAGE_COUNT @"OTS_CALLCENTER_UPDATE_MESSAGE_COUNT"  // 更新消息数字

#define OTS_CHANGE_STATUSBAR_FRAME      @"UIApplicationDidChangeStatusBarFrameNotification" //app状态栏发送变化，主要是打电话

#define OTS_CMS_LOG                         @"OTS_CMS_LOG"//CMS日志

#define OTS_HTTPS_SWITCHED_NOTIFICATION                   @"OTS_HTTPS_SWITCHED_NOTIFICATION"

#define OTS_BI_NOTIFICATION @"OTS_BI_NOTIFICATION" //BI通知

#define OTS_TABBAR_UPDATE @"OTS_TABBAR_UPDATE" // 更新 tabbar

#define OTS_HOME_TABBAR_CLICKED @"OTS_HOME_TABBAR_CLICKED" // 首页 tab 双击

#endif
