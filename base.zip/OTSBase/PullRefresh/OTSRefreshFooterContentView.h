//
//  JWPullRefreshHeaderContentView.h
//  JWUIKit
//
//  Created by Jerry on 16/4/9.
//  Copyright © 2016年 Jerry Wong. All rights reserved.
//

#import <OTSCore/OTSCore.h>

@interface OTSRefreshFooterContentView : UIView <OTSRefreshContentViewProtocol>

@end
