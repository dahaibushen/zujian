//
//  UIScrollView+OTSPullRefresh.h
//  OTSBase
//
//  Created by Jerry on 2017/8/29.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import <OTSCore/UIScrollView+PullRefresh.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (OTSPullRefresh)

- (void)addRefreshHeaderWithBlock:(OTSRefreshHeaderBlock)aBlock;

- (void)addLoadMoreFooterWithBlock:(OTSRefreshFooterBlock)aBlock;

@end

@interface OTSRefreshHeaderView (OTSUpdateDate)

- (void)refreshLastUpdatedDate:(nullable NSDate*)date;

@end

NS_ASSUME_NONNULL_END
