//
//  UIScrollView+OTSPullRefresh.m
//  OTSBase
//
//  Created by Jerry on 2017/8/29.
//  Copyright © 2017年 com.yhd. All rights reserved.
//

#import "UIScrollView+OTSPullRefresh.h"
#import "OTSRefreshHeaderContentView.h"
#import "OTSRefreshFooterContentView.h"

@implementation UIScrollView (OTSPullRefresh)

- (void)addRefreshHeaderWithBlock:(OTSRefreshHeaderBlock)aBlock {
    [self addRefreshHeaderWithBlock:aBlock contentClass:OTSRefreshHeaderContentView.class];
    self.refreshHeader.style = OTSPullRefreshStyleFollow;
}

- (void)addLoadMoreFooterWithBlock:(OTSRefreshFooterBlock)aBlock {
    [self addLoadMoreFooterWithBlock:aBlock contentClass:OTSRefreshFooterContentView.class];
}

@end

@implementation OTSRefreshHeaderView (OTSUpdateDate)

- (void)refreshLastUpdatedDate:(NSDate*)date {
    if ([self.contentView respondsToSelector:@selector(refreshLastUpdatedDate:)]) {
        [(id)self.contentView refreshLastUpdatedDate:date];
    }
}

@end
