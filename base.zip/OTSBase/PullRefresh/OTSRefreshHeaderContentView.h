//
//  JWPullRefreshHeaderContentView.h
//  JWUIKit
//
//  Created by Jerry on 16/4/9.
//  Copyright © 2016年 Jerry Wong. All rights reserved.
//

#import <OTSCore/OTSCore.h>

@interface OTSRefreshHeaderContentView : UIView<OTSRefreshContentViewProtocol>

@property (nonatomic, strong, readonly) UIImageView *imageView;
@property (nonatomic, strong, readonly) UILabel *infoLabel;
@property (nonatomic, strong, readonly) UILabel *statusLabel;

- (void)refreshLastUpdatedDate:(NSDate*)date;

@end
