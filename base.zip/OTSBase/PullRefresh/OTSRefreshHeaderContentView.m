//
//  OTSPullRefreshHeaderContentView.m
//  OTSUIKit
//
//  Created by Jerry on 16/4/9.
//  Copyright © 2016年 Jerry Wong. All rights reserved.
//

#import "OTSRefreshHeaderContentView.h"
#import <UIView+FDCollapsibleConstraints/UIView+FDCollapsibleConstraints.h>

@implementation OTSRefreshHeaderContentView {
    NSDateFormatter *_dateFormatter;
}

+ (CGFloat)preferredHeight {
    return 65.f;
}

+ (NSUInteger)imageFrameCount {
    return 14;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        UIView *contentView = [[UIView alloc] init];
        contentView.translatesAutoresizingMaskIntoConstraints = NO;
        [self addSubview:contentView];
        
        _infoLabel = [[UILabel alloc] init];
        _infoLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _infoLabel.font = [UIFont systemFontOfSize:11.0f];
        _infoLabel.textColor = [UIColor lightGrayColor];
        _infoLabel.textAlignment = NSTextAlignmentCenter;
        [contentView addSubview:_infoLabel];
        
        _statusLabel = [[UILabel alloc] init];
        _statusLabel.translatesAutoresizingMaskIntoConstraints = NO;
        _statusLabel.font = [UIFont systemFontOfSize:11.0f];
        _statusLabel.textColor = [UIColor lightGrayColor];
        [contentView addSubview:_statusLabel];
        
        _imageView = [[UIImageView alloc] init];
        _imageView.translatesAutoresizingMaskIntoConstraints = NO;
        [contentView addSubview:_imageView];
        
        NSMutableArray *images = [NSMutableArray array];
        for (int i = 1; i <= [self.class imageFrameCount]; i++) {
            [images safeAddObject:[UIImage imageNamed:[self imageNameAtIndex:i]]];
        }
        
        if (images.count > 1) {
            _imageView.animationDuration = 1.f;
            _imageView.animationImages = images;
        } else if(images.count == 1){
            _imageView.image = images[0];
        }
        
        [contentView autoCenterInSuperview];
        [self setupConstraints];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapContentView:)];
        [self addGestureRecognizer:tap];
    }
    return self;
}

- (NSString*)imageNameAtIndex:(NSUInteger)idx {
    return [NSString stringWithFormat:@"refreshheaderView_arrow%zd",idx];
}

- (void)setupConstraints {
    [_imageView autoPinEdgeToSuperviewEdge:ALEdgeLeft];
    [_imageView autoPinEdgeToSuperviewEdge:ALEdgeTop];
    
    [self.infoLabel autoPinEdgeToSuperviewEdge:ALEdgeRight];
    [self.infoLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:_imageView withOffset:-5.0];
    [self.infoLabel autoSetDimension:ALDimensionWidth toSize:90.0];
    [_imageView autoAlignAxis:ALAxisHorizontal toSameAxisOfView:self.infoLabel];
    
    [_statusLabel autoPinEdgeToSuperviewEdge:ALEdgeBottom];
    NSLayoutConstraint *timeTopGap = [_statusLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.infoLabel withOffset:5.0];
    [_statusLabel autoAlignAxis:ALAxisVertical toSameAxisOfView:_statusLabel.superview];
    _statusLabel.fd_autoCollapse = YES;
    _statusLabel.fd_collapsibleConstraints = @[timeTopGap];
}

- (void)refreshLastUpdatedDate: (NSDate*)date {
    if (date) {
        if (!_dateFormatter) {
            _dateFormatter = [NSDateFormatter new];
            _dateFormatter.locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
            _dateFormatter.dateFormat = @"yyyy.MM.dd a h:mm";
        }
        self.statusLabel.text = [NSString stringWithFormat:@"上次刷新: %@", [_dateFormatter stringFromDate:[NSDate date]]];
    } else {
        self.statusLabel.text = nil;
    }
}

#pragma mark - Action
- (void)didTapContentView:(UITapGestureRecognizer*)sender {
    void (^refreshingBlock)(id refreshView) = [self.superview valueForKey:@"refreshingBlock"];
    
    if (refreshingBlock) {
        refreshingBlock(self.superview);
        [self startLoading];
    }
}

#pragma mark - OTSPullRefreshContentViewProtocol
- (void)setProgress:(CGFloat)progress {
    if (progress < 1.0) {
        self.infoLabel.text = @"下拉可以刷新...";
    } else {
        self.infoLabel.text = @"松开即可刷新...";
    }
    
    [_imageView stopAnimating];
    _imageView.image = [UIImage imageNamed: [self imageNameAtIndex:((int)(progress * 25) % ([self.class imageFrameCount]) + 1)]];
}

- (void)startLoading {
    self.infoLabel.text = @"载入中...";
    [_imageView startAnimating];
    self.userInteractionEnabled = NO;
}

- (void)stopLoading {
    [_imageView stopAnimating];
    self.userInteractionEnabled = NO;
}

- (void)loadedError:(NSString *)errorMsg {
    [_imageView stopAnimating];
    self.infoLabel.text = errorMsg;
    _statusLabel.text = @"点击重新加载";
    self.userInteractionEnabled = YES;
}

@end
